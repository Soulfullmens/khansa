import type { Express, Request, Response, NextFunction } from "express";
import express from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import {
  insertUserSchema,
  insertInvestmentSchema,
  insertGoalSchema,
  insertTransactionSchema,
  insertInsightSchema,
  insertStreakSchema,
  insertUserAchievementSchema,
  insertUserRewardSchema,
  insertPointTransactionSchema
} from "@shared/schema";
import "./types"; // Import types extensions
import { setupAuth, attachUserToRequest } from "./auth";
import crypto from 'crypto';
import nodemailer from 'nodemailer';
import { getCurrentGoldPrice, initGoldPriceService } from './gold-price-service';

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize gold price service
  await initGoldPriceService();

  // Set up authentication
  setupAuth(app);
  
  // Middleware to attach user to request object for authenticated routes
  app.use("/api", attachUserToRequest);
  
  // Authentication middleware
  const authenticate = async (req: Request, res: Response, next: Function) => {
    if (!req.user) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };
  
  // Password reset routes
  app.post('/api/forgot-password', async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: 'Email is required' });
      }
      
      // Find user by email
      const user = await storage.getUserByEmail(email);
      if (!user) {
        // Don't reveal that the user doesn't exist
        return res.json({ message: 'If an account with that email exists, a password reset link has been sent.' });
      }
      
      // Generate reset token
      const resetToken = crypto.randomBytes(32).toString('hex');
      const resetTokenExpires = new Date(Date.now() + 60 * 60 * 1000); // 1 hour
      
      // Save reset token to user
      await storage.setResetToken(user.id, resetToken, resetTokenExpires);
      
      // Create reset URL
      const resetUrl = `${req.headers.origin}/reset-password?token=${resetToken}`;
      
      // Email configuration
      let emailSent = false;
      let emailError = null;
      
      // Try SendGrid first if available
      if (process.env.SENDGRID_API_KEY) {
        try {
          const sgMail = require('@sendgrid/mail');
          sgMail.setApiKey(process.env.SENDGRID_API_KEY);
          
          const msg = {
            to: email,
            from: 'support@khansa.io',
            subject: 'Khansa - Password Reset',
            text: `You are receiving this email because you (or someone else) has requested a password reset for your account. Please click on the following link to reset your password: ${resetUrl}`,
            html: `
              <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f5eb; color: #333;">
                <div style="text-align: center; margin-bottom: 20px;">
                  <h1 style="color: #D4AF37; margin-bottom: 10px;">Khansa</h1>
                  <p style="font-size: 18px; color: #8B7D3A;">Your Financial Wellness Partner</p>
                </div>
                
                <div style="background-color: white; padding: 25px; border-radius: 10px; border: 1px solid #eee;">
                  <h2 style="margin-top: 0; color: #996515;">Password Reset</h2>
                  <p>Hello,</p>
                  <p>You are receiving this email because you (or someone else) has requested a password reset for your account.</p>
                  <p>Please click on the button below to reset your password:</p>
                  
                  <div style="text-align: center; margin: 30px 0;">
                    <a href="${resetUrl}" style="display: inline-block; background-color: #D4AF37; color: white; padding: 12px 25px; text-decoration: none; border-radius: 4px; font-weight: bold;">Reset Password</a>
                  </div>
                  
                  <p>If you did not request this, please ignore this email and your password will remain unchanged.</p>
                  <p>This link will expire in 1 hour.</p>
                </div>
                
                <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #777;">
                  <p>© ${new Date().getFullYear()} Khansa. All rights reserved.</p>
                </div>
              </div>
            `
          };
          
          await sgMail.send(msg);
          emailSent = true;
        } catch (error) {
          console.error('SendGrid email error:', error);
          emailError = error;
        }
      }
      
      // Fall back to Nodemailer if SendGrid fails or isn't available
      if (!emailSent) {
        try {
          // Create test account if SMTP config isn't provided
          let transporter;
          if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
            transporter = nodemailer.createTransport({
              host: process.env.SMTP_HOST,
              port: process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT) : 587,
              secure: process.env.SMTP_SECURE === 'true',
              auth: {
                user: process.env.SMTP_USER,
                pass: process.env.SMTP_PASS
              }
            });
          } else {
            // For development, use Ethereal to test emails
            const testAccount = await nodemailer.createTestAccount();
            transporter = nodemailer.createTransport({
              host: 'smtp.ethereal.email',
              port: 587,
              secure: false,
              auth: {
                user: testAccount.user,
                pass: testAccount.pass
              }
            });
          }
          
          const mailOptions = {
            from: '"Khansa Support" <support@khansa.io>',
            to: email,
            subject: 'Khansa - Password Reset',
            text: `You are receiving this email because you (or someone else) has requested a password reset for your account. Please click on the following link to reset your password: ${resetUrl}`,
            html: `
              <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f9f5eb; color: #333;">
                <div style="text-align: center; margin-bottom: 20px;">
                  <h1 style="color: #D4AF37; margin-bottom: 10px;">Khansa</h1>
                  <p style="font-size: 18px; color: #8B7D3A;">Your Financial Wellness Partner</p>
                </div>
                
                <div style="background-color: white; padding: 25px; border-radius: 10px; border: 1px solid #eee;">
                  <h2 style="margin-top: 0; color: #996515;">Password Reset</h2>
                  <p>Hello,</p>
                  <p>You are receiving this email because you (or someone else) has requested a password reset for your account.</p>
                  <p>Please click on the button below to reset your password:</p>
                  
                  <div style="text-align: center; margin: 30px 0;">
                    <a href="${resetUrl}" style="display: inline-block; background-color: #D4AF37; color: white; padding: 12px 25px; text-decoration: none; border-radius: 4px; font-weight: bold;">Reset Password</a>
                  </div>
                  
                  <p>If you did not request this, please ignore this email and your password will remain unchanged.</p>
                  <p>This link will expire in 1 hour.</p>
                </div>
                
                <div style="margin-top: 20px; text-align: center; font-size: 12px; color: #777;">
                  <p>© ${new Date().getFullYear()} Khansa. All rights reserved.</p>
                </div>
              </div>
            `
          };
          
          const info = await transporter.sendMail(mailOptions);
          console.log('Email sent:', info.messageId);
          
          // Log preview URL for development
          if (!process.env.SMTP_HOST) {
            console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
          }
          emailSent = true;
        } catch (error) {
          console.error('Nodemailer error:', error);
          emailError = emailError || error;
        }
      }
      
      // For development purposes, always return success
      // In production, should handle errors properly
      if (!emailSent && emailError) {
        console.error('Failed to send password reset email:', emailError);
      }
      
      res.json({ message: 'If an account with that email exists, a password reset link has been sent.' });
    } catch (error) {
      console.error('Password reset request error:', error);
      res.status(500).json({ message: 'Error processing password reset request' });
    }
  });
  
  app.post('/api/reset-password', async (req, res) => {
    try {
      const { token, password } = req.body;
      
      if (!token || !password) {
        return res.status(400).json({ message: 'Token and password are required' });
      }
      
      // Find user by reset token
      const user = await storage.getUserByResetToken(token);
      if (!user) {
        return res.status(400).json({ message: 'Invalid or expired token' });
      }
      
      // Hash the new password
      const { hashPassword } = await import('./auth');
      const hashedPassword = await hashPassword(password);
      
      // Update user password and clear reset token
      await storage.updatePassword(user.id, hashedPassword);
      
      res.json({ message: 'Password has been reset successfully' });
    } catch (error) {
      console.error('Password reset error:', error);
      res.status(500).json({ message: 'Error resetting password' });
    }
  });

  // Investment routes
  app.get("/api/investments", authenticate, async (req, res) => {
    try {
      const investment = await storage.getInvestmentByUserId(req.user!.id);
      if (!investment) {
        return res.status(404).json({ message: "Investment not found" });
      }
      res.json(investment);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch investment data" });
    }
  });

  app.post("/api/investments/add", authenticate, async (req, res) => {
    try {
      const { amount } = req.body;
      const numericAmount = parseFloat(amount);
      
      if (isNaN(numericAmount) || numericAmount <= 0) {
        return res.status(400).json({ message: "Invalid amount" });
      }
      
      // Get latest gold price
      const goldPrice = await storage.getLatestGoldPrice();
      if (!goldPrice) {
        return res.status(500).json({ message: "Gold price not available" });
      }
      
      // Get current investment
      const currentInvestment = await storage.getInvestmentByUserId(req.user!.id);
      if (!currentInvestment) {
        return res.status(404).json({ message: "Investment not found" });
      }
      
      // Calculate new gold amount
      const pricePerGram = parseFloat(goldPrice.pricePerGram.toString());
      const goldAmount = numericAmount / pricePerGram;
      
      // Update investment
      const currentGoldAmount = parseFloat(currentInvestment.goldAmount.toString());
      const currentGoldValue = parseFloat(currentInvestment.goldValue.toString());
      const currentOtherInvestments = parseFloat((currentInvestment.otherInvestments || "0").toString());
      
      const updatedInvestment = await storage.updateInvestment(currentInvestment.id, {
        goldAmount: (currentGoldAmount + goldAmount).toString(),
        goldValue: (currentGoldValue + numericAmount).toString(),
        totalValue: (currentGoldValue + numericAmount + currentOtherInvestments).toString()
      });
      
      // Create transaction record
      await storage.createTransaction({
        userId: req.user!.id,
        type: "manual-deposit",
        amount: numericAmount.toString(),
        description: "Manual deposit to gold"
      });
      
      res.json(updatedInvestment);
    } catch (error) {
      res.status(500).json({ message: "Failed to add investment" });
    }
  });

  // Goals routes
  app.get("/api/goals", authenticate, async (req, res) => {
    try {
      const goals = await storage.getGoalsByUserId(req.user!.id);
      res.json(goals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch goals" });
    }
  });

  app.post("/api/goals", authenticate, async (req, res) => {
    try {
      const goalData = insertGoalSchema.parse({
        ...req.body,
        userId: req.user!.id
      });
      
      const goal = await storage.createGoal(goalData);
      res.status(201).json(goal);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to create goal" });
    }
  });

  app.patch("/api/goals/:id", authenticate, async (req, res) => {
    try {
      const goalId = parseInt(req.params.id);
      
      // Validate goal exists and belongs to user
      const existingGoal = await storage.getGoalById(goalId);
      if (!existingGoal) {
        return res.status(404).json({ message: "Goal not found" });
      }
      
      if (existingGoal.userId !== req.user!.id) {
        return res.status(403).json({ message: "Not authorized to update this goal" });
      }
      
      // Update goal
      const updatedGoal = await storage.updateGoal(goalId, req.body);
      res.json(updatedGoal);
    } catch (error) {
      res.status(500).json({ message: "Failed to update goal" });
    }
  });

  app.delete("/api/goals/:id", authenticate, async (req, res) => {
    try {
      const goalId = parseInt(req.params.id);
      
      // Validate goal exists and belongs to user
      const existingGoal = await storage.getGoalById(goalId);
      if (!existingGoal) {
        return res.status(404).json({ message: "Goal not found" });
      }
      
      if (existingGoal.userId !== req.user!.id) {
        return res.status(403).json({ message: "Not authorized to delete this goal" });
      }
      
      // Delete goal
      await storage.deleteGoal(goalId);
      res.json({ message: "Goal deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete goal" });
    }
  });

  // Transactions routes
  app.get("/api/transactions", authenticate, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const transactions = await storage.getTransactionsByUserId(req.user!.id, limit);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Gold price routes
  app.get("/api/gold/price", async (req, res) => {
    try {
      // First try to get real-time price from API
      try {
        const realtimePrice = await getCurrentGoldPrice();
        
        // Convert to the format expected by the client
        return res.json({
          pricePerGram: realtimePrice.price.toString(),
          change24h: realtimePrice.change24h || "0.00",
          currency: "INR",
          timestamp: new Date(realtimePrice.timestamp).toISOString()
        });
      } catch (apiError) {
        console.error("Failed to get real-time gold price:", apiError);
        
        // Fall back to database price if API fails
        const goldPrice = await storage.getLatestGoldPrice();
        if (!goldPrice) {
          return res.status(404).json({ message: "Gold price not available" });
        }
        res.json(goldPrice);
      }
    } catch (error) {
      console.error("Gold price error:", error);
      res.status(500).json({ message: "Failed to fetch gold price" });
    }
  });
  
  // Historical gold price route
  app.get("/api/gold/price/history", async (req, res) => {
    try {
      const days = parseInt(req.query.days as string) || 30;
      
      // Limit to reasonable number of days
      const limitedDays = Math.min(days, 365);
      
      // Create end date (today)
      const endDate = new Date();
      
      // Create start date (X days ago)
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - limitedDays);
      
      // In a production environment, we would fetch this from an external API
      // or from a database where we store regular gold price updates
      
      // For now, we'll generate synthetic data for demonstration purposes
      const historicalPrices = [];
      
      // Current price as reference
      const latestPrice = await storage.getLatestGoldPrice();
      const basePrice = latestPrice ? parseFloat(latestPrice.pricePerGram.toString()) : 5500;
      
      // Generate daily prices
      for (let i = 0; i <= limitedDays; i++) {
        const date = new Date(startDate);
        date.setDate(date.getDate() + i);
        
        // Calculate a price with some random variation
        // This is just for demonstration - real prices would come from the database
        const randomFactor = 0.98 + (Math.random() * 0.04); // +/- 2% random variation
        const trendFactor = 1 + (i / limitedDays * 0.075); // Slight upward trend over time (7.5% over period)
        
        const price = basePrice * randomFactor * trendFactor;
        
        historicalPrices.push({
          date: date.toISOString().split('T')[0],
          price: Math.round(price * 100) / 100 // Round to 2 decimal places
        });
      }
      
      // Return the historical prices
      res.json(historicalPrices);
    } catch (error) {
      console.error('Error fetching historical gold prices:', error);
      res.status(500).json({ message: "Failed to fetch historical gold prices" });
    }
  });
  
  // Gold price forecast route (AI-powered predictions)
  app.get("/api/gold/forecast", authenticate, async (req, res) => {
    try {
      // In a production environment, this would use an AI model to predict gold prices
      // For now, we'll return a simple prediction
      
      const latestPrice = await storage.getLatestGoldPrice();
      if (!latestPrice) {
        return res.status(404).json({ message: "Gold price not available" });
      }
      
      const currentPrice = parseFloat(latestPrice.pricePerGram.toString());
      const randomDirection = Math.random() > 0.5 ? 'rise' : 'fall';
      const randomPercent = (1 + Math.random() * 4).toFixed(1); // 1-5% change
      
      const prediction = `Gold prices are likely to ${randomDirection} by approximately ${randomPercent}% in the next month based on market indicators.`;
      
      res.json({
        prediction,
        confidence: 0.75 + (Math.random() * 0.2) // 75-95% confidence
      });
    } catch (error) {
      console.error('Error generating gold price forecast:', error);
      res.status(500).json({ message: "Failed to generate forecast" });
    }
  });

  // Insights routes
  app.get("/api/insights", authenticate, async (req, res) => {
    try {
      const insights = await storage.getInsightsByUserId(req.user!.id);
      res.json(insights);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch insights" });
    }
  });

  app.patch("/api/insights/:id/read", authenticate, async (req, res) => {
    try {
      const insightId = parseInt(req.params.id);
      const success = await storage.markInsightAsRead(insightId);
      
      if (!success) {
        return res.status(404).json({ message: "Insight not found" });
      }
      
      res.json({ message: "Insight marked as read" });
    } catch (error) {
      res.status(500).json({ message: "Failed to mark insight as read" });
    }
  });

  // AI-powered financial insights and recommendations
  app.get("/api/spending-analysis", authenticate, async (req, res) => {
    try {
      const userId = req.user!.id;
      
      // Get user transactions
      const storedTransactions = await storage.getTransactionsByUserId(userId);
      
      // Convert to format expected by analyzeSpending (add category and date properties)
      const transactions = storedTransactions.map(t => ({
        ...t,
        amount: parseFloat(t.amount),
        category: t.type, // Use type as category for now
        date: t.createdAt,
      }));
      
      // Analyze spending patterns
      const { analyzeSpending } = await import("../client/src/lib/ai-service");
      const analysis = analyzeSpending(transactions);
      
      // Return the analysis
      res.json(analysis);
    } catch (error) {
      console.error("Error generating spending analysis:", error);
      res.status(500).json({ 
        error: "Failed to generate spending analysis" 
      });
    }
  });

  app.get("/api/savings-recommendations", authenticate, async (req, res) => {
    try {
      const userId = req.user!.id;
      
      // Get user transactions
      const storedTransactions = await storage.getTransactionsByUserId(userId);
      
      // Convert to format expected by analyzeSpending (add category and date properties)
      const transactions = storedTransactions.map(t => ({
        ...t,
        amount: parseFloat(t.amount),
        category: t.type, // Use type as category for now
        date: t.createdAt,
      }));
      
      // Analyze spending patterns and generate AI recommendations
      const { analyzeSpending, generateSavingsRecommendations } = await import("../client/src/lib/ai-service");
      const analysis = analyzeSpending(transactions);
      const recommendations = await generateSavingsRecommendations(analysis);
      
      // Return recommendations
      res.json(recommendations);
    } catch (error) {
      console.error("Error generating savings recommendations:", error);
      res.status(500).json({ 
        error: "Failed to generate savings recommendations" 
      });
    }
  });

  // Subscription and payment routes
  if (process.env.STRIPE_SECRET_KEY) {
    // Import Stripe using dynamic import for ES modules
    const Stripe = await import('stripe').then(module => module.default);
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
      apiVersion: '2025-03-31.basil' as any
    });

    app.post("/api/create-payment-intent", authenticate, async (req, res) => {
      try {
        const { amount, purchaseType, goldGrams, pricePerGram } = req.body;
        const numericAmount = parseFloat(amount);
        
        if (isNaN(numericAmount) || numericAmount <= 0) {
          return res.status(400).json({ message: "Invalid amount" });
        }
        
        // Create metadata based on purchase type
        const metadata: Record<string, string> = {
          userId: req.user!.id.toString(),
        };
        
        // Add gold purchase metadata if applicable
        if (purchaseType === 'gold' && goldGrams && pricePerGram) {
          metadata.purchaseType = 'gold';
          metadata.goldGrams = goldGrams.toString();
          metadata.pricePerGram = pricePerGram.toString();
        }
        
        // Create a payment intent
        const paymentIntent = await stripe.paymentIntents.create({
          amount: Math.round(numericAmount * 100), // Convert to cents
          currency: "inr", // Using Indian Rupees as default
          metadata,
        });
        
        res.json({ 
          clientSecret: paymentIntent.client_secret,
          amount: numericAmount
        });
      } catch (error) {
        console.error("Payment intent creation error:", error);
        res.status(500).json({ message: "Failed to create payment intent" });
      }
    });
    
    app.post("/api/create-subscription", authenticate, async (req, res) => {
      try {
        const { tier, paymentMethod } = req.body;
        
        if (!tier) {
          return res.status(400).json({ message: "Subscription tier is required" });
        }
        
        let user = req.user! as any;
        
        // Create or get Stripe customer
        let customer;
        if (user.stripeCustomerId) {
          customer = await stripe.customers.retrieve(user.stripeCustomerId);
        } else {
          customer = await stripe.customers.create({
            name: user.name,
            metadata: {
              userId: user.id.toString()
            }
          });
          
          // Update user with customer ID
          user = await storage.updateStripeCustomerId(user.id, customer.id);
        }
        
        // Determine price based on tier
        const prices = {
          standard: "price_standard", // placeholder price IDs
          premium: "price_premium",
          platinum: "price_platinum"
        };
        
        const priceId = prices[tier as keyof typeof prices] || prices.standard;
        
        // Create subscription
        const subscription = await stripe.subscriptions.create({
          customer: customer.id,
          items: [{ price: priceId }],
          payment_behavior: 'default_incomplete',
          expand: ['latest_invoice.payment_intent'],
        }) as any;
        
        // Update user subscription info
        await storage.updateUserStripeInfo(user.id, {
          customerId: customer.id,
          subscriptionId: subscription.id,
          status: subscription.status,
          tier
        });
        
        // Return client secret for the frontend to complete payment
        const clientSecret = subscription.latest_invoice?.payment_intent?.client_secret;
        res.json({
          subscriptionId: subscription.id,
          clientSecret,
        });
      } catch (error) {
        console.error("Subscription creation error:", error);
        res.status(500).json({ message: "Failed to create subscription" });
      }
    });
    
    app.get("/api/subscription-status", authenticate, async (req, res) => {
      try {
        const user = req.user! as any;
        
        if (!user.stripeSubscriptionId) {
          return res.json({ status: "none", tier: "free" });
        }
        
        const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId) as any;
        
        res.json({
          status: subscription.status,
          tier: user.subscriptionTier,
          currentPeriodEnd: new Date(subscription.current_period_end * 1000),
          cancelAtPeriodEnd: subscription.cancel_at_period_end
        });
      } catch (error) {
        console.error("Subscription status error:", error);
        res.status(500).json({ message: "Failed to get subscription status" });
      }
    });
    
    app.post("/api/cancel-subscription", authenticate, async (req, res) => {
      try {
        const user = req.user! as any;
        
        if (!user.stripeSubscriptionId) {
          return res.status(400).json({ message: "No active subscription" });
        }
        
        // Cancel at period end
        const subscription = await stripe.subscriptions.update(user.stripeSubscriptionId, {
          cancel_at_period_end: true
        }) as any;
        
        res.json({
          status: subscription.status,
          cancelAtPeriodEnd: subscription.cancel_at_period_end,
          currentPeriodEnd: new Date(subscription.current_period_end * 1000)
        });
      } catch (error) {
        console.error("Subscription cancellation error:", error);
        res.status(500).json({ message: "Failed to cancel subscription" });
      }
    });

    // Webhook to handle Stripe events
    const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;
    app.post('/api/webhook', express.raw({type: 'application/json'}), async (req, res) => {
      let event;
      
      // Verify webhook signature
      if (endpointSecret) {
        const signature = req.headers['stripe-signature'] as string;
        try {
          event = stripe.webhooks.constructEvent(
            req.body,
            signature,
            endpointSecret
          );
        } catch (err: any) {
          console.error(`Webhook signature verification failed:`, err);
          return res.status(400).send(`Webhook Error: ${err.message}`);
        }
      } else {
        // For testing without signature verification
        try {
          event = JSON.parse(req.body.toString());
        } catch (err: any) {
          console.error('Error parsing webhook payload:', err);
          return res.status(400).send(`Webhook Error: ${err.message}`);
        }
      }
      
      // Handle specific events
      try {
        switch (event.type) {
          case 'payment_intent.succeeded':
            const paymentIntent = event.data.object;
            console.log(`PaymentIntent ${paymentIntent.id} succeeded`);
            
            // Check if this is a gold purchase
            if (paymentIntent.metadata.purchaseType === 'gold' && 
                paymentIntent.metadata.userId && 
                paymentIntent.metadata.goldGrams && 
                paymentIntent.metadata.pricePerGram) {
              
              const userId = parseInt(paymentIntent.metadata.userId);
              const goldGrams = parseFloat(paymentIntent.metadata.goldGrams);
              const pricePerGram = parseFloat(paymentIntent.metadata.pricePerGram);
              const amount = paymentIntent.amount / 100; // Convert from cents
              
              // Get current investment
              const currentInvestment = await storage.getInvestmentByUserId(userId);
              if (!currentInvestment) {
                console.error(`Investment not found for user ${userId}`);
                break;
              }
              
              // Update investment with new gold amount
              const currentGoldAmount = parseFloat(currentInvestment.goldAmount.toString());
              const currentGoldValue = parseFloat(currentInvestment.goldValue.toString());
              const currentOtherInvestments = parseFloat((currentInvestment.otherInvestments || "0").toString());
              
              await storage.updateInvestment(currentInvestment.id, {
                goldAmount: (currentGoldAmount + goldGrams).toString(),
                goldValue: (currentGoldValue + amount).toString(),
                totalValue: (currentGoldValue + amount + currentOtherInvestments).toString()
              });
              
              // Create transaction record
              await storage.createTransaction({
                userId,
                type: "gold-purchase",
                amount: amount.toString(),
                description: `Purchase of ${goldGrams.toFixed(6)} grams of gold`
              });
              
              console.log(`Updated gold investment for user ${userId}: +${goldGrams.toFixed(6)} grams`);
            }
            break;
            
          case 'subscription_schedule.completed':
            // Handle subscription management
            break;
            
          // Add more event handlers as needed
            
          default:
            console.log(`Unhandled event type: ${event.type}`);
        }
        
        res.status(200).send({ received: true });
      } catch (error) {
        console.error('Error processing webhook:', error);
        res.status(500).send({ error: 'Failed to process webhook' });
      }
    });
  }

  // Gamification System Routes
  
  // Streaks routes
  app.get('/api/streaks', authenticate, async (req, res) => {
    try {
      const streak = await storage.getStreakByUserId(req.user!.id);
      if (!streak) {
        // Create new streak for user
        const newStreak = await storage.createStreak({
          userId: req.user!.id,
          currentStreak: 0,
          longestStreak: 0,
          lastCheckIn: new Date(),
          streakFreezeUsed: false,
        });
        return res.json(newStreak);
      }
      res.json(streak);
    } catch (error) {
      console.error('Error getting streak:', error);
      res.status(500).json({ message: 'Failed to get streak information' });
    }
  });

  app.post('/api/streaks/check-in', authenticate, async (req, res) => {
    try {
      // Get current streak
      let streak = await storage.getStreakByUserId(req.user!.id);
      
      if (!streak) {
        // Create new streak for user
        streak = await storage.createStreak({
          userId: req.user!.id,
          currentStreak: 1, // First check-in
          longestStreak: 1,
          lastCheckIn: new Date(),
          streakFreezeUsed: false,
        });
        
        // Add points for first check-in
        await storage.addPoints(
          req.user!.id,
          10,
          'First check-in',
          'streak',
          null
        );
        
        return res.json({ 
          streak,
          message: 'Check-in successful! +10 points awarded.',
          pointsAwarded: 10
        });
      }
      
      // Check if already checked in today
      const lastCheckIn = new Date(streak.lastCheckIn);
      const today = new Date();
      
      if (
        lastCheckIn.getDate() === today.getDate() &&
        lastCheckIn.getMonth() === today.getMonth() &&
        lastCheckIn.getFullYear() === today.getFullYear()
      ) {
        return res.json({ 
          streak,
          message: 'You have already checked in today.',
          pointsAwarded: 0
        });
      }
      
      // Check if streak should continue or reset
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      
      const dayBeforeYesterday = new Date(today);
      dayBeforeYesterday.setDate(dayBeforeYesterday.getDate() - 2);
      
      let newCurrentStreak = streak.currentStreak;
      let pointsAwarded = 0;
      let streakFreezeUsed = false;
      let message = '';
      
      if (
        lastCheckIn.getDate() === yesterday.getDate() &&
        lastCheckIn.getMonth() === yesterday.getMonth() &&
        lastCheckIn.getFullYear() === yesterday.getFullYear()
      ) {
        // Checked in yesterday, continue streak
        newCurrentStreak += 1;
        pointsAwarded = 5 + Math.floor(newCurrentStreak / 5) * 5; // Base 5 points + 5 bonus every 5 days
        message = `Check-in successful! Your streak is now ${newCurrentStreak} days. +${pointsAwarded} points awarded.`;
      } 
      else if (
        lastCheckIn.getDate() === dayBeforeYesterday.getDate() &&
        lastCheckIn.getMonth() === dayBeforeYesterday.getMonth() &&
        lastCheckIn.getFullYear() === dayBeforeYesterday.getFullYear() &&
        !streak.streakFreezeUsed
      ) {
        // Missed one day but has streak freeze available
        newCurrentStreak += 1;
        streakFreezeUsed = true;
        pointsAwarded = 5;
        message = `Check-in successful! Your streak freeze was used to protect your streak. Your streak is now ${newCurrentStreak} days. +${pointsAwarded} points awarded.`;
      }
      else {
        // Streak broken
        newCurrentStreak = 1;
        pointsAwarded = 5;
        message = `Your streak has been reset. Your new streak is 1 day. +${pointsAwarded} points awarded.`;
      }
      
      // Update streak
      const newLongestStreak = Math.max(streak.longestStreak, newCurrentStreak);
      
      const updatedStreak = await storage.updateStreak(req.user!.id, {
        currentStreak: newCurrentStreak,
        longestStreak: newLongestStreak,
        lastCheckIn: new Date(),
        streakFreezeUsed: streakFreezeUsed,
      });
      
      // Add points
      if (pointsAwarded > 0) {
        await storage.addPoints(
          req.user!.id,
          pointsAwarded,
          `Streak check-in (day ${newCurrentStreak})`,
          'streak',
          null
        );
      }
      
      // Check for streak achievements
      if (newCurrentStreak >= 7) {
        // Check if user already has 7-day streak achievement
        const userAchievements = await storage.getUserAchievements(req.user!.id);
        const streak7Achievement = await storage.getAchievementsByCategory('streak')
          .then(achievements => achievements.find(a => a.name === 'Saving Streak 7'));
        
        if (streak7Achievement && !userAchievements.some(ua => ua.achievementId === streak7Achievement.id)) {
          await storage.unlockAchievement({
            userId: req.user!.id,
            achievementId: streak7Achievement.id,
            isNew: true
          });
          
          message += ` 🏆 Achievement unlocked: Saving Streak 7!`;
        }
      }
      
      if (newCurrentStreak >= 30) {
        // Check if user already has 30-day streak achievement
        const userAchievements = await storage.getUserAchievements(req.user!.id);
        const streak30Achievement = await storage.getAchievementsByCategory('streak')
          .then(achievements => achievements.find(a => a.name === 'Saving Streak 30'));
        
        if (streak30Achievement && !userAchievements.some(ua => ua.achievementId === streak30Achievement.id)) {
          await storage.unlockAchievement({
            userId: req.user!.id,
            achievementId: streak30Achievement.id,
            isNew: true
          });
          
          message += ` 🏆 Achievement unlocked: Saving Streak 30!`;
        }
      }
      
      res.json({ 
        streak: updatedStreak,
        message,
        pointsAwarded
      });
    } catch (error) {
      console.error('Error updating streak:', error);
      res.status(500).json({ message: 'Failed to update streak' });
    }
  });

  app.post('/api/streaks/buy-freeze', authenticate, async (req, res) => {
    try {
      // Get user's streak
      const streak = await storage.getStreakByUserId(req.user!.id);
      if (!streak) {
        return res.status(404).json({ message: 'No streak found' });
      }
      
      // Check if streak freeze is already active
      if (streak.streakFreezeUsed) {
        return res.status(400).json({ message: 'Streak freeze is already active' });
      }
      
      // Get user points
      const userPoints = await storage.getUserPointsById(req.user!.id);
      if (!userPoints) {
        return res.status(400).json({ message: 'No points available' });
      }
      
      // Check if user has enough points
      const streakFreezeReward = await storage.getActiveRewards()
        .then(rewards => rewards.find(r => r.name === 'Streak Freeze'));
      
      if (!streakFreezeReward) {
        return res.status(404).json({ message: 'Streak freeze reward not found' });
      }
      
      if (userPoints.availablePoints < streakFreezeReward.cost) {
        return res.status(400).json({ 
          message: `Not enough points. Streak freeze costs ${streakFreezeReward.cost} points.`,
          currentPoints: userPoints.availablePoints,
          requiredPoints: streakFreezeReward.cost
        });
      }
      
      // Redeem reward
      await storage.redeemReward({
        userId: req.user!.id,
        rewardId: streakFreezeReward.id,
        status: 'claimed'
      });
      
      // Update streak
      const updatedStreak = await storage.updateStreak(req.user!.id, {
        streakFreezeUsed: false // Keep it false until actually used during a check-in
      });
      
      res.json({
        message: 'Streak freeze purchased successfully! It will be applied automatically when you miss a day.',
        streak: updatedStreak,
        pointsRemaining: userPoints.availablePoints - streakFreezeReward.cost
      });
    } catch (error) {
      console.error('Error buying streak freeze:', error);
      res.status(500).json({ message: 'Failed to purchase streak freeze' });
    }
  });

  // Achievements routes
  app.get('/api/achievements', authenticate, async (req, res) => {
    try {
      // Get all achievements
      const allAchievements = await storage.getAllAchievements();
      
      // Get user's unlocked achievements
      const userAchievements = await storage.getUserAchievements(req.user!.id);
      
      // Map achievements with unlocked status
      const achievements = allAchievements.map(achievement => {
        const userAchievement = userAchievements.find(ua => ua.achievementId === achievement.id);
        return {
          ...achievement,
          unlocked: !!userAchievement,
          unlockedAt: userAchievement?.unlockedAt || null,
          isNew: userAchievement?.isNew || false,
          hidden: achievement.isHidden && !userAchievement // Hide secret achievements until unlocked
        };
      });
      
      res.json(achievements);
    } catch (error) {
      console.error('Error getting achievements:', error);
      res.status(500).json({ message: 'Failed to get achievements' });
    }
  });

  app.post('/api/achievements/:id/mark-seen', authenticate, async (req, res) => {
    try {
      const achievementId = parseInt(req.params.id);
      
      // Verify achievement exists
      const achievement = await storage.getAchievementById(achievementId);
      if (!achievement) {
        return res.status(404).json({ message: 'Achievement not found' });
      }
      
      // Verify user has unlocked this achievement
      const userAchievement = await storage.getUserAchievementById(req.user!.id, achievementId);
      if (!userAchievement) {
        return res.status(400).json({ message: 'Achievement not unlocked by user' });
      }
      
      // Mark as seen
      await storage.markAchievementAsSeen(req.user!.id, achievementId);
      
      res.json({ message: 'Achievement marked as seen' });
    } catch (error) {
      console.error('Error marking achievement as seen:', error);
      res.status(500).json({ message: 'Failed to mark achievement as seen' });
    }
  });

  // Rewards routes
  app.get('/api/rewards', authenticate, async (req, res) => {
    try {
      // Get active rewards
      const activeRewards = await storage.getActiveRewards();
      
      // Get user points
      const userPoints = await storage.getUserPointsById(req.user!.id);
      
      // Map rewards with availability based on points
      const rewards = activeRewards.map(reward => ({
        ...reward,
        canAfford: userPoints ? userPoints.availablePoints >= reward.cost : false
      }));
      
      res.json({
        rewards,
        userPoints: userPoints || { totalPoints: 0, availablePoints: 0 }
      });
    } catch (error) {
      console.error('Error getting rewards:', error);
      res.status(500).json({ message: 'Failed to get rewards' });
    }
  });

  app.get('/api/rewards/my', authenticate, async (req, res) => {
    try {
      // Get user's redeemed rewards
      const userRewards = await storage.getUserRewards(req.user!.id);
      
      res.json(userRewards);
    } catch (error) {
      console.error('Error getting user rewards:', error);
      res.status(500).json({ message: 'Failed to get user rewards' });
    }
  });

  app.post('/api/rewards/:id/redeem', authenticate, async (req, res) => {
    try {
      const rewardId = parseInt(req.params.id);
      
      // Verify reward exists and is active
      const reward = await storage.getRewardById(rewardId);
      if (!reward || !reward.isActive) {
        return res.status(404).json({ message: 'Reward not found or not active' });
      }
      
      // Verify user has enough points
      const userPoints = await storage.getUserPointsById(req.user!.id);
      if (!userPoints || userPoints.availablePoints < reward.cost) {
        return res.status(400).json({ 
          message: 'Not enough points',
          currentPoints: userPoints?.availablePoints || 0,
          requiredPoints: reward.cost 
        });
      }
      
      // Redeem reward
      const userReward = await storage.redeemReward({
        userId: req.user!.id,
        rewardId: reward.id,
        status: 'pending'
      });
      
      // Handle special rewards processing
      if (reward.type === 'feature' && reward.name === 'Streak Freeze') {
        // Apply streak freeze
        const streak = await storage.getStreakByUserId(req.user!.id);
        if (streak) {
          await storage.updateStreak(req.user!.id, {
            streakFreezeUsed: false // Keep it false until actually used
          });
          
          // Mark as claimed
          await storage.updateUserRewardStatus(userReward.id, 'claimed');
        }
      }
      
      res.json({ 
        message: 'Reward redeemed successfully',
        userReward,
        pointsRemaining: userPoints.availablePoints - reward.cost
      });
    } catch (error) {
      console.error('Error redeeming reward:', error);
      res.status(500).json({ message: 'Failed to redeem reward' });
    }
  });

  // Points routes
  app.get('/api/points', authenticate, async (req, res) => {
    try {
      // Get user points
      let userPoints = await storage.getUserPointsById(req.user!.id);
      
      if (!userPoints) {
        userPoints = await storage.createUserPoints({
          userId: req.user!.id,
          totalPoints: 0,
          availablePoints: 0
        });
      }
      
      // Get recent point transactions
      const recentTransactions = await storage.getPointTransactionsByUserId(req.user!.id, 10);
      
      res.json({
        points: userPoints,
        recentTransactions
      });
    } catch (error) {
      console.error('Error getting user points:', error);
      res.status(500).json({ message: 'Failed to get user points' });
    }
  });
  
  // AI-powered savings recommendations route
  app.get('/api/savings/recommendations', authenticate, async (req, res) => {
    try {
      // Sample recommendations for demo purposes
      // In production, this would use the AI service to analyze spending patterns
      const recommendations = [
        {
          id: "rec-001",
          title: "Optimize Subscription Services",
          description: "You're paying for multiple streaming services. Consider rotating subscriptions - use one service for a month, then switch.",
          potentialSavings: 1200,
          difficulty: 'easy',
          category: 'subscription',
          implementationSteps: [
            "List all your current subscriptions and their monthly costs",
            "Identify which ones you use least frequently",
            "Cancel subscriptions you rarely use",
            "For remaining ones, consider rotating usage on a monthly basis"
          ]
        },
        {
          id: "rec-002",
          title: "Reduce Food Delivery",
          description: "You spent ₹4,500 on food delivery last month. Cutting this by half could lead to significant savings.",
          potentialSavings: 2250,
          difficulty: 'medium',
          category: 'food',
          implementationSteps: [
            "Plan meals in advance each week",
            "Prepare and store meals in batches",
            "Limit food delivery to once a week",
            "Use delivery app coupons and offers when you do order"
          ]
        },
        {
          id: "rec-003",
          title: "Smart Energy Use",
          description: "Your utility bills are higher than average. Smart power management can reduce these costs.",
          potentialSavings: 850,
          difficulty: 'easy',
          category: 'utilities',
          implementationSteps: [
            "Switch to LED lights throughout your home",
            "Unplug electronics when not in use",
            "Use power strips for easy management",
            "Set your AC to energy-saving temperatures"
          ]
        },
        {
          id: "rec-004",
          title: "Low-Cost Entertainment",
          description: "You could replace some paid entertainment with free or low-cost alternatives.",
          potentialSavings: 1800,
          difficulty: 'medium',
          category: 'entertainment',
          implementationSteps: [
            "Research free events in your city",
            "Explore public libraries for books, movies, and events",
            "Try free trials of different services instead of subscribing",
            "Look for student or professional discounts on entertainment"
          ]
        }
      ];
      
      res.json(recommendations);
    } catch (error) {
      console.error('Error getting savings recommendations:', error);
      res.status(500).json({ message: 'Failed to retrieve savings recommendations' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
