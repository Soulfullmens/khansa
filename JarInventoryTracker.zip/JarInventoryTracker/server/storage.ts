import {
  users, investments, goals, transactions, goldPrices, insights,
  streaks, achievements, userAchievements, rewards, userRewards, userPoints, pointTransactions,
  type User, type InsertUser,
  type Investment, type InsertInvestment,
  type Goal, type InsertGoal,
  type Transaction, type InsertTransaction,
  type GoldPrice, type InsertGoldPrice,
  type Insight, type InsertInsight,
  type Streak, type InsertStreak,
  type Achievement, type InsertAchievement,
  type UserAchievement, type InsertUserAchievement,
  type Reward, type InsertReward,
  type UserReward, type InsertUserReward,
  type UserPoints, type InsertUserPoints,
  type PointTransaction, type InsertPointTransaction
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateStripeCustomerId(userId: number, customerId: string): Promise<User | undefined>;
  updateUserStripeInfo(userId: number, stripeInfo: { customerId: string, subscriptionId: string, status?: string, tier?: string }): Promise<User | undefined>;
  setResetToken(userId: number, token: string, expires: Date): Promise<boolean>;
  getUserByResetToken(token: string): Promise<User | undefined>;
  updatePassword(userId: number, password: string): Promise<boolean>;
  
  // Investments
  getInvestmentByUserId(userId: number): Promise<Investment | undefined>;
  createInvestment(investment: InsertInvestment): Promise<Investment>;
  updateInvestment(id: number, investment: Partial<InsertInvestment>): Promise<Investment | undefined>;
  
  // Goals
  getGoalsByUserId(userId: number): Promise<Goal[]>;
  getGoalById(id: number): Promise<Goal | undefined>;
  createGoal(goal: InsertGoal): Promise<Goal>;
  updateGoal(id: number, goal: Partial<InsertGoal>): Promise<Goal | undefined>;
  deleteGoal(id: number): Promise<boolean>;
  
  // Transactions
  getTransactionsByUserId(userId: number, limit?: number): Promise<Transaction[]>;
  getTransactionById(id: number): Promise<Transaction | undefined>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  
  // Gold Prices
  getLatestGoldPrice(): Promise<GoldPrice | undefined>;
  createGoldPrice(goldPrice: InsertGoldPrice): Promise<GoldPrice>;
  
  // Insights
  getInsightsByUserId(userId: number): Promise<Insight[]>;
  createInsight(insight: InsertInsight): Promise<Insight>;
  markInsightAsRead(id: number): Promise<boolean>;
  
  // Streaks
  getStreakByUserId(userId: number): Promise<Streak | undefined>;
  createStreak(streak: InsertStreak): Promise<Streak>;
  updateStreak(userId: number, streak: Partial<InsertStreak>): Promise<Streak | undefined>;
  
  // Achievements
  getAllAchievements(): Promise<Achievement[]>;
  getAchievementById(id: number): Promise<Achievement | undefined>;
  getAchievementsByCategory(category: string): Promise<Achievement[]>;
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;
  
  // User Achievements
  getUserAchievements(userId: number): Promise<(UserAchievement & { achievement: Achievement })[]>;
  getUserAchievementById(userId: number, achievementId: number): Promise<UserAchievement | undefined>;
  unlockAchievement(userAchievement: InsertUserAchievement): Promise<UserAchievement>;
  markAchievementAsSeen(userId: number, achievementId: number): Promise<boolean>;
  
  // Rewards
  getAllRewards(): Promise<Reward[]>;
  getActiveRewards(): Promise<Reward[]>;
  getRewardById(id: number): Promise<Reward | undefined>;
  createReward(reward: InsertReward): Promise<Reward>;
  updateReward(id: number, reward: Partial<InsertReward>): Promise<Reward | undefined>;
  
  // User Rewards
  getUserRewards(userId: number): Promise<(UserReward & { reward: Reward })[]>;
  getUserRewardById(id: number): Promise<(UserReward & { reward: Reward }) | undefined>;
  redeemReward(userReward: InsertUserReward): Promise<UserReward>;
  updateUserRewardStatus(id: number, status: string): Promise<boolean>;
  
  // User Points
  getUserPointsById(userId: number): Promise<UserPoints | undefined>;
  createUserPoints(userPoints: InsertUserPoints): Promise<UserPoints>;
  updateUserPoints(userId: number, points: { totalPoints?: number, availablePoints?: number }): Promise<UserPoints | undefined>;
  addPoints(userId: number, amount: number, description: string, source: string, sourceId?: number): Promise<UserPoints>;
  deductPoints(userId: number, amount: number, description: string, source: string, sourceId?: number): Promise<UserPoints>;
  
  // Point Transactions
  getPointTransactionsByUserId(userId: number, limit?: number): Promise<PointTransaction[]>;
  createPointTransaction(transaction: InsertPointTransaction): Promise<PointTransaction>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private investments: Map<number, Investment>;
  private goals: Map<number, Goal>;
  private transactions: Map<number, Transaction>;
  private goldPrices: Map<number, GoldPrice>;
  private insights: Map<number, Insight>;
  private streaks: Map<number, Streak>;
  private achievements: Map<number, Achievement>;
  private userAchievements: Map<number, UserAchievement>;
  private rewards: Map<number, Reward>;
  private userRewards: Map<number, UserReward>;
  private userPoints: Map<number, UserPoints>;
  private pointTransactions: Map<number, PointTransaction>;
  
  private userIdCounter: number;
  private investmentIdCounter: number;
  private goalIdCounter: number;
  private transactionIdCounter: number;
  private goldPriceIdCounter: number;
  private insightIdCounter: number;
  private streakIdCounter: number;
  private achievementIdCounter: number;
  private userAchievementIdCounter: number;
  private rewardIdCounter: number;
  private userRewardIdCounter: number;
  private userPointsIdCounter: number;
  private pointTransactionIdCounter: number;

  constructor() {
    this.users = new Map();
    this.investments = new Map();
    this.goals = new Map();
    this.transactions = new Map();
    this.goldPrices = new Map();
    this.insights = new Map();
    this.streaks = new Map();
    this.achievements = new Map();
    this.userAchievements = new Map();
    this.rewards = new Map();
    this.userRewards = new Map();
    this.userPoints = new Map();
    this.pointTransactions = new Map();
    
    this.userIdCounter = 1;
    this.investmentIdCounter = 1;
    this.goalIdCounter = 1;
    this.transactionIdCounter = 1;
    this.goldPriceIdCounter = 1;
    this.insightIdCounter = 1;
    this.streakIdCounter = 1;
    this.achievementIdCounter = 1;
    this.userAchievementIdCounter = 1;
    this.rewardIdCounter = 1;
    this.userRewardIdCounter = 1;
    this.userPointsIdCounter = 1;
    this.pointTransactionIdCounter = 1;
    
    // Seed data for demo purposes
    this.seedGoldPrices();
    this.seedAchievements();
    this.seedRewards();
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async getUserByResetToken(token: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => (user as any).resetToken === token && (user as any).resetTokenExpires > new Date(),
    );
  }

  async setResetToken(userId: number, token: string, expires: Date): Promise<boolean> {
    const user = this.users.get(userId);
    if (!user) return false;
    
    const updatedUser = {
      ...user,
      resetToken: token,
      resetTokenExpires: expires
    };
    
    this.users.set(userId, updatedUser as User);
    return true;
  }

  async updatePassword(userId: number, password: string): Promise<boolean> {
    const user = this.users.get(userId);
    if (!user) return false;
    
    const updatedUser = {
      ...user,
      password,
      resetToken: null,
      resetTokenExpires: null
    };
    
    this.users.set(userId, updatedUser as User);
    return true;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const createdAt = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      userLevel: "Gold Saver",
      createdAt,
      resetToken: null,
      resetTokenExpires: null,
      subscriptionStatus: "none",
      subscriptionTier: "free",
      stripeCustomerId: null,
      stripeSubscriptionId: null,
      profileImage: insertUser.profileImage || null
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateStripeCustomerId(userId: number, customerId: string): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      stripeCustomerId: customerId
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async updateUserStripeInfo(userId: number, stripeInfo: { customerId: string, subscriptionId: string, status?: string, tier?: string }): Promise<User | undefined> {
    const user = this.users.get(userId);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      stripeCustomerId: stripeInfo.customerId,
      stripeSubscriptionId: stripeInfo.subscriptionId,
      subscriptionStatus: stripeInfo.status || "active",
      subscriptionTier: stripeInfo.tier || "premium"
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  // Investments
  async getInvestmentByUserId(userId: number): Promise<Investment | undefined> {
    return Array.from(this.investments.values()).find(
      (investment) => investment.userId === userId,
    );
  }

  async createInvestment(insertInvestment: InsertInvestment): Promise<Investment> {
    const id = this.investmentIdCounter++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const investment: Investment = { 
      ...insertInvestment, 
      id, 
      createdAt, 
      updatedAt,
      otherInvestments: insertInvestment.otherInvestments || null
    };
    this.investments.set(id, investment);
    return investment;
  }

  async updateInvestment(id: number, partialInvestment: Partial<InsertInvestment>): Promise<Investment | undefined> {
    const investment = this.investments.get(id);
    if (!investment) return undefined;

    const updatedInvestment: Investment = {
      ...investment,
      ...partialInvestment,
      updatedAt: new Date()
    };
    this.investments.set(id, updatedInvestment);
    return updatedInvestment;
  }

  // Goals
  async getGoalsByUserId(userId: number): Promise<Goal[]> {
    return Array.from(this.goals.values()).filter(
      (goal) => goal.userId === userId,
    );
  }

  async getGoalById(id: number): Promise<Goal | undefined> {
    return this.goals.get(id);
  }

  async createGoal(insertGoal: InsertGoal): Promise<Goal> {
    const id = this.goalIdCounter++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const goal: Goal = { ...insertGoal, id, createdAt, updatedAt };
    this.goals.set(id, goal);
    return goal;
  }

  async updateGoal(id: number, partialGoal: Partial<InsertGoal>): Promise<Goal | undefined> {
    const goal = this.goals.get(id);
    if (!goal) return undefined;

    const updatedGoal: Goal = {
      ...goal,
      ...partialGoal,
      updatedAt: new Date()
    };
    this.goals.set(id, updatedGoal);
    return updatedGoal;
  }

  async deleteGoal(id: number): Promise<boolean> {
    return this.goals.delete(id);
  }

  // Transactions
  async getTransactionsByUserId(userId: number, limit?: number): Promise<Transaction[]> {
    const userTransactions = Array.from(this.transactions.values())
      .filter((transaction) => transaction.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    return limit ? userTransactions.slice(0, limit) : userTransactions;
  }

  async getTransactionById(id: number): Promise<Transaction | undefined> {
    return this.transactions.get(id);
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = this.transactionIdCounter++;
    const createdAt = new Date();
    const transaction: Transaction = { 
      ...insertTransaction, 
      id, 
      createdAt,
      description: insertTransaction.description || null, 
      goalId: insertTransaction.goalId || null
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  // Gold Prices
  async getLatestGoldPrice(): Promise<GoldPrice | undefined> {
    // Return the most recent gold price
    const goldPriceArray = Array.from(this.goldPrices.values());
    if (goldPriceArray.length === 0) return undefined;
    
    return goldPriceArray.reduce((latest, current) => {
      return current.updatedAt > latest.updatedAt ? current : latest;
    });
  }

  async createGoldPrice(insertGoldPrice: InsertGoldPrice): Promise<GoldPrice> {
    const id = this.goldPriceIdCounter++;
    const updatedAt = new Date();
    const goldPrice: GoldPrice = { ...insertGoldPrice, id, updatedAt };
    this.goldPrices.set(id, goldPrice);
    return goldPrice;
  }

  // Insights
  async getInsightsByUserId(userId: number): Promise<Insight[]> {
    return Array.from(this.insights.values())
      .filter((insight) => insight.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createInsight(insertInsight: InsertInsight): Promise<Insight> {
    const id = this.insightIdCounter++;
    const createdAt = new Date();
    const insight: Insight = { ...insertInsight, id, isRead: false, createdAt };
    this.insights.set(id, insight);
    return insight;
  }

  async markInsightAsRead(id: number): Promise<boolean> {
    const insight = this.insights.get(id);
    if (!insight) return false;

    const updatedInsight: Insight = {
      ...insight,
      isRead: true
    };
    this.insights.set(id, updatedInsight);
    return true;
  }

  // Streaks
  async getStreakByUserId(userId: number): Promise<Streak | undefined> {
    return Array.from(this.streaks.values()).find(
      (streak) => streak.userId === userId,
    );
  }

  async createStreak(insertStreak: InsertStreak): Promise<Streak> {
    const id = this.streakIdCounter++;
    const updatedAt = new Date();
    const streak: Streak = { 
      ...insertStreak, 
      id, 
      updatedAt 
    };
    this.streaks.set(id, streak);
    return streak;
  }

  async updateStreak(userId: number, partialStreak: Partial<InsertStreak>): Promise<Streak | undefined> {
    const streak = Array.from(this.streaks.values()).find(s => s.userId === userId);
    if (!streak) return undefined;

    const updatedStreak: Streak = {
      ...streak,
      ...partialStreak,
      updatedAt: new Date()
    };
    this.streaks.set(streak.id, updatedStreak);
    return updatedStreak;
  }

  // Achievements
  async getAllAchievements(): Promise<Achievement[]> {
    return Array.from(this.achievements.values());
  }

  async getAchievementById(id: number): Promise<Achievement | undefined> {
    return this.achievements.get(id);
  }

  async getAchievementsByCategory(category: string): Promise<Achievement[]> {
    return Array.from(this.achievements.values()).filter(
      (achievement) => achievement.category === category,
    );
  }

  async createAchievement(insertAchievement: InsertAchievement): Promise<Achievement> {
    const id = this.achievementIdCounter++;
    const achievement: Achievement = { ...insertAchievement, id };
    this.achievements.set(id, achievement);
    return achievement;
  }

  // User Achievements
  async getUserAchievements(userId: number): Promise<(UserAchievement & { achievement: Achievement })[]> {
    const userAchievementsArray = Array.from(this.userAchievements.values())
      .filter((ua) => ua.userId === userId);
    
    return userAchievementsArray.map(ua => {
      const achievement = this.achievements.get(ua.achievementId);
      if (!achievement) throw new Error(`Achievement ${ua.achievementId} not found`);
      return { ...ua, achievement };
    });
  }

  async getUserAchievementById(userId: number, achievementId: number): Promise<UserAchievement | undefined> {
    return Array.from(this.userAchievements.values()).find(
      (ua) => ua.userId === userId && ua.achievementId === achievementId,
    );
  }

  async unlockAchievement(insertUserAchievement: InsertUserAchievement): Promise<UserAchievement> {
    const id = this.userAchievementIdCounter++;
    const unlockedAt = new Date();
    const userAchievement: UserAchievement = { 
      ...insertUserAchievement, 
      id, 
      unlockedAt,
      isNew: insertUserAchievement.isNew ?? true
    };
    this.userAchievements.set(id, userAchievement);
    
    // Also add points for the achievement
    const achievement = this.achievements.get(userAchievement.achievementId);
    if (achievement) {
      await this.addPoints(
        userAchievement.userId, 
        achievement.pointsAwarded, 
        `Unlocked achievement: ${achievement.name}`, 
        'achievement', 
        achievement.id
      );
    }
    
    return userAchievement;
  }

  async markAchievementAsSeen(userId: number, achievementId: number): Promise<boolean> {
    const userAchievement = Array.from(this.userAchievements.values()).find(
      (ua) => ua.userId === userId && ua.achievementId === achievementId,
    );
    
    if (!userAchievement) return false;

    const updatedUserAchievement: UserAchievement = {
      ...userAchievement,
      isNew: false
    };
    this.userAchievements.set(userAchievement.id, updatedUserAchievement);
    return true;
  }

  // Rewards
  async getAllRewards(): Promise<Reward[]> {
    return Array.from(this.rewards.values());
  }

  async getActiveRewards(): Promise<Reward[]> {
    const now = new Date();
    return Array.from(this.rewards.values()).filter(
      (reward) => reward.isActive && (!reward.expiresAt || reward.expiresAt > now),
    );
  }

  async getRewardById(id: number): Promise<Reward | undefined> {
    return this.rewards.get(id);
  }

  async createReward(insertReward: InsertReward): Promise<Reward> {
    const id = this.rewardIdCounter++;
    const reward: Reward = { 
      ...insertReward, 
      id,
      expiresAt: insertReward.expiresAt || null
    };
    this.rewards.set(id, reward);
    return reward;
  }

  async updateReward(id: number, partialReward: Partial<InsertReward>): Promise<Reward | undefined> {
    const reward = this.rewards.get(id);
    if (!reward) return undefined;

    const updatedReward: Reward = {
      ...reward,
      ...partialReward,
      expiresAt: partialReward.expiresAt ?? reward.expiresAt
    };
    this.rewards.set(id, updatedReward);
    return updatedReward;
  }

  // User Rewards
  async getUserRewards(userId: number): Promise<(UserReward & { reward: Reward })[]> {
    const userRewardsArray = Array.from(this.userRewards.values())
      .filter((ur) => ur.userId === userId);
    
    return userRewardsArray.map(ur => {
      const reward = this.rewards.get(ur.rewardId);
      if (!reward) throw new Error(`Reward ${ur.rewardId} not found`);
      return { ...ur, reward };
    });
  }

  async getUserRewardById(id: number): Promise<(UserReward & { reward: Reward }) | undefined> {
    const userReward = this.userRewards.get(id);
    if (!userReward) return undefined;
    
    const reward = this.rewards.get(userReward.rewardId);
    if (!reward) return undefined;
    
    return { ...userReward, reward };
  }

  async redeemReward(insertUserReward: InsertUserReward): Promise<UserReward> {
    const id = this.userRewardIdCounter++;
    const redeemedAt = new Date();
    const userReward: UserReward = { 
      ...insertUserReward, 
      id, 
      redeemedAt,
      status: insertUserReward.status || 'pending'
    };
    this.userRewards.set(id, userReward);
    
    // Deduct points
    const reward = this.rewards.get(userReward.rewardId);
    if (reward) {
      await this.deductPoints(
        userReward.userId, 
        reward.cost, 
        `Redeemed reward: ${reward.name}`, 
        'reward', 
        reward.id
      );
    }
    
    return userReward;
  }

  async updateUserRewardStatus(id: number, status: string): Promise<boolean> {
    const userReward = this.userRewards.get(id);
    if (!userReward) return false;

    const updatedUserReward: UserReward = {
      ...userReward,
      status
    };
    this.userRewards.set(id, updatedUserReward);
    return true;
  }

  // User Points
  async getUserPointsById(userId: number): Promise<UserPoints | undefined> {
    return Array.from(this.userPoints.values()).find(
      (up) => up.userId === userId,
    );
  }

  async createUserPoints(insertUserPoints: InsertUserPoints): Promise<UserPoints> {
    const id = this.userPointsIdCounter++;
    const updatedAt = new Date();
    const userPoints: UserPoints = { 
      ...insertUserPoints, 
      id, 
      updatedAt 
    };
    this.userPoints.set(id, userPoints);
    return userPoints;
  }

  async updateUserPoints(userId: number, points: { totalPoints?: number, availablePoints?: number }): Promise<UserPoints | undefined> {
    let userPoints = await this.getUserPointsById(userId);
    
    if (!userPoints) {
      userPoints = await this.createUserPoints({ 
        userId, 
        totalPoints: 0, 
        availablePoints: 0 
      });
    }

    const updatedUserPoints: UserPoints = {
      ...userPoints,
      totalPoints: points.totalPoints !== undefined ? points.totalPoints : userPoints.totalPoints,
      availablePoints: points.availablePoints !== undefined ? points.availablePoints : userPoints.availablePoints,
      updatedAt: new Date()
    };
    
    this.userPoints.set(userPoints.id, updatedUserPoints);
    return updatedUserPoints;
  }

  async addPoints(userId: number, amount: number, description: string, source: string, sourceId?: number): Promise<UserPoints> {
    // Get or create user points
    let userPoints = await this.getUserPointsById(userId);
    
    if (!userPoints) {
      userPoints = await this.createUserPoints({ 
        userId, 
        totalPoints: 0, 
        availablePoints: 0 
      });
    }
    
    // Update points
    const updatedUserPoints = await this.updateUserPoints(userId, {
      totalPoints: userPoints.totalPoints + amount,
      availablePoints: userPoints.availablePoints + amount
    });
    
    // Create transaction record
    await this.createPointTransaction({
      userId,
      amount,
      description,
      source,
      sourceId: sourceId || null
    });
    
    return updatedUserPoints!;
  }

  async deductPoints(userId: number, amount: number, description: string, source: string, sourceId?: number): Promise<UserPoints> {
    // Get user points
    const userPoints = await this.getUserPointsById(userId);
    
    if (!userPoints) {
      throw new Error('User has no points account');
    }
    
    if (userPoints.availablePoints < amount) {
      throw new Error('Insufficient points');
    }
    
    // Update points (deduct)
    const updatedUserPoints = await this.updateUserPoints(userId, {
      availablePoints: userPoints.availablePoints - amount
    });
    
    // Create transaction record with negative amount
    await this.createPointTransaction({
      userId,
      amount: -amount, // Negative amount for deductions
      description,
      source,
      sourceId: sourceId || null
    });
    
    return updatedUserPoints!;
  }

  // Point Transactions
  async getPointTransactionsByUserId(userId: number, limit?: number): Promise<PointTransaction[]> {
    const userPointTransactions = Array.from(this.pointTransactions.values())
      .filter((pt) => pt.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    return limit ? userPointTransactions.slice(0, limit) : userPointTransactions;
  }

  async createPointTransaction(insertPointTransaction: InsertPointTransaction): Promise<PointTransaction> {
    const id = this.pointTransactionIdCounter++;
    const createdAt = new Date();
    const pointTransaction: PointTransaction = { 
      ...insertPointTransaction, 
      id, 
      createdAt,
      sourceId: insertPointTransaction.sourceId || null
    };
    this.pointTransactions.set(id, pointTransaction);
    return pointTransaction;
  }

  // Seed data for demo purposes
  private seedGoldPrices() {
    // Create sample gold price with history data
    const priceHistory = [];
    const today = new Date();
    
    // Generate 30 days of price history
    for (let i = 29; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      
      // Base price with some randomness
      const basePrice = 5500 + Math.random() * 500;
      priceHistory.push({
        date: date.toISOString().split('T')[0],
        price: parseFloat(basePrice.toFixed(2))
      });
    }
    
    this.createGoldPrice({
      pricePerGram: "5843.75",
      change24h: "0.8",
      change7d: "1.4",
      change30d: "2.5",
      priceHistory
    });
  }
  
  private seedAchievements() {
    // Create sample achievements
    const achievements = [
      {
        name: "First Gold Purchase",
        description: "Buy gold for the first time",
        icon: "trophy-star",
        category: "investment",
        level: 1,
        pointsAwarded: 100,
        isHidden: false
      },
      {
        name: "Saving Streak 7",
        description: "Log into the app for 7 days in a row",
        icon: "flame",
        category: "streak",
        level: 1,
        pointsAwarded: 50,
        isHidden: false
      },
      {
        name: "Saving Streak 30",
        description: "Log into the app for 30 days in a row",
        icon: "flame-double",
        category: "streak",
        level: 2,
        pointsAwarded: 200,
        isHidden: false
      },
      {
        name: "Goal Setter",
        description: "Create your first savings goal",
        icon: "target",
        category: "goals",
        level: 1,
        pointsAwarded: 50,
        isHidden: false
      },
      {
        name: "Goal Achiever",
        description: "Complete a savings goal",
        icon: "crown",
        category: "goals",
        level: 2,
        pointsAwarded: 150,
        isHidden: false
      },
      {
        name: "Portfolio Builder",
        description: "Invest in at least 3 different assets",
        icon: "briefcase",
        category: "investment",
        level: 2,
        pointsAwarded: 150,
        isHidden: false
      },
      {
        name: "Smart Saver",
        description: "Follow a smart savings recommendation",
        icon: "lightbulb",
        category: "savings",
        level: 1,
        pointsAwarded: 75,
        isHidden: false
      },
      {
        name: "Round-Up Master",
        description: "Save ₹1000 using round-up transactions",
        icon: "coins",
        category: "savings",
        level: 2,
        pointsAwarded: 100,
        isHidden: false
      },
      {
        name: "Hidden Achievement",
        description: "This is a secret achievement. Complete certain actions to unlock it!",
        icon: "question-mark",
        category: "secret",
        level: 3,
        pointsAwarded: 300,
        isHidden: true
      }
    ];
    
    achievements.forEach(achievement => {
      this.createAchievement(achievement);
    });
  }
  
  private seedRewards() {
    // Create sample rewards
    const rewards = [
      {
        name: "Premium Account (1 Month)",
        description: "Get 1 month of premium account access",
        icon: "diamond",
        cost: 500,
        type: "subscription",
        isActive: true,
        expiresAt: null
      },
      {
        name: "Streak Freeze",
        description: "Protect your streak for one day when you miss a check-in",
        icon: "snowflake",
        cost: 100,
        type: "feature",
        isActive: true,
        expiresAt: null
      },
      {
        name: "Investment Report",
        description: "Get a detailed report on your investment performance",
        icon: "chart-line-up",
        cost: 250,
        type: "digital",
        isActive: true,
        expiresAt: null
      },
      {
        name: "No Transaction Fees",
        description: "No transaction fees on your next purchase",
        icon: "wallet",
        cost: 200,
        type: "discount",
        isActive: true,
        expiresAt: null
      },
      {
        name: "Custom Avatar",
        description: "Unlock custom avatars for your profile",
        icon: "user-square",
        cost: 150,
        type: "feature",
        isActive: true,
        expiresAt: null
      },
      {
        name: "Financial Consultation",
        description: "30-minute financial consultation with an expert",
        icon: "briefcase",
        cost: 1000,
        type: "service",
        isActive: true,
        expiresAt: null
      }
    ];
    
    rewards.forEach(reward => {
      this.createReward(reward);
    });
  }
}

export const storage = new MemStorage();
