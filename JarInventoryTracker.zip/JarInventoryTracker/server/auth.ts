import { Express, Request, Response, NextFunction } from "express";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SchemaUser } from "@shared/schema";

// Define User interface for Express Request
declare global {
  namespace Express {
    interface User {
      id: number;
      username: string;
      password: string;
      name: string;
      profileImage?: string | null;
    }
  }
}

const scryptAsync = promisify(scrypt);

// Password hashing functions
export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

// Setup authentication middleware
export function setupAuth(app: Express) {
  // Authentication routes
  app.post("/api/register", async (req, res) => {
    try {
      const { username, password, name, email } = req.body;
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Hash password
      const hashedPassword = await hashPassword(password);
      
      // Create user
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
        name
      });
      
      // Initialize user's investment portfolio
      await storage.createInvestment({
        userId: user.id,
        goldAmount: "0",
        goldValue: "0",
        otherInvestments: "0",
        totalValue: "0"
      });
      
      // Create session
      if (!req.session) {
        console.error("Session middleware not properly initialized");
        return res.status(500).json({ message: "Internal server error with session management" });
      }
      
      // Save user ID to session
      req.session.userId = user.id;
      
      // Ensure session is saved before responding
      req.session.save((err) => {
        if (err) {
          console.error("Session save error:", err);
          return res.status(500).json({ message: "Failed to create user session" });
        }
        
        // Return user without password
        const { password, ...userWithoutPassword } = user;
        res.status(201).json(userWithoutPassword);
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Failed to register user" });
    }
  });

  app.post("/api/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // Validate input
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      // Get user
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Verify password
      const isPasswordValid = await comparePasswords(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Validate session exists
      if (!req.session) {
        console.error("Session middleware not properly initialized");
        return res.status(500).json({ message: "Internal server error with session management" });
      }
      
      // Create session
      req.session.userId = user.id;
      
      // Ensure session is saved before responding
      req.session.save((err) => {
        if (err) {
          console.error("Session save error:", err);
          return res.status(500).json({ message: "Failed to create user session" });
        }
        
        // Return user without password
        const { password, ...userWithoutPassword } = user;
        res.json(userWithoutPassword);
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Failed to login" });
    }
  });

  app.post("/api/logout", (req, res) => {
    req.session?.destroy((err) => {
      if (err) {
        console.error("Logout error:", err);
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/user", async (req, res) => {
    try {
      const userId = req.session?.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Return user without password
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("User fetch error:", error);
      res.status(500).json({ message: "Failed to fetch user data" });
    }
  });

  // Authentication middleware for protected routes
  app.use("/api", (req: Request, res: Response, next: NextFunction) => {
    // Skip auth check for authentication endpoints and public routes
    if (
      req.path === "/login" ||
      req.path === "/register" ||
      req.path === "/logout" ||
      req.path === "/user" || 
      req.path === "/gold/price"
    ) {
      return next();
    }
    
    const userId = req.session?.userId;
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    next();
  });
}

// Middleware to attach user to request object
export async function attachUserToRequest(req: Request, res: Response, next: NextFunction) {
  try {
    const userId = req.session?.userId;
    if (userId) {
      const user = await storage.getUser(userId);
      if (user) {
        req.user = user;
      }
    }
    next();
  } catch (error) {
    console.error("User attachment error:", error);
    next();
  }
}