// This service will integrate with a real gold price API
// For production, we would use a proper API like the World Gold Council API, 
// Gold API, or Metals-API for real-time gold prices

import { storage } from './storage';

// Constants
const GOLD_PRICE_UPDATE_INTERVAL = 30 * 60 * 1000; // 30 minutes in milliseconds
const BASE_PRICE = 5500; // Base price in INR per gram for 24k gold (if API fails)

// Last time we fetched gold price from API
let lastFetchTime = 0;
let cachedPrice: any = null;

interface GoldPriceApiResponse {
  price: number;
  currency: string;
  timestamp: number;
  change24h?: string;
}

// Simulate a real gold price API call
async function fetchGoldPriceFromApi(): Promise<GoldPriceApiResponse> {
  try {
    // In a production environment, we would call a real API
    // For example:
    // const response = await fetch(`https://api.metals-api.com/v1/latest?access_key=${API_KEY}&base=INR&symbols=XAU`);
    // const data = await response.json();
    // return {...};

    // For our demo, we'll simulate API response with some random variations
    // to make it realistic

    // Base price with minor random fluctuation
    const randomFactor = 0.995 + (Math.random() * 0.01); // +/- 0.5% variation
    const price = BASE_PRICE * randomFactor;

    // Simulate 24h change
    const isPositive = Math.random() > 0.4; // 60% chance of positive change
    const changePercent = (Math.random() * 1.5).toFixed(2); // 0-1.5% change
    const change24h = isPositive ? changePercent : `-${changePercent}`;

    return {
      price: Math.round(price * 100) / 100, // Round to 2 decimal places
      currency: 'INR',
      timestamp: Date.now(),
      change24h
    };
  } catch (error) {
    console.error('Error fetching gold price from API:', error);
    throw error;
  }
}

// Get current gold price, with caching
export async function getCurrentGoldPrice(): Promise<GoldPriceApiResponse> {
  const now = Date.now();
  
  // Check if we need to update our cached price
  if (!cachedPrice || (now - lastFetchTime > GOLD_PRICE_UPDATE_INTERVAL)) {
    try {
      cachedPrice = await fetchGoldPriceFromApi();
      lastFetchTime = now;
      
      // Store the price in the database for historical tracking
      await storage.createGoldPrice({
        pricePerGram: cachedPrice.price.toString(),
        change24h: cachedPrice.change24h || '0.00',
        change7d: '1.20', // Static value for demo
        change30d: '3.50', // Static value for demo
        priceHistory: JSON.stringify([]), // Empty array for now, would be populated in prod
      });
      
    } catch (error) {
      console.error('Failed to update gold price:', error);
      
      // If we have no cached price, create a fallback
      if (!cachedPrice) {
        cachedPrice = {
          price: BASE_PRICE,
          currency: 'INR',
          timestamp: now,
          change24h: '0.00'
        };
      }
    }
  }
  
  return cachedPrice;
}

// Initialize the service - fetch initial price
export async function initGoldPriceService() {
  try {
    await getCurrentGoldPrice();
    console.log('Gold price service initialized');
    
    // Set up interval to periodically update the price
    // This would typically be done in a production environment
    // setInterval(getCurrentGoldPrice, GOLD_PRICE_UPDATE_INTERVAL);
  } catch (error) {
    console.error('Failed to initialize gold price service:', error);
  }
}