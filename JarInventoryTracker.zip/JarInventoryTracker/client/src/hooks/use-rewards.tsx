import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getQueryFn, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function useRewards() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const {
    data: rewardsData,
    isLoading,
    error,
  } = useQuery({
    queryKey: ['/api/rewards'],
    queryFn: getQueryFn(),
  });

  const {
    data: myRewards,
    isLoading: isLoadingMyRewards,
  } = useQuery({
    queryKey: ['/api/rewards/my'],
    queryFn: getQueryFn(),
  });

  const redeemMutation = useMutation({
    mutationFn: async (rewardId: number) => {
      const res = await apiRequest('POST', `/api/rewards/${rewardId}/redeem`);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/rewards'] });
      queryClient.invalidateQueries({ queryKey: ['/api/rewards/my'] });
      queryClient.invalidateQueries({ queryKey: ['/api/points'] });
      queryClient.invalidateQueries({ queryKey: ['/api/streaks'] });

      toast({
        title: 'Reward redeemed',
        description: data.message,
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to redeem reward',
        description: error.message || "An error occurred",
        variant: 'destructive',
      });
    },
  });

  return {
    rewards: rewardsData?.rewards || [],
    userPoints: rewardsData?.userPoints,
    myRewards,
    isLoading,
    isLoadingMyRewards,
    error,
    redeem: redeemMutation.mutate,
    isRedeeming: redeemMutation.isPending,
  };
}