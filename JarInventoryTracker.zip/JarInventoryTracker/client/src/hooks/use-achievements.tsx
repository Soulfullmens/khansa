import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getQueryFn, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function useAchievements() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const {
    data: achievements,
    isLoading,
    error,
  } = useQuery({
    queryKey: ['/api/achievements'],
    queryFn: getQueryFn(),
  });

  const markSeenMutation = useMutation({
    mutationFn: async (achievementId: number) => {
      const res = await apiRequest('POST', `/api/achievements/${achievementId}/mark-seen`);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/achievements'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  return {
    achievements,
    isLoading,
    error,
    markSeen: markSeenMutation.mutate,
    isMarkingSeen: markSeenMutation.isPending,
  };
}