import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";

export function usePoints() {
  const {
    data: pointsData,
    isLoading,
    error,
  } = useQuery({
    queryKey: ['/api/points'],
    queryFn: getQueryFn(),
  });

  return {
    points: pointsData?.points,
    transactions: pointsData?.recentTransactions || [],
    isLoading,
    error,
  };
}