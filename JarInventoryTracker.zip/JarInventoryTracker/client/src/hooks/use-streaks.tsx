import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getQueryFn, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function useStreaks() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const {
    data: streak,
    isLoading,
    error,
  } = useQuery({
    queryKey: ['/api/streaks'],
    queryFn: getQueryFn(),
  });

  const checkInMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/streaks/check-in');
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/streaks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/points'] });

      toast({
        title: 'Check-in successful',
        description: data.message,
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Check-in failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const buyFreezeMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/streaks/buy-freeze');
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/streaks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/points'] });
      queryClient.invalidateQueries({ queryKey: ['/api/rewards'] });

      toast({
        title: 'Streak freeze purchased',
        description: data.message,
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Purchase failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  return {
    streak,
    isLoading,
    error,
    checkIn: checkInMutation.mutate,
    buyFreeze: buyFreezeMutation.mutate,
    isCheckingIn: checkInMutation.isPending,
    isBuyingFreeze: buyFreezeMutation.isPending,
  };
}