import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

interface OnboardingFlowProps {
  onComplete: () => void;
  onSkip: () => void;
}

const OnboardingFlow: React.FC<OnboardingFlowProps> = ({ onComplete, onSkip }) => {
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const totalSteps = 3;

  const handleNext = () => {
    setStep((prev) => Math.min(prev + 1, totalSteps));
  };

  const handleBack = () => {
    setStep((prev) => Math.max(prev - 1, 1));
  };

  const handleComplete = () => {
    toast({
      title: "Onboarding completed",
      description: "You're all set to start your golden future!",
    });
    onComplete();
  };

  return (
    <div className="fixed inset-0 bg-white z-30">
      <div className="h-full flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
          {step === 1 && <WelcomeStep onNext={handleNext} onSkip={onSkip} />}
          {step === 2 && <SavingsGoalStep onNext={handleNext} onBack={handleBack} onSkip={onSkip} />}
          {step === 3 && <AutoSaveStep onComplete={handleComplete} onBack={handleBack} onSkip={onSkip} />}
          
          <div className="w-full max-w-xs mt-8">
            <Progress value={(step / totalSteps) * 100} className="h-2 mb-6">
              <div className="flex justify-between -mt-1">
                {Array.from({ length: totalSteps }).map((_, i) => (
                  <div 
                    key={i}
                    className={`h-4 w-4 rounded-full ${i < step ? 'bg-[#F7B801]' : 'bg-gray-200'}`}
                  />
                ))}
              </div>
            </Progress>
          </div>
        </div>
      </div>
    </div>
  );
};

// Step 1 - Welcome
const WelcomeStep = ({ onNext, onSkip }: { onNext: () => void; onSkip: () => void }) => {
  return (
    <>
      <div className="w-64 h-64 mb-8">
        <img 
          src="https://images.unsplash.com/photo-1631897206332-2372660795a6?auto=format&fit=crop&q=80&w=256&h=256" 
          alt="Gold investment illustration" 
          className="w-full h-full object-contain"
        />
      </div>
      
      <h1 className="font-heading font-bold text-2xl mb-3 text-[#1A2E44]">Start your golden future today</h1>
      <p className="text-gray-600 mb-8 max-w-xs">Save in digital gold with as little as ₹10 per day and watch your wealth grow</p>
      
      <div className="w-full max-w-xs">
        <Button 
          onClick={onNext}
          className="w-full py-6 bg-gradient-to-r from-[#F7B801] to-[#FFC833] text-white font-medium mb-4"
        >
          Continue
        </Button>
        
        <Button variant="ghost" onClick={onSkip} className="text-[#1A2E44] text-sm">
          Skip for now
        </Button>
      </div>
    </>
  );
};

// Step 2 - Savings Goal
const savingsGoalSchema = z.object({
  goalName: z.string().min(1, "Goal name is required"),
  goalAmount: z.string().refine(val => !isNaN(Number(val)) && Number(val) > 0, "Amount must be greater than 0"),
});

const SavingsGoalStep = ({ 
  onNext, 
  onBack, 
  onSkip 
}: { 
  onNext: () => void; 
  onBack: () => void; 
  onSkip: () => void 
}) => {
  const { toast } = useToast();
  const { register, handleSubmit, formState: { errors } } = useForm<z.infer<typeof savingsGoalSchema>>({
    resolver: zodResolver(savingsGoalSchema),
    defaultValues: {
      goalName: "",
      goalAmount: "",
    }
  });

  const onSubmit = async (data: z.infer<typeof savingsGoalSchema>) => {
    try {
      // Create a goal with 6 months target date
      const targetDate = new Date();
      targetDate.setMonth(targetDate.getMonth() + 6);

      await apiRequest("POST", "/api/goals", {
        name: data.goalName,
        targetAmount: data.goalAmount,
        currentAmount: "0",
        targetDate: targetDate.toISOString(),
        icon: "ri-trophy-line",
        iconBg: "bg-blue-500"
      });

      queryClient.invalidateQueries({ queryKey: ["/api/goals"] });
      toast({
        title: "Goal created!",
        description: `Your goal "${data.goalName}" has been created successfully.`,
      });
      onNext();
    } catch (error) {
      toast({
        title: "Failed to create goal",
        description: "There was an error creating your goal. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <>
      <div className="w-64 h-64 mb-8">
        <img 
          src="https://images.unsplash.com/photo-1579621970588-a35d0e7ab9b6?auto=format&fit=crop&q=80&w=256&h=256" 
          alt="Goal setting illustration" 
          className="w-full h-full object-contain"
        />
      </div>
      
      <h1 className="font-heading font-bold text-2xl mb-3 text-[#1A2E44]">Set your first savings goal</h1>
      <p className="text-gray-600 mb-8 max-w-xs">What are you saving for? Let's set a target to keep you motivated</p>
      
      <form onSubmit={handleSubmit(onSubmit)} className="w-full max-w-xs">
        <div className="space-y-4 mb-6">
          <div>
            <Input 
              placeholder="Goal name (e.g. New Phone)" 
              {...register("goalName")}
            />
            {errors.goalName && (
              <p className="text-red-500 text-xs mt-1">{errors.goalName.message}</p>
            )}
          </div>
          <div>
            <Input 
              placeholder="Target amount (₹)" 
              type="number"
              {...register("goalAmount")} 
            />
            {errors.goalAmount && (
              <p className="text-red-500 text-xs mt-1">{errors.goalAmount.message}</p>
            )}
          </div>
        </div>
        
        <Button 
          type="submit"
          className="w-full py-6 bg-gradient-to-r from-[#F7B801] to-[#FFC833] text-white font-medium mb-4"
        >
          Continue
        </Button>
        
        <div className="flex justify-between">
          <Button variant="ghost" onClick={onBack} className="text-[#1A2E44] text-sm">
            Back
          </Button>
          <Button variant="ghost" onClick={onSkip} className="text-[#1A2E44] text-sm">
            Skip for now
          </Button>
        </div>
      </form>
    </>
  );
};

// Step 3 - Auto Save
const autoSaveSchema = z.object({
  dailySavings: z.string().refine(val => !isNaN(Number(val)) && Number(val) >= 0, "Amount must be a valid number"),
});

const AutoSaveStep = ({ 
  onComplete, 
  onBack, 
  onSkip 
}: { 
  onComplete: () => void; 
  onBack: () => void; 
  onSkip: () => void 
}) => {
  const { toast } = useToast();
  const { register, handleSubmit, formState: { errors } } = useForm<z.infer<typeof autoSaveSchema>>({
    resolver: zodResolver(autoSaveSchema),
    defaultValues: {
      dailySavings: "50",
    }
  });

  const onSubmit = (data: z.infer<typeof autoSaveSchema>) => {
    // This would connect to an API to set up automatic savings
    toast({
      title: "Auto-save set up!",
      description: `We'll save ₹${data.dailySavings} for you every day.`,
    });
    onComplete();
  };

  return (
    <>
      <div className="w-64 h-64 mb-8">
        <img 
          src="https://images.unsplash.com/photo-1589666564459-93cdd3ab856a?auto=format&fit=crop&q=80&w=256&h=256" 
          alt="Auto save illustration" 
          className="w-full h-full object-contain"
        />
      </div>
      
      <h1 className="font-heading font-bold text-2xl mb-3 text-[#1A2E44]">Save automatically</h1>
      <p className="text-gray-600 mb-8 max-w-xs">Set up a daily automatic savings amount to grow your investments effortlessly</p>
      
      <form onSubmit={handleSubmit(onSubmit)} className="w-full max-w-xs">
        <div className="space-y-4 mb-6">
          <div>
            <Input 
              placeholder="Daily savings amount (₹)" 
              type="number"
              {...register("dailySavings")} 
              className="text-center text-lg font-mono py-6"
            />
            {errors.dailySavings && (
              <p className="text-red-500 text-xs mt-1">{errors.dailySavings.message}</p>
            )}
          </div>
          <p className="text-sm text-gray-500 text-center">
            This will help you save approximately ₹18,250 per year
          </p>
        </div>
        
        <Button 
          type="submit"
          className="w-full py-6 bg-gradient-to-r from-[#F7B801] to-[#FFC833] text-white font-medium mb-4"
        >
          Complete Setup
        </Button>
        
        <div className="flex justify-between">
          <Button variant="ghost" onClick={onBack} className="text-[#1A2E44] text-sm">
            Back
          </Button>
          <Button variant="ghost" onClick={onSkip} className="text-[#1A2E44] text-sm">
            Skip for now
          </Button>
        </div>
      </form>
    </>
  );
};

export default OnboardingFlow;
