import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

interface QuickActionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const QuickActionModal: React.FC<QuickActionModalProps> = ({ isOpen, onClose }) => {
  const { toast } = useToast();
  const [amount, setAmount] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [_, setLocation] = useLocation();

  const handleAddMoney = async () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    try {
      await apiRequest("POST", "/api/investments/add", { amount });
      queryClient.invalidateQueries({ queryKey: ["/api/investments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      
      toast({
        title: "Money added successfully",
        description: `₹${amount} has been added to your investments`,
      });
      
      setAmount("");
      onClose();
    } catch (error) {
      toast({
        title: "Failed to add money",
        description: "An error occurred while processing your request",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const navigateTo = (path: string) => {
    setLocation(path);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-white rounded-t-xl w-full max-w-md p-6 sm:rounded-xl">
        <DialogHeader>
          <DialogTitle className="text-center font-heading font-semibold text-lg mb-6">Quick Actions</DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-3 gap-4 mb-6">
          <button className="flex flex-col items-center p-3 bg-[#FFF8E6] rounded-lg">
            <div className="bg-[#F7B801] h-12 w-12 rounded-full flex items-center justify-center mb-2">
              <i className="ri-add-line text-white text-xl"></i>
            </div>
            <span className="text-xs text-center">Add Money</span>
          </button>
          
          <button className="flex flex-col items-center p-3 bg-gray-50 rounded-lg">
            <div className="bg-gray-700 h-12 w-12 rounded-full flex items-center justify-center mb-2">
              <i className="ri-exchange-line text-white text-xl"></i>
            </div>
            <span className="text-xs text-center">Withdraw</span>
          </button>
          
          <button 
            className="flex flex-col items-center p-3 bg-blue-50 rounded-lg"
            onClick={() => navigateTo("/goals")}
          >
            <div className="bg-blue-500 h-12 w-12 rounded-full flex items-center justify-center mb-2">
              <i className="ri-trophy-line text-white text-xl"></i>
            </div>
            <span className="text-xs text-center">New Goal</span>
          </button>
          
          <button className="flex flex-col items-center p-3 bg-green-50 rounded-lg">
            <div className="bg-green-500 h-12 w-12 rounded-full flex items-center justify-center mb-2">
              <i className="ri-repeat-line text-white text-xl"></i>
            </div>
            <span className="text-xs text-center">Auto Save</span>
          </button>
          
          <button className="flex flex-col items-center p-3 bg-purple-50 rounded-lg">
            <div className="bg-purple-500 h-12 w-12 rounded-full flex items-center justify-center mb-2">
              <i className="ri-gift-line text-white text-xl"></i>
            </div>
            <span className="text-xs text-center">Rewards</span>
          </button>
          
          <button className="flex flex-col items-center p-3 bg-indigo-50 rounded-lg">
            <div className="bg-indigo-500 h-12 w-12 rounded-full flex items-center justify-center mb-2">
              <i className="ri-customer-service-2-line text-white text-xl"></i>
            </div>
            <span className="text-xs text-center">Support</span>
          </button>
        </div>

        <div className="mt-4">
          <h3 className="font-medium text-sm mb-2">Quick Add Money</h3>
          <div className="flex items-center space-x-2">
            <Input
              type="number"
              placeholder="Enter amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="flex-1"
            />
            <Button 
              className="bg-gradient-to-r from-[#F7B801] to-[#FFC833] text-white"
              onClick={handleAddMoney}
              disabled={isProcessing}
            >
              {isProcessing ? "Processing..." : "Add"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default QuickActionModal;
