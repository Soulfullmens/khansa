import { motion } from 'framer-motion';
import { useAuth } from '@/hooks/use-auth';
import Khansa3DLogo from '@/components/ui/khansa-3d-logo';
import GoldCoin3D from '@/components/ui/gold-coin-3d';

const LuxuryHeader = () => {
  const { user } = useAuth();
  const currentHour = new Date().getHours();
  
  // Determine greeting based on time of day
  const getGreeting = () => {
    if (currentHour < 12) return 'Good Morning';
    if (currentHour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };
  
  return (
    <div className="mb-6">
      <div className="bg-gradient-to-r from-amber-50 to-amber-100 rounded-xl p-6 shadow-lg border border-amber-200/50 relative overflow-hidden">
        {/* Background patterns */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{ 
            backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M54.627 0l.83.828-1.415 1.415L51.8 0h2.827zM5.373 0l-.83.828L5.96 2.243 8.2 0H5.374zM48.97 0l3.657 3.657-1.414 1.414L46.143 0h2.828zM11.03 0L7.372 3.657 8.787 5.07 13.857 0H11.03zm32.284 0L49.8 6.485 48.384 7.9l-7.9-7.9h2.83zM16.686 0L10.2 6.485 11.616 7.9l7.9-7.9h-2.83zm20.97 0l9.315 9.314-1.414 1.414L34.828 0h2.83zM22.344 0L13.03 9.314l1.414 1.414L25.172 0h-2.83zM32 0l12.142 12.142-1.414 1.414L30 .828 17.272 13.556l-1.414-1.414L28 0h4zM.284 0l28 28-1.414 1.414L0 2.544v2.83L25.456 30l-1.414 1.414-28-28L0 0h.284zM0 5.373l25.456 25.455-1.414 1.415L0 8.2v2.83l21.627 21.628-1.414 1.414L0 13.657v2.828l17.8 17.8-1.414 1.414L0 19.1v2.83l14.142 14.14-1.414 1.415L0 24.544v2.83l10.314 10.313-1.414 1.414L0 30v2.828l6.485 6.485-1.414 1.415L0 35.373v2.83l2.657 2.656-1.414 1.415L0 40.717v2.83l-1.414 1.414L0 47.803v2.83l-1.414 1.415L0 54.627v2.83L0 60h2.828L60 2.828V0h-2.83L0 57.172V60h5.657L60 5.657V0h-2.83L0 52.343V60h8.485L60 8.485V0h-2.83L0 47.515V60h11.314L60 11.314V0h-2.83L0 42.687V60h14.142L60 14.142V0h-2.83L0 37.858V60h17.8L60 16.97V0h-2.83L0 33.03V60h20.627L60 20.627V0h-2.83L0 28.373V60H24.28L60 24.28V0h-2.83L0 23.03V60h28L60 28V0h-2.83L0 17.272V60h32.657L60 32.657V0h-2.83L0 11.515V60h37.515L60 37.515V0h-2.83L0 5.757V60h42.343L60 42.343V0h-2.83L0 0v60h47.172L60 47.172V0h-2.83L0 0v60h52.9L60 56.9V0h-2.83L0 0v60h57.627L60 57.627V0h-2.83L0 0v60h60L60 0H0v60z\' fill=\'%23B45309\' fill-opacity=\'1\' fill-rule=\'evenodd\'/%3E%3C/svg%3E")',
            backgroundSize: '20px 20px',
          }} />
        </div>
        
        {/* Shimmer effect */}
        <motion.div 
          className="absolute inset-0 bg-gradient-to-r from-transparent via-amber-200/30 to-transparent"
          animate={{ 
            x: ['-100%', '100%'],
          }}
          transition={{ 
            duration: 3, 
            repeat: Infinity,
            repeatType: "loop",
            ease: "easeInOut" 
          }}
        />
        
        <div className="flex items-center justify-between relative z-10">
          {/* Logo and greeting */}
          <div className="flex-1">
            <div className="flex items-center">
              {/* 3D Logo */}
              <Khansa3DLogo size="sm" className="hidden md:block" />
              
              {/* Text content */}
              <div className="md:ml-6">
                <motion.h2 
                  className="text-2xl font-semibold text-amber-800"
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  {getGreeting()}, {user?.username || 'Investor'}
                </motion.h2>
                
                <motion.p 
                  className="text-amber-700/80 mt-1"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.2, duration: 0.5 }}
                >
                  Your premium gold investment journey awaits you.
                </motion.p>
              </div>
            </div>
          </div>
          
          {/* Gold coin 3D animation */}
          <div className="hidden md:block">
            <GoldCoin3D size={90} />
          </div>
        </div>
        
        {/* Daily gold price changes */}
        <motion.div 
          className="mt-5 pt-5 border-t border-amber-200/50 flex items-center justify-between text-sm"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
            <span className="text-amber-800">Today's Gold Price: </span>
            <span className="font-medium text-amber-900 ml-2">₹5,825.75/gram</span>
          </div>
          
          <div className="flex items-center text-green-600">
            <span className="font-medium">+1.2%</span>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M12 7a1 1 0 10-2 0v3.586l-1.293-1.293a1 1 0 10-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L12 10.586V7z" clipRule="evenodd" />
            </svg>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default LuxuryHeader;