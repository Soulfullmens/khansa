import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import type { Insight } from "@shared/schema";
import { INSIGHT_TYPES } from "@/lib/constants";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

const InsightsSection = () => {
  const { data: insights, isLoading } = useQuery<Insight[]>({
    queryKey: ["/api/insights"],
  });

  const markAsRead = async (id: number) => {
    try {
      await apiRequest("PATCH", `/api/insights/${id}/read`, {});
      queryClient.invalidateQueries({ queryKey: ["/api/insights"] });
    } catch (error) {
      console.error("Failed to mark insight as read", error);
    }
  };

  if (isLoading) {
    return (
      <section className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-heading font-semibold text-lg">Smart Insights</h2>
          <span className="text-xs bg-[#FFF1CC] text-[#F7B801] py-1 px-2 rounded-full">AI Powered</span>
        </div>
        <div className="space-y-4">
          <Card className="bg-white rounded-xl shadow-md p-4 border-l-4 border-[#F7B801]">
            <CardContent className="p-0">
              <div className="animate-pulse flex items-start">
                <div className="bg-gray-200 rounded-full p-2 mr-3 h-8 w-8"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded w-36 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-full mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-full mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-24 mt-2"></div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    );
  }

  // If no insights, show empty state
  if (!insights || insights.length === 0) {
    return (
      <section className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-heading font-semibold text-lg">Smart Insights</h2>
          <span className="text-xs bg-[#FFF1CC] text-[#F7B801] py-1 px-2 rounded-full">AI Powered</span>
        </div>
        <Card className="bg-white rounded-xl shadow-md p-6">
          <CardContent className="p-0 text-center">
            <div className="bg-[#FFF8E6] h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-lightbulb-line text-[#F7B801] text-2xl"></i>
            </div>
            <h3 className="font-medium text-base mb-2">No insights yet</h3>
            <p className="text-sm text-gray-500">
              As you save and invest more, we'll provide personalized insights to help you reach your goals faster.
            </p>
          </CardContent>
        </Card>
      </section>
    );
  }

  return (
    <section className="mb-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-heading font-semibold text-lg">Smart Insights</h2>
        <span className="text-xs bg-[#FFF1CC] text-[#F7B801] py-1 px-2 rounded-full">AI Powered</span>
      </div>
      
      <div className="space-y-4">
        {insights.filter(insight => !insight.isRead).map((insight) => {
          const insightStyle = INSIGHT_TYPES[insight.type as keyof typeof INSIGHT_TYPES];
          
          return (
            <Card 
              key={insight.id} 
              className={`bg-white rounded-xl shadow-md p-4 border-l-4 ${insightStyle.border}`}
            >
              <CardContent className="p-0">
                <div className="flex items-start">
                  <div className={`${insightStyle.bg} rounded-full p-2 mr-3`}>
                    <i className={`${insightStyle.icon} ${insightStyle.color}`}></i>
                  </div>
                  <div>
                    <h3 className="font-medium text-sm mb-1">{insight.title}</h3>
                    <p className="text-sm text-gray-600">{insight.description}</p>
                    <button 
                      className={`${insightStyle.color} text-xs mt-2 font-medium`}
                      onClick={() => markAsRead(insight.id)}
                    >
                      {insight.actionText}
                    </button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </section>
  );
};

export default InsightsSection;
