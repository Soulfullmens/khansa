import { Button } from "@/components/ui/button";

const EducationalBanner = () => {
  return (
    <section className="mb-8">
      <div className="bg-[#1A2E44] text-white rounded-xl p-6 relative overflow-hidden">
        <div className="relative z-10">
          <h3 className="font-heading font-semibold text-lg mb-2">Why invest in digital gold?</h3>
          <p className="text-sm opacity-90 mb-4">Learn how fractional gold ownership helps you build wealth safely.</p>
          <Button className="bg-white text-[#1A2E44] hover:bg-gray-100">Learn More</Button>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute right-0 top-0 h-full w-1/3 opacity-20">
          <div className="absolute right-4 top-1/2 transform -translate-y-1/2 w-20 h-20 rounded-full bg-[#F7B801]"></div>
          <div className="absolute right-12 top-1/4 w-10 h-10 rounded-full bg-[#FFC833]"></div>
          <div className="absolute right-8 bottom-4 w-14 h-14 rounded-full bg-[#CC9600]"></div>
        </div>
      </div>
    </section>
  );
};

export default EducationalBanner;
