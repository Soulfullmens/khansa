import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import type { Goal } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useState, useEffect } from "react";
import { GOAL_ICONS } from "@/lib/constants";
import { useToast } from "@/hooks/use-toast";
import { format, differenceInDays } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { Icon } from "@/lib/icons";

// Schema for goal creation
const goalSchema = z.object({
  name: z.string().min(1, "Name is required"),
  targetAmount: z.string().refine(val => !isNaN(Number(val)) && Number(val) > 0, "Amount must be greater than 0"),
  targetDate: z.string().refine(val => new Date(val) > new Date(), "Date must be in the future"),
  icon: z.string(),
  iconBg: z.string(),
});

type GoalFormData = z.infer<typeof goalSchema>;

const calculateDaysRemaining = (targetDate: Date) => {
  return Math.max(0, differenceInDays(targetDate, new Date()));
};

const GoalCard = ({ goal, index }: { goal: Goal, index: number }) => {
  const [progressAnimation, setProgressAnimation] = useState(0);
  const progress = (parseFloat(goal.currentAmount.toString()) / parseFloat(goal.targetAmount.toString())) * 100;
  const remaining = parseFloat(goal.targetAmount.toString()) - parseFloat(goal.currentAmount.toString());
  const targetDate = new Date(goal.targetDate);
  const daysRemaining = calculateDaysRemaining(targetDate);
  const [showDetails, setShowDetails] = useState(false);
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setProgressAnimation(progress);
    }, 300 + index * 100); // Stagger the animations
    
    return () => clearTimeout(timer);
  }, [progress, index]);
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.1 }}
    >
      <Card className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow overflow-hidden">
        <motion.div 
          className="p-4 cursor-pointer"
          onClick={() => setShowDetails(!showDetails)}
        >
          <CardContent className="p-0">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center">
                <motion.div 
                  className={`${goal.iconBg} h-10 w-10 rounded-full flex items-center justify-center mr-3`}
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ type: "spring", stiffness: 400, damping: 10 }}
                >
                  <Icon icon={goal.icon} className="text-white text-lg" />
                </motion.div>
                <div>
                  <h3 className="font-medium">{goal.name}</h3>
                  <p className="text-xs text-gray-500">by {format(targetDate, 'MMM yyyy')}</p>
                </div>
              </div>
              <div className="text-right">
                <span className="font-mono font-medium">₹{goal.targetAmount}</span>
                <div className="text-xs text-gray-500">
                  {daysRemaining} days left
                </div>
              </div>
            </div>
            
            <div className="relative mb-2 overflow-hidden">
              <Progress 
                value={0} 
                className="h-3 bg-gray-200" 
                indicatorClassName="bg-gradient-to-r from-[#F7B801] to-[#FFC833] shadow-lg" 
              />
              <motion.div 
                className="absolute top-0 left-0 h-3 bg-gradient-to-r from-[#F7B801] to-[#FFC833] rounded-full shadow-lg"
                style={{ width: `${progressAnimation}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
              />
            </div>
            
            <div className="flex justify-between text-xs items-center">
              <span className="text-gray-500">₹{goal.currentAmount} saved</span>
              <span className="text-gray-500 flex items-center">
                ₹{remaining.toFixed(2)} to go 
                <motion.span
                  animate={{ rotate: showDetails ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                  className="ml-1 text-gray-400"
                >
                  <Icon icon="ri-arrow-down-line" className="h-3 w-3" />
                </motion.span>
              </span>
            </div>
          </CardContent>
        </motion.div>
        
        <AnimatePresence>
          {showDetails && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="px-4 pb-4 border-t border-gray-100"
            >
              <div className="pt-3 grid grid-cols-2 gap-3 text-xs">
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-gray-500 mb-1">Savings Progress</p>
                  <div className="flex items-center">
                    <div className="bg-[#F7B801] h-2 w-2 rounded-full mr-1"></div>
                    <span className="font-medium">{progress.toFixed(1)}%</span>
                  </div>
                  <p className="text-[11px] text-gray-400 mt-1">
                    {progress > 50 ? "You're doing great!" : "Keep saving!"}
                  </p>
                </div>
                
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-gray-500 mb-1">Daily Saving Target</p>
                  <p className="font-medium">₹{daysRemaining > 0 ? (remaining / daysRemaining).toFixed(2) : 0}/day</p>
                  <p className="text-[11px] text-gray-400 mt-1">
                    To reach your goal on time
                  </p>
                </div>
                
                <div className="bg-gray-50 p-3 rounded-lg col-span-2">
                  <div className="flex justify-between items-center mb-1">
                    <p className="text-gray-500">Quick Add Money</p>
                    <div className="flex space-x-1">
                      <motion.button 
                        className="bg-[#FFF8E6] text-[#F7B801] px-2 py-1 rounded-md font-medium"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        ₹100
                      </motion.button>
                      <motion.button 
                        className="bg-[#FFF8E6] text-[#F7B801] px-2 py-1 rounded-md font-medium"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        ₹500
                      </motion.button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </Card>
    </motion.div>
  );
};

const GoalsSection = () => {
  const { toast } = useToast();
  const [showNewGoalDialog, setShowNewGoalDialog] = useState(false);
  const [selectedIcon, setSelectedIcon] = useState<string | null>(null);
  
  const { data: goals, isLoading } = useQuery<Goal[]>({
    queryKey: ["/api/goals"],
  });

  const { register, handleSubmit, reset, setValue, watch, formState: { errors } } = useForm<GoalFormData>({
    resolver: zodResolver(goalSchema),
    defaultValues: {
      name: "",
      targetAmount: "",
      targetDate: "",
      icon: GOAL_ICONS[0].icon,
      iconBg: GOAL_ICONS[0].bg,
    }
  });

  const watchedIcon = watch("icon");
  
  useEffect(() => {
    setSelectedIcon(watchedIcon);
  }, [watchedIcon]);

  const onSubmit = async (data: GoalFormData) => {
    try {
      const goalData = {
        name: data.name,
        targetAmount: data.targetAmount,
        currentAmount: "0",
        targetDate: new Date(data.targetDate).toISOString(),
        icon: data.icon,
        iconBg: data.iconBg,
      };
      
      await apiRequest("POST", "/api/goals", goalData);
      queryClient.invalidateQueries({ queryKey: ["/api/goals"] });
      
      // Reset form and close dialog
      reset();
      setShowNewGoalDialog(false);
      
      toast({
        title: "Goal created!",
        description: `Your goal "${data.name}" has been created successfully.`,
      });
    } catch (error) {
      toast({
        title: "Failed to create goal",
        description: "There was an error creating your goal. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleSelectIcon = (icon: string, bg: string) => {
    setValue("icon", icon);
    setValue("iconBg", bg);
  };

  if (isLoading) {
    return (
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-heading font-semibold text-lg">Your Goals</h2>
        </div>
        <div className="space-y-4">
          {[1, 2].map((i) => (
            <Card key={i} className="bg-white rounded-xl shadow-md p-4">
              <CardContent className="p-0">
                <div className="animate-pulse">
                  <div className="flex items-center mb-3">
                    <div className="bg-gray-200 h-10 w-10 rounded-full mr-3"></div>
                    <div className="flex-1">
                      <div className="h-4 bg-gray-200 rounded w-24 mb-1"></div>
                      <div className="h-3 bg-gray-200 rounded w-16"></div>
                    </div>
                    <div className="h-4 bg-gray-200 rounded w-16"></div>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3 mb-2"></div>
                  <div className="flex justify-between">
                    <div className="h-3 bg-gray-200 rounded w-16"></div>
                    <div className="h-3 bg-gray-200 rounded w-16"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <section className="mb-6">
      <div className="flex items-center justify-between mb-4">
        <motion.h2 
          className="font-heading font-semibold text-lg"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4 }}
        >
          Your Goals
        </motion.h2>
        <motion.button 
          className="text-sm bg-[#FFF8E6] text-[#F7B801] flex items-center px-3 py-1 rounded-full hover:bg-[#FFE499] transition-colors"
          onClick={() => setShowNewGoalDialog(true)}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4 }}
        >
          <Icon icon="ri-add-line" className="mr-1" /> New Goal
        </motion.button>
      </div>
      
      {goals && goals.length > 0 ? (
        <div className="space-y-4">
          {goals.map((goal, index) => (
            <GoalCard key={goal.id} goal={goal} index={index} />
          ))}
        </div>
      ) : (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="bg-white rounded-xl shadow-md p-6">
            <CardContent className="p-0 flex flex-col items-center justify-center text-center">
              <motion.div 
                className="bg-[#E6EBF0] h-16 w-16 rounded-full flex items-center justify-center mb-4"
                initial={{ scale: 0.8 }}
                animate={{ scale: 1 }}
                transition={{ 
                  duration: 0.5,
                  type: "spring",
                  stiffness: 300
                }}
              >
                <Icon icon="ri-trophy-line" className="text-[#1A2E44] text-2xl" />
              </motion.div>
              <motion.h3 
                className="font-medium text-lg mb-2"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2, duration: 0.5 }}
              >
                No goals yet
              </motion.h3>
              <motion.p 
                className="text-sm text-gray-500 mb-4"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3, duration: 0.5 }}
              >
                Create a goal to start saving for something special
              </motion.p>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4, duration: 0.5 }}
              >
                <Button 
                  onClick={() => setShowNewGoalDialog(true)}
                  className="bg-gradient-to-r from-[#F7B801] to-[#FFC833] text-white hover:shadow-lg transition-shadow"
                >
                  Create your first goal
                </Button>
              </motion.div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* New Goal Dialog */}
      <Dialog open={showNewGoalDialog} onOpenChange={setShowNewGoalDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Create a new goal</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Goal name</Label>
                <Input id="name" {...register("name")} placeholder="e.g., Goa Vacation" />
                {errors.name && (
                  <p className="text-red-500 text-xs">{errors.name.message}</p>
                )}
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="targetAmount">Target amount (₹)</Label>
                <Input 
                  id="targetAmount" 
                  {...register("targetAmount")} 
                  placeholder="e.g., 25000"
                  type="number"
                  min="1"
                />
                {errors.targetAmount && (
                  <p className="text-red-500 text-xs">{errors.targetAmount.message}</p>
                )}
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="targetDate">Target date</Label>
                <Input 
                  id="targetDate" 
                  {...register("targetDate")} 
                  type="date"
                  min={new Date().toISOString().split('T')[0]}
                />
                {errors.targetDate && (
                  <p className="text-red-500 text-xs">{errors.targetDate.message}</p>
                )}
              </div>
              
              <div className="grid gap-2">
                <Label>Choose an icon</Label>
                <div className="grid grid-cols-4 gap-2">
                  <AnimatePresence>
                    {GOAL_ICONS.map((goalIcon, index) => (
                      <motion.button
                        key={index}
                        type="button"
                        className={`${goalIcon.bg} h-12 w-12 rounded-full flex items-center justify-center mx-auto transition-all
                          ${selectedIcon === goalIcon.icon ? "ring-2 ring-offset-2 ring-[#F7B801]" : ""}`}
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={() => handleSelectIcon(goalIcon.icon, goalIcon.bg)}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                      >
                        <Icon icon={goalIcon.icon} className="text-white text-xl" />
                      </motion.button>
                    ))}
                  </AnimatePresence>
                </div>
                <input type="hidden" {...register("icon")} />
                <input type="hidden" {...register("iconBg")} />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowNewGoalDialog(false)}>
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="bg-gradient-to-r from-[#F7B801] to-[#FFC833] text-white hover:shadow-lg transition-shadow"
              >
                Create Goal
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default GoalsSection;
