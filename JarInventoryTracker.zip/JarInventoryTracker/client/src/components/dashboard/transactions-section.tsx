import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import type { Transaction } from "@shared/schema";
import { TRANSACTION_TYPES } from "@/lib/constants";
import { format } from "date-fns";

const TransactionsSection = () => {
  const { data: transactions, isLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions", { limit: 3 }],
  });

  if (isLoading) {
    return (
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-heading font-semibold text-lg">Recent Transactions</h2>
          <button className="text-sm text-[#F7B801]">See All</button>
        </div>
        
        <Card className="bg-white rounded-xl shadow-md divide-y">
          {[1, 2, 3].map((i) => (
            <div key={i} className="p-4">
              <div className="animate-pulse flex items-center justify-between">
                <div className="flex items-center">
                  <div className="bg-gray-200 h-10 w-10 rounded-full mr-3"></div>
                  <div>
                    <div className="h-4 bg-gray-200 rounded w-24 mb-1"></div>
                    <div className="h-3 bg-gray-200 rounded w-32"></div>
                  </div>
                </div>
                <div className="h-4 bg-gray-200 rounded w-16"></div>
              </div>
            </div>
          ))}
        </Card>
      </section>
    );
  }

  // If no transactions, show empty state
  if (!transactions || transactions.length === 0) {
    return (
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-heading font-semibold text-lg">Recent Transactions</h2>
        </div>
        
        <Card className="bg-white rounded-xl shadow-md p-6">
          <CardContent className="p-0 text-center">
            <div className="bg-[#E6EBF0] h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-exchange-dollar-line text-[#1A2E44] text-2xl"></i>
            </div>
            <h3 className="font-medium text-base mb-2">No transactions yet</h3>
            <p className="text-sm text-gray-500">
              Start saving and investing to see your transaction history here.
            </p>
          </CardContent>
        </Card>
      </section>
    );
  }

  return (
    <section className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-heading font-semibold text-lg">Recent Transactions</h2>
        <button className="text-sm text-[#F7B801]">See All</button>
      </div>
      
      <Card className="bg-white rounded-xl shadow-md divide-y">
        {transactions.map((transaction) => {
          const transactionType = TRANSACTION_TYPES[transaction.type as keyof typeof TRANSACTION_TYPES];
          const isPositive = transaction.type !== "withdraw";
          const dateFormatted = format(new Date(transaction.createdAt), "MMM d, yyyy • h:mm a");
          
          return (
            <div key={transaction.id} className="p-4 flex items-center justify-between">
              <div className="flex items-center">
                <div className={`${transactionType.bg} h-10 w-10 rounded-full flex items-center justify-center mr-3`}>
                  <i className={`${transactionType.icon} ${transactionType.color}`}></i>
                </div>
                <div>
                  <p className="font-medium text-sm">{transactionType.label}</p>
                  <p className="text-xs text-gray-500">{dateFormatted}</p>
                </div>
              </div>
              <span className={`font-mono font-medium ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
                {isPositive ? '+' : '-'}₹{parseFloat(transaction.amount.toString()).toFixed(2)}
              </span>
            </div>
          );
        })}
      </Card>
    </section>
  );
};

export default TransactionsSection;
