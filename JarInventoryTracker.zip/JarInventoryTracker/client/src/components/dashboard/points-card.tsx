import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Coins, ArrowUp, ArrowDown } from "lucide-react";
import { usePoints } from "@/hooks/use-points";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";

export function PointsCard() {
  const { points, transactions, isLoading } = usePoints();
  
  const renderPointsContent = () => {
    if (isLoading) {
      return (
        <div className="space-y-4">
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-4 w-1/2" />
        </div>
      );
    }
    
    if (!points) {
      return (
        <div className="flex flex-col items-center justify-center h-36 space-y-4">
          <Coins className="h-10 w-10 text-muted-foreground" />
          <p className="text-center text-muted-foreground">No points yet. Complete actions to earn points!</p>
        </div>
      );
    }
    
    return (
      <div className="space-y-4">
        <div className="flex flex-col items-center justify-center">
          <div className="text-3xl font-bold">{points.availablePoints}</div>
          <div className="text-sm text-muted-foreground">Available Points</div>
        </div>
        
        <div className="bg-muted/40 p-3 rounded-lg flex justify-between">
          <div className="text-center">
            <div className="text-sm font-medium">{points.totalPoints}</div>
            <div className="text-xs text-muted-foreground">Total Earned</div>
          </div>
          
          <div className="w-px bg-border"></div>
          
          <div className="text-center">
            <div className="text-sm font-medium">{points.totalPoints - points.availablePoints}</div>
            <div className="text-xs text-muted-foreground">Spent</div>
          </div>
        </div>
        
        {transactions && transactions.length > 0 && (
          <div>
            <div className="text-sm font-medium mb-2">Recent Activity</div>
            <ScrollArea className="h-[150px]">
              <div className="space-y-2">
                {transactions.map((transaction) => (
                  <div key={transaction.id} className="text-sm flex items-start justify-between p-2 rounded-md bg-background">
                    <div className="flex items-center gap-2">
                      <div className={`rounded-full p-1 ${
                        transaction.amount > 0 
                          ? 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300' 
                          : 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300'
                      }`}>
                        {transaction.amount > 0 ? (
                          <ArrowUp className="h-3 w-3" />
                        ) : (
                          <ArrowDown className="h-3 w-3" />
                        )}
                      </div>
                      <div>
                        <div className="font-medium line-clamp-1">{transaction.description}</div>
                        <div className="text-xs text-muted-foreground">{new Date(transaction.createdAt).toLocaleDateString()}</div>
                      </div>
                    </div>
                    <div className={`font-medium ${
                      transaction.amount > 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                    }`}>
                      {transaction.amount > 0 ? '+' : ''}{transaction.amount}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>
        )}
      </div>
    );
  };
  
  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-medium flex items-center">
          <Coins className="mr-2 h-5 w-5 text-amber-500" />
          Points Wallet
        </CardTitle>
      </CardHeader>
      <CardContent>
        {renderPointsContent()}
      </CardContent>
      <CardFooter className="pt-0">
        <p className="text-xs text-muted-foreground">
          Use points to redeem rewards in the rewards store
        </p>
      </CardFooter>
    </Card>
  );
}