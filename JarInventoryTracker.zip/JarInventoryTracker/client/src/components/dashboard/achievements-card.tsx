import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Award, Lock, TrendingUp } from "lucide-react";
import { useAchievements } from "@/hooks/use-achievements";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

export function AchievementsCard() {
  const { achievements, isLoading, markSeen } = useAchievements();
  
  const renderAchievements = () => {
    if (isLoading) {
      return Array(3).fill(0).map((_, i) => (
        <div key={i} className="flex items-center gap-3 mb-3">
          <Skeleton className="h-10 w-10 rounded-full" />
          <div className="space-y-1 flex-1">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-3 w-1/2" />
          </div>
        </div>
      ));
    }
    
    if (!achievements || achievements.length === 0) {
      return (
        <div className="flex flex-col items-center justify-center h-36 text-center py-8">
          <Award className="h-10 w-10 text-muted-foreground mb-2" />
          <p className="text-muted-foreground">No achievements available yet</p>
        </div>
      );
    }
    
    // Show only non-hidden or unlocked achievements, prioritize new ones
    const visibleAchievements = achievements
      .filter(a => !a.hidden)
      .sort((a, b) => {
        // Prioritize new achievements
        if (a.isNew && !b.isNew) return -1;
        if (!a.isNew && b.isNew) return 1;
        // Then unlocked achievements
        if (a.unlocked && !b.unlocked) return -1;
        if (!a.unlocked && b.unlocked) return 1;
        // Then by level
        return a.level - b.level;
      });
    
    return (
      <ScrollArea className="h-[200px] pr-3">
        <div className="space-y-3">
          {visibleAchievements.map((achievement) => (
            <TooltipProvider key={achievement.id}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div 
                    className={`flex items-center gap-3 p-2 rounded-lg ${
                      achievement.unlocked 
                        ? achievement.isNew 
                          ? 'bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800' 
                          : 'bg-background' 
                        : 'bg-muted/40'
                    }`}
                    onClick={() => {
                      if (achievement.unlocked && achievement.isNew) {
                        markSeen(achievement.id);
                      }
                    }}
                  >
                    <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                      achievement.unlocked 
                        ? 'bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300' 
                        : 'bg-muted text-muted-foreground'
                    }`}>
                      {achievement.unlocked ? (
                        <Award className="h-5 w-5" />
                      ) : (
                        <Lock className="h-4 w-4" />
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className={`font-medium text-sm truncate ${
                          achievement.unlocked ? 'text-foreground' : 'text-muted-foreground'
                        }`}>
                          {achievement.name}
                        </p>
                        {achievement.isNew && (
                          <Badge variant="outline" className="bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-900 dark:text-amber-300 dark:border-amber-800 text-xs">
                            New
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground truncate">
                        {achievement.unlocked 
                          ? `+${achievement.pointsAwarded} points` 
                          : achievement.description}
                      </p>
                    </div>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <div className="space-y-1">
                    <p className="font-medium">{achievement.name}</p>
                    <p className="text-sm">{achievement.description}</p>
                    {achievement.unlocked && (
                      <p className="text-xs text-muted-foreground">
                        Unlocked {new Date(achievement.unlockedAt).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          ))}
        </div>
      </ScrollArea>
    );
  };
  
  // Calculate achievement progress
  const achievementStats = React.useMemo(() => {
    if (!achievements) return { total: 0, unlocked: 0, percentage: 0 };
    
    const visible = achievements.filter(a => !a.hidden);
    const unlocked = visible.filter(a => a.unlocked);
    
    return {
      total: visible.length,
      unlocked: unlocked.length,
      percentage: visible.length > 0 ? Math.round((unlocked.length / visible.length) * 100) : 0
    };
  }, [achievements]);
  
  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-medium flex items-center justify-between">
          <div className="flex items-center">
            <Award className="mr-2 h-5 w-5 text-amber-500" />
            Achievements
          </div>
          {!isLoading && (
            <Badge variant="outline" className="ml-auto">
              {achievementStats.unlocked}/{achievementStats.total}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {renderAchievements()}
      </CardContent>
      <CardFooter className="pt-0">
        <p className="text-xs text-muted-foreground flex items-center">
          <TrendingUp className="h-3 w-3 mr-1" />
          Complete goals and maintain streaks to earn achievements
        </p>
      </CardFooter>
    </Card>
  );
}