import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { fetchHistoricalGoldPrices, HistoricalGoldPrice } from '@/lib/gold-price-service';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { LUXURY_PALETTE, DASHBOARD_COLORS } from '@/lib/luxury-palette';
import { ArrowUpIcon, ArrowDownIcon } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

interface GoldPriceChartProps {
  currentPrice: number;
  priceChange: string;
}

export function GoldPriceChart({ currentPrice, priceChange }: GoldPriceChartProps) {
  const [historicalData, setHistoricalData] = useState<HistoricalGoldPrice[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d'>('30d');

  const isPositiveChange = parseFloat(priceChange) >= 0;
  const changeColor = isPositiveChange 
    ? DASHBOARD_COLORS.goldPriceSection.change.positive 
    : DASHBOARD_COLORS.goldPriceSection.change.negative;
  const priceChangeFormatted = isPositiveChange ? `+${priceChange}%` : `${priceChange}%`;

  useEffect(() => {
    async function loadHistoricalData() {
      try {
        setLoading(true);
        setError(null);
        
        // Convert timeRange to days
        const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
        const data = await fetchHistoricalGoldPrices(days);
        
        if (data.length > 0) {
          setHistoricalData(data);
        } else {
          setError('No historical data available');
        }
      } catch (err) {
        console.error('Error fetching historical gold prices:', err);
        setError('Failed to load gold price history');
      } finally {
        setLoading(false);
      }
    }

    loadHistoricalData();
  }, [timeRange]);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', { 
      style: 'currency', 
      currency: 'INR',
      maximumFractionDigits: 0 
    }).format(price);
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background p-3 border border-border rounded-md shadow-md">
          <p className="text-sm font-medium">{formatDate(label)}</p>
          <p className="text-sm text-foreground">
            <span className="font-medium">Price:</span> {formatPrice(payload[0].value)}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="h-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg md:text-xl">Gold Price Trend</CardTitle>
            <CardDescription>24K Gold price per gram</CardDescription>
          </div>
          <div className="flex flex-col items-end">
            <div className="text-xl md:text-2xl font-bold">
              {formatPrice(currentPrice)}
            </div>
            <div className="flex items-center text-sm" style={{ color: changeColor }}>
              {isPositiveChange ? (
                <ArrowUpIcon className="w-4 h-4 mr-1" />
              ) : (
                <ArrowDownIcon className="w-4 h-4 mr-1" />
              )}
              <span>{priceChangeFormatted}</span>
            </div>
          </div>
        </div>
        <div className="flex space-x-2 mt-4">
          <button 
            onClick={() => setTimeRange('7d')}
            className={`px-3 py-1 text-xs rounded-full ${
              timeRange === '7d' 
                ? 'bg-primary text-primary-foreground' 
                : 'bg-muted text-muted-foreground'
            }`}
          >
            7D
          </button>
          <button 
            onClick={() => setTimeRange('30d')}
            className={`px-3 py-1 text-xs rounded-full ${
              timeRange === '30d' 
                ? 'bg-primary text-primary-foreground' 
                : 'bg-muted text-muted-foreground'
            }`}
          >
            30D
          </button>
          <button 
            onClick={() => setTimeRange('90d')}
            className={`px-3 py-1 text-xs rounded-full ${
              timeRange === '90d' 
                ? 'bg-primary text-primary-foreground' 
                : 'bg-muted text-muted-foreground'
            }`}
          >
            90D
          </button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="w-full h-[250px] flex items-center justify-center">
            <div className="space-y-2 w-full">
              <Skeleton className="h-[250px] w-full" />
            </div>
          </div>
        ) : error ? (
          <div className="w-full h-[250px] flex items-center justify-center text-muted-foreground">
            {error}
          </div>
        ) : (
          <div className="h-[250px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={historicalData}
                margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="goldGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop 
                      offset="5%" 
                      stopColor={DASHBOARD_COLORS.goldPriceSection.chart.line} 
                      stopOpacity={0.8} 
                    />
                    <stop 
                      offset="95%" 
                      stopColor={DASHBOARD_COLORS.goldPriceSection.chart.fillEnd} 
                      stopOpacity={0} 
                    />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis 
                  dataKey="date" 
                  tickFormatter={formatDate} 
                  tick={{ fontSize: 12 }}
                />
                <YAxis 
                  tickFormatter={(value) => `₹${value.toLocaleString('en-IN')}`} 
                  tick={{ fontSize: 12 }}
                  domain={['dataMin - 100', 'dataMax + 100']}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area 
                  type="monotone" 
                  dataKey="price" 
                  stroke={DASHBOARD_COLORS.goldPriceSection.chart.line} 
                  fillOpacity={1}
                  fill="url(#goldGradient)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
}