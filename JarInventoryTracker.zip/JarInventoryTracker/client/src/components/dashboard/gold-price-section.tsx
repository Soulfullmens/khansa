import { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { GoldPriceChart } from './gold-price-chart';
import { fetchCurrentGoldPrice, getGoldPriceForecast } from '@/lib/gold-price-service';
import { LUXURY_PALETTE } from '@/lib/luxury-palette';
import { Button } from '@/components/ui/button';
import { TrendingUp, AlertCircle, Sparkles } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function GoldPriceSection() {
  const [goldPrice, setGoldPrice] = useState<number | null>(null);
  const [priceChange, setPriceChange] = useState<string>('0.00');
  const [forecast, setForecast] = useState<string | null>(null);
  const [forecastConfidence, setForecastConfidence] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showForecast, setShowForecast] = useState(false);

  useEffect(() => {
    async function fetchGoldPrice() {
      try {
        setLoading(true);
        setError(null);
        
        const priceData = await fetchCurrentGoldPrice();
        setGoldPrice(priceData.pricePerGram);
        setPriceChange(priceData.change24h);
        
        // Also fetch forecast but don't show it automatically
        const forecastData = await getGoldPriceForecast();
        setForecast(forecastData.prediction);
        setForecastConfidence(forecastData.confidence);
      } catch (err) {
        console.error('Error fetching gold price:', err);
        setError('Failed to load current gold price');
      } finally {
        setLoading(false);
      }
    }

    fetchGoldPrice();
    
    // Refresh price every 5 minutes
    const intervalId = setInterval(fetchGoldPrice, 5 * 60 * 1000);
    
    return () => clearInterval(intervalId);
  }, []);

  return (
    <div className="space-y-4">
      {loading ? (
        <Card>
          <CardHeader>
            <CardTitle><Skeleton className="h-7 w-48" /></CardTitle>
            <CardDescription><Skeleton className="h-5 w-32" /></CardDescription>
          </CardHeader>
          <CardContent>
            <Skeleton className="h-[300px] w-full" />
          </CardContent>
        </Card>
      ) : error ? (
        <Card className="border-red-200">
          <CardHeader>
            <CardTitle className="flex items-center text-red-500">
              <AlertCircle className="mr-2 h-5 w-5" />
              Error Loading Gold Price
            </CardTitle>
            <CardDescription>{error}</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => window.location.reload()}>
              Try Again
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          <GoldPriceChart 
            currentPrice={goldPrice || 0} 
            priceChange={priceChange} 
          />
          
          {forecast && (
            <Card className={`${showForecast ? 'border-gold-300' : 'border'} transition-all duration-200`}>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-base flex items-center">
                    <Sparkles className="h-4 w-4 mr-2" style={{ color: LUXURY_PALETTE.gold[500] }} />
                    AI Price Forecast
                  </CardTitle>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setShowForecast(!showForecast)}
                  >
                    {showForecast ? 'Hide' : 'Show'}
                  </Button>
                </div>
                {!showForecast && (
                  <CardDescription className="mt-0">
                    Get AI-powered gold price predictions
                  </CardDescription>
                )}
              </CardHeader>
              
              {showForecast && (
                <CardContent>
                  <div className="space-y-2">
                    <p className="text-sm">{forecast}</p>
                    <div className="flex items-center">
                      <div className="text-xs text-muted-foreground">
                        Confidence: {Math.round(forecastConfidence * 100)}%
                      </div>
                      <div className="ml-2 flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full rounded-full" 
                          style={{ 
                            width: `${forecastConfidence * 100}%`,
                            backgroundColor: LUXURY_PALETTE.gold[500]
                          }} 
                        />
                      </div>
                    </div>
                    <div className="flex justify-end">
                      <Button variant="outline" size="sm" className="mt-2">
                        <TrendingUp className="h-4 w-4 mr-2" />
                        Full Analysis
                      </Button>
                    </div>
                  </div>
                </CardContent>
              )}
            </Card>
          )}
        </>
      )}
    </div>
  );
}