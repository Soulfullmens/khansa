import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Flame, Award, Snowflake } from "lucide-react";
import { useStreaks } from "@/hooks/use-streaks";
import { useRewards } from "@/hooks/use-rewards";
import { Skeleton } from "@/components/ui/skeleton";

export function StreakCard() {
  const { streak, isLoading, checkIn, isCheckingIn, buyFreeze, isBuyingFreeze } = useStreaks();
  const { rewards, userPoints } = useRewards();
  
  // Find streak freeze reward
  const streakFreezeReward = rewards?.find(r => r.name === "Streak Freeze");
  const canAffordFreeze = 
    streakFreezeReward && 
    userPoints && 
    userPoints.availablePoints >= streakFreezeReward.cost;
  
  // Calculate next milestone (5, 10, 15, etc.)
  const getNextMilestone = (current: number) => {
    return Math.ceil(current / 5) * 5;
  };
  
  const renderCardContent = () => {
    if (isLoading) {
      return (
        <div className="space-y-5 py-6">
          <Skeleton className="h-8 w-full" />
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>
      );
    }
    
    if (!streak) {
      return (
        <div className="flex flex-col items-center justify-center h-36 space-y-4">
          <p className="text-center text-muted-foreground">Start your streak by checking in today!</p>
          <Button onClick={() => checkIn()} disabled={isCheckingIn}>
            Start Your Streak
          </Button>
        </div>
      );
    }
    
    const nextMilestone = getNextMilestone(streak.currentStreak || 0);
    const progress = ((streak.currentStreak || 0) % 5) / 5 * 100;
    
    return (
      <>
        <div className="flex justify-between items-start">
          <div>
            <p className="text-xl font-semibold">{streak.currentStreak} Days</p>
            <p className="text-sm text-muted-foreground">Current Streak</p>
          </div>
          
          <div className="text-right">
            <p className="text-xl font-semibold">{streak.longestStreak} Days</p>
            <p className="text-sm text-muted-foreground">Longest Streak</p>
          </div>
        </div>
        
        <div className="my-6">
          <div className="flex justify-between text-sm mb-2">
            <span>Progress to {nextMilestone} days</span>
            <span>{streak.currentStreak % 5}/{5} days</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
        
        <div className="flex gap-3 mt-4">
          <Button 
            className="flex-1" 
            onClick={() => checkIn()} 
            disabled={isCheckingIn}
          >
            <Flame className="mr-2 h-4 w-4" />
            Check In
          </Button>
          
          {streakFreezeReward && (
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={() => buyFreeze()}
              disabled={isBuyingFreeze || !canAffordFreeze || !!streak.streakFreezeUsed}
              title={
                streak.streakFreezeUsed 
                  ? "Streak freeze already active" 
                  : !canAffordFreeze 
                  ? `You need ${streakFreezeReward.cost} points` 
                  : "Buy a streak freeze"
              }
            >
              <Snowflake className="mr-2 h-4 w-4" /> 
              {streak.streakFreezeUsed ? "Active" : `Buy (${streakFreezeReward.cost}p)`}
            </Button>
          )}
        </div>
      </>
    );
  };
  
  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-medium flex items-center">
          <Flame className="mr-2 h-5 w-5 text-amber-500" />
          Daily Streak
        </CardTitle>
      </CardHeader>
      <CardContent>
        {renderCardContent()}
      </CardContent>
      <CardFooter className="pt-0">
        <p className="text-xs text-muted-foreground">
          Check in daily to earn points and unlock achievements
        </p>
      </CardFooter>
    </Card>
  );
}