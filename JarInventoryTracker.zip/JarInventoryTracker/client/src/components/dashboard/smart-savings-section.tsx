import { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { motion, AnimatePresence } from "framer-motion";
import { Icon } from "@/lib/icons";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { LUXURY_PALETTE, DASHBOARD_COLORS } from "@/lib/luxury-palette";
import { SavingsRecommendation } from "@/lib/ai-service";

export const SmartSavingsSection = () => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(true);
  const [recommendations, setRecommendations] = useState<SavingsRecommendation[] | null>(null);
  const [selectedRecommendation, setSelectedRecommendation] = useState<SavingsRecommendation | null>(null);
  const [showDetails, setShowDetails] = useState(false);

  useEffect(() => {
    const fetchRecommendations = async () => {
      try {
        setIsLoading(true);
        const response = await apiRequest('GET', '/api/savings/recommendations');
        const data = await response.json();
        setRecommendations(data);
      } catch (error) {
        toast({
          title: "Couldn't fetch savings recommendations",
          description: "We'll try again later",
          variant: "destructive"
        });
        setRecommendations([]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchRecommendations();
  }, [toast]);

  const handleRecommendationClick = (recommendation: SavingsRecommendation) => {
    setSelectedRecommendation(recommendation);
    setShowDetails(true);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy':
        return LUXURY_PALETTE.emerald[500];
      case 'medium':
        return LUXURY_PALETTE.gold[500];
      case 'hard':
        return LUXURY_PALETTE.burgundy[500];
      default:
        return LUXURY_PALETTE.neutral[500];
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'food':
        return 'ri-restaurant-line';
      case 'transportation':
        return 'ri-car-line';
      case 'entertainment':
        return 'ri-film-line';
      case 'shopping':
        return 'ri-shopping-bag-line';
      case 'utilities':
        return 'ri-home-wifi-line';
      case 'subscription':
        return 'ri-calendar-check-line';
      default:
        return 'ri-money-dollar-circle-line';
    }
  };

  if (isLoading) {
    return (
      <section className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-heading font-semibold text-lg">Smart Savings</h2>
          <span 
            className="text-xs px-2 py-1 rounded-full" 
            style={{ 
              background: `${LUXURY_PALETTE.royalBlue[100]}`, 
              color: `${LUXURY_PALETTE.royalBlue[800]}` 
            }}
          >
            AI Powered
          </span>
        </div>
        <Card style={{ borderColor: DASHBOARD_COLORS.smartSavings.border }} className="rounded-xl shadow-md border">
          <CardContent className="p-6">
            <div className="animate-pulse space-y-4">
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
                <div className="h-24 bg-gray-200 rounded"></div>
                <div className="h-24 bg-gray-200 rounded"></div>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>
    );
  }

  if (!recommendations || recommendations.length === 0) {
    return (
      <section className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-heading font-semibold text-lg">Smart Savings</h2>
          <span 
            className="text-xs px-2 py-1 rounded-full" 
            style={{ 
              background: `${LUXURY_PALETTE.royalBlue[100]}`, 
              color: `${LUXURY_PALETTE.royalBlue[800]}` 
            }}
          >
            AI Powered
          </span>
        </div>
        <Card style={{ borderColor: DASHBOARD_COLORS.smartSavings.border }} className="rounded-xl shadow-md border">
          <CardContent className="p-6 text-center">
            <div 
              style={{ background: LUXURY_PALETTE.royalBlue[100] }}
              className="h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-4"
            >
              <Icon icon="ri-robot-line" className="text-2xl" style={{ color: LUXURY_PALETTE.royalBlue[500] }} />
            </div>
            <h3 className="font-medium text-base mb-2">Analyzing your spending patterns</h3>
            <p className="text-sm text-gray-500">
              As you make more transactions, we'll analyze your spending habits and suggest personalized ways to save money.
            </p>
          </CardContent>
        </Card>
      </section>
    );
  }

  return (
    <section className="mb-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-heading font-semibold text-lg">Smart Savings</h2>
        <span 
          className="text-xs px-2 py-1 rounded-full" 
          style={{ 
            background: `${LUXURY_PALETTE.royalBlue[100]}`, 
            color: `${LUXURY_PALETTE.royalBlue[800]}` 
          }}
        >
          AI Powered
        </span>
      </div>
      
      <AnimatePresence mode="wait">
        {showDetails && selectedRecommendation ? (
          <motion.div
            key="details"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card 
              style={{ borderColor: DASHBOARD_COLORS.smartSavings.border }} 
              className="rounded-xl shadow-md border overflow-hidden"
            >
              <CardContent className="p-0">
                <div 
                  style={{ background: LUXURY_PALETTE.royalBlue[50] }} 
                  className="p-4 border-b"
                >
                  <div className="flex justify-between items-center">
                    <h3 className="font-medium">{selectedRecommendation.title}</h3>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => setShowDetails(false)}
                      className="h-8 w-8 p-0 rounded-full"
                    >
                      <Icon icon="ri-close-line" className="text-lg" />
                    </Button>
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <Badge 
                      style={{ 
                        background: LUXURY_PALETTE.royalBlue[100], 
                        color: LUXURY_PALETTE.royalBlue[800] 
                      }}
                      className="px-3 py-1"
                    >
                      {selectedRecommendation.category}
                    </Badge>
                    <div 
                      style={{ color: getDifficultyColor(selectedRecommendation.difficulty) }}
                      className="flex items-center text-sm font-medium"
                    >
                      <span className="mr-1">{selectedRecommendation.difficulty.charAt(0).toUpperCase() + selectedRecommendation.difficulty.slice(1)}</span>
                      <div className="flex">
                        {['easy', 'medium', 'hard'].map((level, i) => (
                          <div 
                            key={i} 
                            className="w-2 h-2 rounded-full mx-0.5" 
                            style={{ 
                              background: level === selectedRecommendation.difficulty 
                                ? getDifficultyColor(level) 
                                : LUXURY_PALETTE.neutral[200]
                            }}
                          ></div>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <div className="mb-6">
                    <p className="text-sm mb-4">{selectedRecommendation.description}</p>
                    
                    <div 
                      style={{ borderColor: LUXURY_PALETTE.emerald[200] }}
                      className="border rounded-lg p-4 bg-emerald-50 mb-4"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Potential Savings</span>
                        <span 
                          style={{ color: LUXURY_PALETTE.emerald[700] }}
                          className="font-medium text-lg"
                        >
                          ₹{selectedRecommendation.potentialSavings.toLocaleString()}
                        </span>
                      </div>
                    </div>
                    
                    {selectedRecommendation.implementationSteps && (
                      <div>
                        <h4 className="font-medium text-sm mb-2">Implementation Steps</h4>
                        <ul className="space-y-2">
                          {selectedRecommendation.implementationSteps.map((step, i) => (
                            <li key={i} className="flex items-start">
                              <div 
                                style={{ background: LUXURY_PALETTE.royalBlue[100] }}
                                className="w-5 h-5 rounded-full flex items-center justify-center mr-2 mt-0.5 flex-shrink-0"
                              >
                                <span 
                                  style={{ color: LUXURY_PALETTE.royalBlue[700] }}
                                  className="text-xs font-medium"
                                >
                                  {i+1}
                                </span>
                              </div>
                              <span className="text-sm">{step}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button 
                      style={{ 
                        background: LUXURY_PALETTE.royalBlue[600],
                        color: 'white'
                      }}
                      className="flex-1 hover:shadow-lg"
                      onClick={() => setShowDetails(false)}
                    >
                      Try This Strategy
                    </Button>
                    <Button 
                      variant="outline" 
                      className="flex-1 border-gray-300"
                      onClick={() => setShowDetails(false)}
                    >
                      Remind Me Later
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <motion.div
            key="list"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card style={{ borderColor: DASHBOARD_COLORS.smartSavings.border }} className="rounded-xl shadow-md border">
              <CardContent className="p-6">
                <p className="text-sm text-gray-600 mb-4">
                  Based on your spending habits, here are some ways you could save money:
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {recommendations?.map((recommendation: SavingsRecommendation, i: number) => (
                    <motion.div 
                      key={recommendation.id} 
                      whileHover={{ scale: 1.03 }}
                      transition={{ type: "spring", stiffness: 400, damping: 10 }}
                      onClick={() => handleRecommendationClick(recommendation)}
                      className="cursor-pointer"
                    >
                      <Card 
                        style={{ 
                          borderColor: LUXURY_PALETTE.neutral[200],
                          background: LUXURY_PALETTE.neutral[50]
                        }} 
                        className="border rounded-lg p-4 hover:shadow-md transition-shadow relative overflow-hidden"
                      >
                        <div className="flex items-start">
                          <div 
                            style={{ 
                              background: LUXURY_PALETTE.neutral[100],
                              color: DASHBOARD_COLORS.smartSavings.categories[i % DASHBOARD_COLORS.smartSavings.categories.length]
                            }}
                            className="w-10 h-10 rounded-full flex items-center justify-center mr-3 flex-shrink-0"
                          >
                            <Icon icon={getCategoryIcon(recommendation.category)} className="text-lg" />
                          </div>
                          <div>
                            <h3 className="font-medium text-sm mb-1">{recommendation.title}</h3>
                            <p 
                              style={{ color: LUXURY_PALETTE.emerald[700] }}
                              className="text-xs font-medium"
                            >
                              Save up to ₹{recommendation.potentialSavings.toLocaleString()}
                            </p>
                          </div>
                        </div>
                        <div 
                          style={{ 
                            background: DASHBOARD_COLORS.smartSavings.categories[i % DASHBOARD_COLORS.smartSavings.categories.length],
                            opacity: 0.1
                          }}
                          className="absolute -bottom-6 -right-6 w-16 h-16 rounded-full"
                        ></div>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};

export default SmartSavingsSection;