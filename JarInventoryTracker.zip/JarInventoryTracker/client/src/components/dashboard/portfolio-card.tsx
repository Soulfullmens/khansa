import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import type { Investment } from "@shared/schema";
import { useState, useEffect } from "react";
import { apiRequest } from "@/lib/queryClient";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { COLORS } from "@/lib/constants";
import { Icon } from "@/lib/icons";

const PortfolioCard = () => {
  const { toast } = useToast();
  const [amount, setAmount] = useState("");
  const [isAddingMoney, setIsAddingMoney] = useState(false);
  const [isWithdrawing, setIsWithdrawing] = useState(false);
  const [activeTab, setActiveTab] = useState("overview"); // "overview" or "allocation"
  const [portfolioValue, setPortfolioValue] = useState(0);
  const [countUp, setCountUp] = useState(0);

  const { data: investment, isLoading } = useQuery<Investment>({
    queryKey: ["/api/investments"],
  });

  // Count up animation for the portfolio value
  useEffect(() => {
    if (investment?.totalValue) {
      const targetValue = parseFloat(investment.totalValue.toString());
      setPortfolioValue(targetValue);
      
      const duration = 1500; // ms
      const frameDuration = 1000 / 60; // 60fps
      const totalFrames = Math.round(duration / frameDuration);
      const valueIncrement = targetValue / totalFrames;
      
      let currentFrame = 0;
      let currentValue = 0;
      
      const timer = setInterval(() => {
        currentFrame++;
        currentValue += valueIncrement;
        
        if (currentFrame === totalFrames) {
          clearInterval(timer);
          setCountUp(targetValue);
        } else {
          setCountUp(currentValue);
        }
      }, frameDuration);
      
      return () => clearInterval(timer);
    }
  }, [investment?.totalValue]);

  // Prepare data for the pie chart
  const pieChartData = [
    { name: 'Digital Gold', value: investment?.goldValue ? parseFloat(investment.goldValue.toString()) : 0 },
    { name: 'Other Investments', value: investment?.otherInvestments ? parseFloat(investment.otherInvestments.toString()) : 0 }
  ];

  const COLORS_ARRAY = [COLORS.gold[500], COLORS.navy[700]];

  const handleAddMoney = async () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: "Invalid amount",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }

    try {
      await apiRequest("POST", "/api/investments/add", { amount });
      queryClient.invalidateQueries({ queryKey: ["/api/investments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      setAmount("");
      setIsAddingMoney(false);
      
      toast({
        title: "Money added successfully",
        description: `₹${amount} has been added to your investments`,
      });
    } catch (error) {
      toast({
        title: "Failed to add money",
        description: "An error occurred while processing your request",
        variant: "destructive",
      });
    }
  };

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-2 shadow-md rounded-md text-xs">
          <p className="font-medium">{payload[0].name}</p>
          <p className="text-gray-600">₹{payload[0].value.toFixed(2)}</p>
          <p className="text-gray-600">{((payload[0].value / portfolioValue) * 100).toFixed(1)}%</p>
        </div>
      );
    }
    return null;
  };

  if (isLoading) {
    return (
      <Card className="bg-white rounded-xl shadow-md p-6 mb-6">
        <CardContent className="p-0">
          <div className="h-64 flex items-center justify-center">
            <div className="animate-pulse w-full">
              <div className="h-4 bg-gray-200 rounded w-48 mb-4"></div>
              <div className="h-8 bg-gray-200 rounded w-64 mb-6"></div>
              <div className="flex justify-between mb-6">
                <div className="h-6 bg-gray-200 rounded w-32"></div>
                <div className="h-6 bg-gray-200 rounded w-32"></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="h-24 bg-gray-200 rounded"></div>
                <div className="h-24 bg-gray-200 rounded"></div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white rounded-xl shadow-md p-6 mb-6 overflow-hidden">
      <CardContent className="p-0">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-heading font-semibold text-lg">Your Portfolio</h2>
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button 
              className={`px-3 py-1 text-xs rounded-md transition-colors ${
                activeTab === "overview" 
                  ? "bg-white text-gray-800 shadow-sm" 
                  : "text-gray-600 hover:text-gray-800"
              }`}
              onClick={() => setActiveTab("overview")}
            >
              Overview
            </button>
            <button 
              className={`px-3 py-1 text-xs rounded-md transition-colors ${
                activeTab === "allocation" 
                  ? "bg-white text-gray-800 shadow-sm" 
                  : "text-gray-600 hover:text-gray-800"
              }`}
              onClick={() => setActiveTab("allocation")}
            >
              Allocation
            </button>
          </div>
        </div>
        
        <AnimatePresence mode="wait">
          {activeTab === "overview" ? (
            <motion.div
              key="overview"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <div className="flex flex-col md:flex-row md:items-center mb-6">
                <div className="flex-1">
                  <p className="text-sm text-gray-500 mb-1">Total Investment Value</p>
                  <div className="flex items-baseline">
                    <motion.span 
                      className="font-mono text-2xl md:text-3xl font-medium"
                      key={countUp}
                    >
                      ₹{countUp.toFixed(2)}
                    </motion.span>
                    <motion.span 
                      className="ml-2 text-green-500 text-sm flex items-center"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.5 }}
                    >
                      <Icon icon="ri-arrow-up-line" className="mr-1" /> 3.2%
                    </motion.span>
                  </div>
                </div>
                
                <div className="mt-4 md:mt-0 md:ml-4 flex flex-row md:flex-col space-x-4 md:space-x-0 md:space-y-2">
                  <AnimatePresence mode="wait">
                    {isAddingMoney ? (
                      <motion.div 
                        className="flex flex-col space-y-2 w-full"
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.9 }}
                      >
                        <div className="flex items-center space-x-2">
                          <Input
                            type="number"
                            placeholder="Enter amount"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                            className="w-full"
                          />
                          <Button 
                            size="sm"
                            className="bg-gradient-to-r from-[#F7B801] to-[#FFC833] text-white"
                            onClick={handleAddMoney}
                          >
                            Add
                          </Button>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setIsAddingMoney(false)}
                        >
                          Cancel
                        </Button>
                      </motion.div>
                    ) : (
                      <motion.div
                        className="flex flex-row md:flex-col space-x-4 md:space-x-0 md:space-y-2 w-full"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                      >
                        <Button 
                          className="bg-gradient-to-r from-[#F7B801] to-[#FFC833] text-white py-2 px-4 rounded-lg text-sm font-medium flex-1 flex items-center justify-center hover:shadow-lg transition-shadow"
                          onClick={() => setIsAddingMoney(true)}
                        >
                          <Icon icon="ri-add-line" className="mr-1" /> Add Money
                        </Button>
                        
                        <Button
                          variant="outline"
                          className="bg-gray-100 text-[#1A2E44] border-none py-2 px-4 rounded-lg text-sm font-medium flex-1 flex items-center justify-center hover:bg-gray-200 transition-colors"
                        >
                          <Icon icon="ri-exchange-line" className="mr-1" /> Withdraw
                        </Button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <motion.div 
                  className="bg-[#FFF8E6] rounded-lg p-4 relative overflow-hidden hover:shadow-md transition-shadow"
                  whileHover={{ scale: 1.02 }}
                  transition={{ type: "spring", stiffness: 400, damping: 10 }}
                >
                  <div className="flex items-center mb-2">
                    <div className="bg-[#F7B801] h-8 w-8 rounded-full flex items-center justify-center mr-2">
                      <Icon icon="ri-coin-line" className="text-white" />
                    </div>
                    <span className="font-medium text-sm">Digital Gold</span>
                  </div>
                  <p className="font-mono text-lg font-medium">{investment?.goldAmount || "0.00"} gm</p>
                  <p className="text-sm text-gray-600">₹{investment?.goldValue || "0.00"}</p>
                  <div className="absolute -bottom-4 -right-4 h-12 w-12 bg-[#F7B801] opacity-20 rounded-full"></div>
                  <div className="absolute -bottom-2 -right-2 h-8 w-8 bg-[#F7B801] opacity-20 rounded-full"></div>
                </motion.div>
                
                <motion.div 
                  className="bg-[#E6EBF0] rounded-lg p-4 relative overflow-hidden hover:shadow-md transition-shadow"
                  whileHover={{ scale: 1.02 }}
                  transition={{ type: "spring", stiffness: 400, damping: 10 }}
                >
                  <div className="flex items-center mb-2">
                    <div className="bg-[#1A2E44] h-8 w-8 rounded-full flex items-center justify-center mr-2">
                      <Icon icon="ri-funds-line" className="text-white" />
                    </div>
                    <span className="font-medium text-sm">Other Investments</span>
                  </div>
                  <p className="font-mono text-lg font-medium">₹{investment?.otherInvestments || "0.00"}</p>
                  <p className="text-sm text-gray-600">2 active funds</p>
                  <div className="absolute -bottom-4 -right-4 h-12 w-12 bg-[#1A2E44] opacity-20 rounded-full"></div>
                  <div className="absolute -bottom-2 -right-2 h-8 w-8 bg-[#1A2E44] opacity-20 rounded-full"></div>
                </motion.div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="allocation"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="h-64"
            >
              <div className="flex items-center justify-center h-full">
                <div className="w-full max-w-xs">
                  <h3 className="text-center font-medium mb-2">Portfolio Allocation</h3>
                  <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={pieChartData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          dataKey="value"
                          animationDuration={1500}
                          animationBegin={0}
                          animationEasing="ease-out"
                          paddingAngle={2}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          labelLine={false}
                        >
                          {pieChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS_ARRAY[index % COLORS_ARRAY.length]} />
                          ))}
                        </Pie>
                        <Tooltip content={<CustomTooltip />} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex justify-around text-xs text-center mt-2">
                    <div>
                      <div className="h-3 w-3 rounded-full bg-[#F7B801] mx-auto mb-1"></div>
                      <p>Digital Gold</p>
                    </div>
                    <div>
                      <div className="h-3 w-3 rounded-full bg-[#1A2E44] mx-auto mb-1"></div>
                      <p>Other Investments</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
};

export default PortfolioCard;
