import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Award, LayoutDashboard, CoinsIcon, Target, History, HelpCircle, User, LogOut } from "lucide-react";
import { GRADIENTS } from "@/lib/luxury-palette";

const Sidebar = () => {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  return (
    <aside className="hidden md:block md:w-64 bg-white h-screen sticky top-0 border-r border-gray-200">
      <div className="p-6">
        <div className="flex items-center mb-8">
          <div 
            style={{ background: GRADIENTS.goldPrimary }} 
            className="h-10 w-10 rounded-lg flex items-center justify-center mr-3 shadow-md"
          >
            <span className="text-white text-lg font-bold">₹</span>
          </div>
          <h1 className="font-heading font-bold text-xl text-gray-800">Khansa</h1>
        </div>
        
        <div className="flex items-center space-x-3 mb-8">
          <div className="relative">
            <img 
              src={user?.profileImage || "https://images.unsplash.com/photo-1618044733300-9472054094ee?auto=format&fit=crop&q=80&w=100&h=100"} 
              alt="User profile" 
              className="h-12 w-12 rounded-full object-cover border-2 border-amber-500/50"
            />
            <div className="absolute -bottom-1 -right-1 h-5 w-5 rounded-full bg-green-500 border-2 border-white"></div>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-800">{user?.name || "User"}</p>
            <p className="text-xs text-gray-500">{user?.userLevel || "Premium Member"}</p>
          </div>
        </div>
        
        <nav className="space-y-1.5">
          <Link href="/">
            <a className={`flex items-center p-3 rounded-lg transition-colors ${
              location === "/" 
                ? "bg-amber-50 text-amber-700 font-medium" 
                : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
            }`}>
              <LayoutDashboard className="h-5 w-5 mr-3" />
              <span>Dashboard</span>
            </a>
          </Link>
          
          <Link href="/gold">
            <a className={`flex items-center p-3 rounded-lg transition-colors ${
              location === "/gold" 
                ? "bg-amber-50 text-amber-700 font-medium" 
                : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
            }`}>
              <CoinsIcon className="h-5 w-5 mr-3" />
              <span>Investments</span>
            </a>
          </Link>
          
          <Link href="/goals">
            <a className={`flex items-center p-3 rounded-lg transition-colors ${
              location === "/goals" 
                ? "bg-amber-50 text-amber-700 font-medium" 
                : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
            }`}>
              <Target className="h-5 w-5 mr-3" />
              <span>Goals</span>
            </a>
          </Link>
          
          <Link href="/rewards">
            <a className={`flex items-center p-3 rounded-lg transition-colors ${
              location === "/rewards" 
                ? "bg-amber-50 text-amber-700 font-medium" 
                : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
            }`}>
              <Award className="h-5 w-5 mr-3" />
              <span>Rewards</span>
            </a>
          </Link>
          
          <Link href="#">
            <a className={`flex items-center p-3 rounded-lg transition-colors text-gray-600 hover:bg-gray-50 hover:text-gray-900`}>
              <History className="h-5 w-5 mr-3" />
              <span>Transactions</span>
            </a>
          </Link>
          
          <Link href="/profile">
            <a className={`flex items-center p-3 rounded-lg transition-colors ${
              location === "/profile" 
                ? "bg-amber-50 text-amber-700 font-medium" 
                : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
            }`}>
              <User className="h-5 w-5 mr-3" />
              <span>Profile</span>
            </a>
          </Link>
        </nav>
      </div>
      
      <div className="absolute bottom-0 w-full p-6 space-y-3">
        <button 
          onClick={() => logoutMutation.mutate()}
          className="w-full flex items-center p-3 rounded-lg text-gray-700 hover:bg-red-50 hover:text-red-700 transition-colors"
        >
          <LogOut className="h-5 w-5 mr-3" />
          <span>Logout</span>
        </button>
        
        <div className="bg-gray-50 border border-gray-100 p-4 rounded-xl shadow-sm">
          <div className="flex items-center mb-2">
            <HelpCircle className="h-4 w-4 text-amber-600 mr-2" />
            <p className="text-sm font-medium">Need help?</p>
          </div>
          <p className="text-xs text-gray-500 mb-3">Our support team is a click away</p>
          <button 
            style={{ background: GRADIENTS.darkSlate }}
            className="text-sm w-full py-2 text-center rounded-lg text-white shadow-sm"
          >
            Contact Support
          </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
