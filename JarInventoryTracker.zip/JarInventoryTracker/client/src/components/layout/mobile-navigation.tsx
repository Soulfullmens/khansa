import { useState } from "react";
import { Link, useLocation } from "wouter";
import QuickActionModal from "@/components/modals/quick-action-modal";
import { LayoutDashboard, CoinsIcon, Plus, Target, Award, User } from "lucide-react";
import { GRADIENTS } from "@/lib/luxury-palette";

const MobileNavigation = () => {
  const [location] = useLocation();
  const [showQuickActionModal, setShowQuickActionModal] = useState(false);

  return (
    <>
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 pb-2 pt-3 md:hidden z-10 shadow-md">
        <div className="flex justify-around items-center px-2">
          <Link href="/">
            <a className={`flex flex-col items-center py-1 ${location === "/" 
              ? "text-amber-600" 
              : "text-gray-500"}`}
            >
              <LayoutDashboard className="h-5 w-5" />
              <span className="text-xs mt-1">Home</span>
            </a>
          </Link>
          
          <Link href="/gold">
            <a className={`flex flex-col items-center py-1 ${location === "/gold" 
              ? "text-amber-600" 
              : "text-gray-500"}`}
            >
              <CoinsIcon className="h-5 w-5" />
              <span className="text-xs mt-1">Invest</span>
            </a>
          </Link>
          
          <button 
            onClick={() => setShowQuickActionModal(true)}
            className="flex flex-col items-center -mt-8"
          >
            <div 
              style={{ background: GRADIENTS.goldPrimary }}
              className="rounded-full h-14 w-14 flex items-center justify-center shadow-lg"
            >
              <Plus className="h-6 w-6 text-white" />
            </div>
          </button>
          
          <Link href="/rewards">
            <a className={`flex flex-col items-center py-1 ${location === "/rewards" 
              ? "text-amber-600" 
              : "text-gray-500"}`}
            >
              <Award className="h-5 w-5" />
              <span className="text-xs mt-1">Rewards</span>
            </a>
          </Link>
          
          <Link href="/profile">
            <a className={`flex flex-col items-center py-1 ${location === "/profile" 
              ? "text-amber-600" 
              : "text-gray-500"}`}
            >
              <User className="h-5 w-5" />
              <span className="text-xs mt-1">Profile</span>
            </a>
          </Link>
        </div>
      </nav>

      <QuickActionModal 
        isOpen={showQuickActionModal} 
        onClose={() => setShowQuickActionModal(false)} 
      />
    </>
  );
};

export default MobileNavigation;
