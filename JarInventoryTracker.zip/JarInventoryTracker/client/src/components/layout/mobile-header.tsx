import { useAuth } from "@/hooks/use-auth";

const MobileHeader = () => {
  const { user } = useAuth();

  return (
    <header className="bg-gradient-to-r from-[#1A2E44] to-[#2D4D6E] text-white p-4 md:hidden sticky top-0 z-10">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <img 
            src={user?.profileImage || "https://images.unsplash.com/photo-1618044733300-9472054094ee?auto=format&fit=crop&q=80&w=100&h=100"} 
            alt="User profile" 
            className="h-10 w-10 rounded-full object-cover border-2 border-[#F7B801]"
          />
          <div>
            <p className="text-sm font-medium">Hi, {user?.name?.split(' ')[0] || "User"}! 👋</p>
            <p className="text-xs opacity-80">{user?.userLevel || "Gold Saver"}</p>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <button className="relative">
            <i className="ri-notification-3-line text-xl"></i>
            <span className="absolute -top-1 -right-1 bg-red-500 rounded-full w-4 h-4 text-xs flex items-center justify-center">3</span>
          </button>
          <button><i className="ri-settings-2-line text-xl"></i></button>
        </div>
      </div>
    </header>
  );
};

export default MobileHeader;
