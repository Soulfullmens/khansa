import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import GoldCoin3D from './gold-coin-3d';

interface PremiumHeroSceneProps {
  className?: string;
}

function PremiumHeroScene({ className = "" }: PremiumHeroSceneProps) {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  
  // Simplified mouse tracking for parallax
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const { currentTarget, clientX, clientY } = e;
    const { left, top, width, height } = currentTarget.getBoundingClientRect();
    
    const x = (clientX - left) / width - 0.5;
    const y = (clientY - top) / height - 0.5;
    
    setMousePosition({ x, y });
  };
  
  // Coin positions
  const coins = [
    { size: 80, x: '-10%', y: '20%', delay: 0.2 },
    { size: 100, x: '10%', y: '60%', delay: 0.5 },
    { size: 60, x: '60%', y: '30%', delay: 0.3 },
    { size: 120, x: '65%', y: '70%', delay: 0.1 },
  ];
  
  return (
    <div 
      className={`relative overflow-hidden bg-gradient-to-br from-amber-50 to-amber-100 rounded-3xl ${className}`}
      onMouseMove={handleMouseMove}
    >
      {/* Animated gradient background */}
      <div 
        className="absolute inset-0 transition-transform duration-200 ease-out"
        style={{ 
          backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(245, 158, 11, 0.1) 0%, rgba(251, 191, 36, 0.05) 50%, rgba(255, 255, 255, 0) 100%)',
          transform: `translate(${mousePosition.x * 20}px, ${mousePosition.y * 20}px)`,
        }}
      />
      
      {/* Luxury patterns */}
      <div className="absolute inset-0 opacity-10" style={{ 
        backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M54.627 0l.83.828-1.415 1.415L51.8 0h2.827zM5.373 0l-.83.828L5.96 2.243 8.2 0H5.374zM48.97 0l3.657 3.657-1.414 1.414L46.143 0h2.828zM11.03 0L7.372 3.657 8.787 5.07 13.857 0H11.03zm32.284 0L49.8 6.485 48.384 7.9l-7.9-7.9h2.83zM16.686 0L10.2 6.485 11.616 7.9l7.9-7.9h-2.83zm20.97 0l9.315 9.314-1.414 1.414L34.828 0h2.83zM22.344 0L13.03 9.314l1.414 1.414L25.172 0h-2.83zM32 0l12.142 12.142-1.414 1.414L30 .828 17.272 13.556l-1.414-1.414L28 0h4zM.284 0l28 28-1.414 1.414L0 2.544v2.83L25.456 30l-1.414 1.414-28-28L0 0h.284zM0 5.373l25.456 25.455-1.414 1.415L0 8.2v2.83l21.627 21.628-1.414 1.414L0 13.657v2.828l17.8 17.8-1.414 1.414L0 19.1v2.83l14.142 14.14-1.414 1.415L0 24.544v2.83l10.314 10.313-1.414 1.414L0 30v2.828l6.485 6.485-1.414 1.415L0 35.373v2.83l2.657 2.656-1.414 1.415L0 40.717v2.83l-1.414 1.414L0 47.803v2.83l-1.414 1.415L0 54.627v2.83L0 60h2.828L60 2.828V0h-2.83L0 57.172V60h5.657L60 5.657V0h-2.83L0 52.343V60h8.485L60 8.485V0h-2.83L0 47.515V60h11.314L60 11.314V0h-2.83L0 42.687V60h14.142L60 14.142V0h-2.83L0 37.858V60h17.8L60 16.97V0h-2.83L0 33.03V60h20.627L60 20.627V0h-2.83L0 28.373V60H24.28L60 24.28V0h-2.83L0 23.03V60h28L60 28V0h-2.83L0 17.272V60h32.657L60 32.657V0h-2.83L0 11.515V60h37.515L60 37.515V0h-2.83L0 5.757V60h42.343L60 42.343V0h-2.83L0 0v60h47.172L60 47.172V0h-2.83L0 0v60h52.9L60 56.9V0h-2.83L0 0v60h57.627L60 57.627V0h-2.83L0 0v60h60L60 0H0v60z\' fill=\'%23B45309\' fill-opacity=\'1\' fill-rule=\'evenodd\'/%3E%3C/svg%3E")',
        backgroundSize: '30px 30px',
      }} />
      
      {/* Main animated container */}
      <motion.div 
        className="relative h-full flex flex-col items-center justify-center p-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        {/* Logo */}
        <motion.div 
          className="text-4xl font-serif font-bold text-amber-800 mb-6 tracking-wider"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3, duration: 0.8 }}
        >
          KHANSA
        </motion.div>
        
        {/* Tagline */}
        <motion.div 
          className="text-amber-700 text-center max-w-md mb-12"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.5 }}
        >
          <h2 className="text-xl font-medium mb-2">Premium Gold Investments</h2>
          <p className="text-sm text-amber-600/80">
            Transform your savings into gold with our intelligent, goal-based investment platform. Experience luxury in every investment.
          </p>
        </motion.div>
        
        {/* 3D Coins */}
        {coins.map((coin, index) => (
          <motion.div
            key={index}
            className="absolute"
            style={{ 
              left: coin.x, 
              top: coin.y,
              zIndex: index 
            }}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ 
              delay: coin.delay, 
              duration: 0.8
            }}
          >
            <GoldCoin3D size={coin.size} />
          </motion.div>
        ))}
        
        {/* Shimmer effects */}
        <motion.div 
          className="absolute top-1/4 left-1/3 w-40 h-40 rounded-full transition-transform duration-200 ease-out"
          style={{ 
            background: 'radial-gradient(circle, rgba(251, 191, 36, 0.3) 0%, rgba(251, 191, 36, 0) 70%)',
            transform: `translate(${mousePosition.x * -15}px, ${mousePosition.y * -15}px)` 
          }}
          animate={{ 
            opacity: [0.5, 0.8, 0.5]
          }}
          transition={{ 
            duration: 3, 
            repeat: Infinity,
            repeatType: "reverse" 
          }}
        />
        
        <motion.div 
          className="absolute bottom-1/4 right-1/3 w-60 h-60 rounded-full transition-transform duration-200 ease-out"
          style={{ 
            background: 'radial-gradient(circle, rgba(251, 191, 36, 0.2) 0%, rgba(251, 191, 36, 0) 70%)',
            transform: `translate(${mousePosition.x * -20}px, ${mousePosition.y * -20}px)` 
          }}
          animate={{ 
            opacity: [0.3, 0.6, 0.3]
          }}
          transition={{ 
            duration: 4, 
            repeat: Infinity,
            repeatType: "reverse",
            delay: 1 
          }}
        />
      </motion.div>
    </div>
  );
}

export default PremiumHeroScene;