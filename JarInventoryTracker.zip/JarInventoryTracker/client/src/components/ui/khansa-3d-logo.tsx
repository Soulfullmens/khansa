import React from 'react';
import { motion } from 'framer-motion';

interface Khansa3DLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

function Khansa3DLogo({ className = "", size = "md" }: Khansa3DLogoProps) {
  // Sizes for different variants
  const sizes = {
    sm: "w-28 h-10",
    md: "w-44 h-14", 
    lg: "w-60 h-20"
  };
  
  return (
    <div className={`relative ${className} ${sizes[size]}`}>
      {/* Logo base with 3D effect */}
      <div 
        className="w-full h-full rounded-xl relative overflow-hidden cursor-pointer group"
        style={{ 
          boxShadow: '0 5px 15px -5px rgba(245, 190, 61, 0.4)',
          transition: 'transform 0.2s ease-out, box-shadow 0.2s ease-out'
        }}
      >
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-amber-50 to-amber-100 border border-amber-200/50 rounded-xl" />
        
        {/* Text container */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="relative">
            {/* Shadow text for 3D effect */}
            <div className="absolute -bottom-[2px] -right-[2px] text-amber-800/10 font-bold text-2xl md:text-3xl font-serif">
              Khansa
            </div>
            
            {/* Main gradient text */}
            <div className="relative text-transparent bg-clip-text bg-gradient-to-r from-amber-600 to-amber-800 font-bold text-2xl md:text-3xl font-serif">
              Khansa
            </div>
            
            {/* Gold accent */}
            <div className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-yellow-400 shadow-[0_0_8px_rgba(250,204,21,0.8)]" />
          </div>
        </div>
        
        {/* Shine effect */}
        <motion.div 
          className="absolute inset-0 bg-gradient-to-r from-transparent via-amber-400/20 to-transparent"
          animate={{ x: ['-100%', '100%'] }}
          transition={{ 
            duration: 3, 
            repeat: Infinity,
            repeatType: "loop",
            ease: "easeInOut" 
          }}
        />
      </div>
      
      {/* Tagline */}
      <div className="text-center text-amber-800/70 text-xs mt-1 font-medium">
        Premium Gold Investments
      </div>
    </div>
  );
}

export default Khansa3DLogo;