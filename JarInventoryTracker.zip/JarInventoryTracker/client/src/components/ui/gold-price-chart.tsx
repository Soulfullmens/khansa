import { useMemo, useState } from "react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Area,
  ComposedChart,
  ReferenceLine
} from "recharts";
import { COLORS } from "@/lib/constants";
import { motion } from "framer-motion";

interface GoldPriceChartProps {
  data: Array<{ date: string; price: number }>;
  timeframe?: string;
}

const formatPrice = (value: number) => {
  return `₹${value.toFixed(2)}`;
};

const formatDate = (dateStr: string) => {
  const date = new Date(dateStr);
  return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
};

const GoldPriceChart: React.FC<GoldPriceChartProps> = ({ 
  data,
  timeframe = "Past Month" 
}) => {
  const [hoveredPoint, setHoveredPoint] = useState<number | null>(null);
  const [showAveragePrice, setShowAveragePrice] = useState(false);

  const chartData = useMemo(() => {
    if (!data || data.length === 0) return [];
    
    // Filter data based on timeframe
    let filteredData;
    if (timeframe === "Past Month") {
      filteredData = data.slice(-30);
    } else if (timeframe === "Past 3 Months") {
      filteredData = data.slice(-90);
    } else if (timeframe === "Past Year") {
      filteredData = data.slice(-365);
    } else {
      filteredData = data;
    }
    
    return filteredData;
  }, [data, timeframe]);

  const averagePrice = useMemo(() => {
    if (!chartData || chartData.length === 0) return 0;
    const sum = chartData.reduce((acc, item) => acc + item.price, 0);
    return sum / chartData.length;
  }, [chartData]);

  if (!chartData || chartData.length === 0) {
    return (
      <div className="h-48 bg-gray-50 rounded-lg flex items-center justify-center">
        <p className="text-gray-500">No data available</p>
      </div>
    );
  }

  return (
    <div className="relative">
      <div className="absolute top-0 right-0 z-10">
        <button 
          className={`text-xs px-2 py-1 rounded-md transition-colors ${
            showAveragePrice 
              ? 'bg-gold-100 text-gold-600' 
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
          onClick={() => setShowAveragePrice(!showAveragePrice)}
        >
          {showAveragePrice ? 'Hide Average' : 'Show Average'}
        </button>
      </div>
      
      <div className="h-48 bg-gray-50 rounded-lg mb-4 relative overflow-hidden">
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#F7B801] to-[#FFC833] opacity-10 rounded-b-lg"></div>
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart
            data={chartData}
            margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
            onMouseMove={(e) => {
              if (e.activeTooltipIndex !== undefined) {
                setHoveredPoint(e.activeTooltipIndex);
              }
            }}
            onMouseLeave={() => setHoveredPoint(null)}
          >
            <defs>
              <linearGradient id="goldGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={COLORS.gold[500]} stopOpacity={0.3}/>
                <stop offset="95%" stopColor={COLORS.gold[500]} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
            <XAxis 
              dataKey="date"
              tickFormatter={(value) => {
                const date = new Date(value);
                return date.getDate().toString();
              }}
              tick={{ fontSize: 10 }}
              stroke="#94A3B8"
              axisLine={false}
              tickLine={false}
            />
            <YAxis
              domain={['dataMin - 100', 'dataMax + 100']}
              tickFormatter={(value) => `₹${Math.round(value)}`}
              tick={{ fontSize: 10 }}
              stroke="#94A3B8"
              axisLine={false}
              tickLine={false}
            />
            <Tooltip
              formatter={(value: number) => [formatPrice(value), 'Price']}
              labelFormatter={(label) => `Date: ${formatDate(label)}`}
              contentStyle={{
                backgroundColor: 'white',
                borderRadius: '8px',
                border: 'none',
                boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
                fontSize: '12px',
              }}
              cursor={{ stroke: COLORS.navy[300], strokeDasharray: '3 3' }}
            />
            
            {showAveragePrice && (
              <ReferenceLine 
                y={averagePrice} 
                stroke={COLORS.navy[500]} 
                strokeDasharray="3 3"
                label={{ 
                  value: `Avg: ₹${Math.round(averagePrice)}`,
                  position: 'right',
                  fill: COLORS.navy[700],
                  fontSize: 10
                }}
              />
            )}
            
            <Area
              type="monotone"
              dataKey="price"
              stroke="none"
              fill="url(#goldGradient)"
              animationDuration={1000}
            />
            
            <Line
              type="monotone"
              dataKey="price"
              stroke={COLORS.gold[500]}
              strokeWidth={3}
              dot={false}
              activeDot={{ 
                r: 5, 
                fill: COLORS.gold[500], 
                stroke: 'white',
                strokeWidth: 2 
              }}
              animationDuration={1500}
              animationEasing="ease-in-out"
            />
          </ComposedChart>
        </ResponsiveContainer>
        
        {hoveredPoint !== null && chartData[hoveredPoint] && (
          <motion.div 
            className="absolute top-2 left-2 bg-white rounded-lg shadow-md p-2 text-xs font-medium"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
          >
            <div className="text-gray-600">{formatDate(chartData[hoveredPoint].date)}</div>
            <div className="font-mono text-gold-600 text-sm">{formatPrice(chartData[hoveredPoint].price)}</div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default GoldPriceChart;
