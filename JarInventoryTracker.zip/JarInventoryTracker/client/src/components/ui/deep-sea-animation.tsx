import React from 'react';
import { motion } from 'framer-motion';

interface DeepSeaAnimationProps {
  className?: string;
}

const DeepSeaAnimation = ({ className = '' }: DeepSeaAnimationProps) => {
  return (
    <div className={`relative overflow-hidden ${className}`}>
      {/* Main background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-50 via-blue-100 to-indigo-100 dark:from-gray-900 dark:via-blue-950 dark:to-indigo-950"></div>
      
      {/* Animated wave layers */}
      <motion.div 
        className="absolute inset-0"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
      >
        {/* First wave layer */}
        <motion.div 
          className="absolute bottom-0 left-0 right-0 h-[30%] bg-gradient-to-t from-blue-200/60 to-transparent dark:from-blue-900/40 dark:to-transparent"
          animate={{
            y: [0, -5, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        
        {/* Second wave layer */}
        <motion.div 
          className="absolute bottom-0 left-0 right-0 h-[20%] bg-gradient-to-t from-blue-300/40 to-transparent dark:from-blue-800/30 dark:to-transparent"
          animate={{
            y: [0, -7, 0],
          }}
          transition={{
            duration: 7,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 0.5
          }}
        />
        
        {/* Third wave layer */}
        <motion.div 
          className="absolute bottom-0 left-0 right-0 h-[10%] bg-gradient-to-t from-blue-400/30 to-transparent dark:from-blue-700/20 dark:to-transparent"
          animate={{
            y: [0, -9, 0],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1
          }}
        />
      </motion.div>
      
      {/* Particle effects */}
      <div className="absolute inset-0">
        {Array.from({ length: 30 }).map((_, i) => {
          const size = Math.random() * 6 + 2;
          const duration = Math.random() * 15 + 10;
          const delay = Math.random() * 10;
          const initialX = Math.random() * 100;
          const initialY = Math.random() * 100;
          
          return (
            <motion.div
              key={i}
              className="absolute rounded-full bg-amber-200/30 dark:bg-amber-300/20"
              style={{
                width: size,
                height: size,
                left: `${initialX}%`,
                top: `${initialY}%`,
              }}
              animate={{
                y: [0, -100],
                opacity: [0, 0.7, 0],
              }}
              transition={{
                duration,
                repeat: Infinity,
                delay,
                ease: "linear"
              }}
            />
          );
        })}
      </div>
      
      {/* Light spots */}
      {Array.from({ length: 5 }).map((_, i) => {
        const size = Math.random() * 250 + 150;
        const posX = Math.random() * 80 + 10;
        const posY = Math.random() * 80 + 10;
        const opacity = Math.random() * 0.2 + 0.1;
        
        return (
          <motion.div
            key={`light-${i}`}
            className="absolute rounded-full bg-gradient-to-br from-amber-200 to-white dark:from-amber-300/30 dark:to-blue-300/10"
            style={{
              width: size,
              height: size,
              left: `${posX}%`,
              top: `${posY}%`,
              opacity,
              filter: 'blur(50px)',
            }}
            animate={{
              scale: [1, 1.1, 1],
              opacity: [opacity, opacity + 0.1, opacity],
            }}
            transition={{
              duration: 10 + i * 3,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        );
      })}
    </div>
  );
};

export default DeepSeaAnimation;