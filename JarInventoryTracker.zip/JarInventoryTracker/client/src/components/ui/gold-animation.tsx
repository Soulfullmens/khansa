import { motion } from "framer-motion";
import { useEffect, useState } from "react";

interface GoldAnimationProps {
  position?: "top-left" | "top-right" | "bottom-left" | "bottom-right" | "center";
  size?: "sm" | "md" | "lg";
  intensity?: "low" | "medium" | "high";
  className?: string;
}

const GoldAnimation = ({
  position = "top-right",
  size = "md",
  intensity = "medium",
  className = "",
}: GoldAnimationProps) => {
  const [particleCount, setParticleCount] = useState(0);
  
  // Define size classes
  const sizeClasses = {
    sm: "w-32 h-32",
    md: "w-64 h-64",
    lg: "w-96 h-96",
  };
  
  // Define position classes
  const positionClasses = {
    "top-left": "top-0 left-0 origin-top-left",
    "top-right": "top-0 right-0 origin-top-right",
    "bottom-left": "bottom-0 left-0 origin-bottom-left",
    "bottom-right": "bottom-0 right-0 origin-bottom-right",
    "center": "top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 origin-center",
  };
  
  // Define intensity values (reduced for better performance)
  const intensityValues = {
    low: { opacity: 0.1, particleCount: 5 },
    medium: { opacity: 0.15, particleCount: 10 },
    high: { opacity: 0.2, particleCount: 15 },
  };
  
  // Set particle count based on intensity
  useEffect(() => {
    setParticleCount(intensityValues[intensity].particleCount);
  }, [intensity]);
  
  // Generate particles
  const particles = Array.from({ length: particleCount }).map((_, i) => {
    // Random properties for each particle (optimized for better performance)
    const size = Math.floor(Math.random() * 4) + 2; // 2-6px (smaller particles)
    const delay = Math.random() * 1; // 0-1s delay (faster start)
    const duration = 2 + Math.random() * 3; // 2-5s duration (faster animation)
    const initialX = Math.random() * 80 - 40; // -40 to 40 (smaller movement range)
    const initialY = Math.random() * 80 - 40; // -40 to 40 (smaller movement range)
    const targetX = initialX + (Math.random() * 60 - 30); // move -30 to 30 from initial (smaller movement)
    const targetY = initialY + (Math.random() * 60 - 30); // move -30 to 30 from initial (smaller movement)
    
    return (
      <motion.div
        key={i}
        className={`absolute rounded-full bg-gradient-to-r from-amber-200 to-amber-400`}
        style={{ 
          width: size, 
          height: size,
          top: `calc(50% + ${initialY}px)`,
          left: `calc(50% + ${initialX}px)`,
          opacity: 0
        }}
        animate={{
          top: [`calc(50% + ${initialY}px)`, `calc(50% + ${targetY}px)`],
          left: [`calc(50% + ${initialX}px)`, `calc(50% + ${targetX}px)`],
          opacity: [0, intensityValues[intensity].opacity, 0],
          scale: [0.7, 1, 0.7]
        }}
        transition={{
          duration: duration,
          ease: "easeInOut",
          delay: delay,
          repeat: Infinity,
          repeatType: "loop",
          repeatDelay: Math.random()
        }}
      />
    );
  });
  
  // Main glow animation (optimized for performance)
  const mainGlow = (
    <motion.div
      className={`absolute bg-gradient-to-r from-amber-200 to-amber-400 rounded-full blur-2xl opacity-0`}
      style={{ 
        width: '70%', 
        height: '70%',
        top: '15%',
        left: '15%'
      }}
      animate={{
        opacity: [0.05, 0.1, 0.05],
        scale: [0.9, 1, 0.9]
      }}
      transition={{
        duration: 4, // Faster animation
        ease: "easeInOut",
        repeat: Infinity,
        repeatType: "reverse"
      }}
    />
  );
  
  return (
    <div className={`absolute overflow-hidden ${sizeClasses[size]} ${positionClasses[position]} ${className} pointer-events-none z-0`}>
      {mainGlow}
      {particles}
    </div>
  );
};

export default GoldAnimation;