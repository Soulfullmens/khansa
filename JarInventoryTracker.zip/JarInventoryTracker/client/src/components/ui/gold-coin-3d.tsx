import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

interface GoldCoin3DProps {
  size?: number;
  className?: string;
  autoRotate?: boolean;
}

function GoldCoin3D({
  size = 120,
  className = "",
  autoRotate = true
}: GoldCoin3DProps) {
  const [rotation, setRotation] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  
  // Auto rotation effect
  useEffect(() => {
    if (!autoRotate || isHovered) return;
    
    const interval = setInterval(() => {
      setRotation(prev => prev + 180);
    }, 3000);
    
    return () => clearInterval(interval);
  }, [autoRotate, isHovered]);
  
  return (
    <div 
      className={`relative ${className}`}
      style={{ width: size, height: size }}
    >
      <div
        className={`w-full h-full relative cursor-pointer transition-transform duration-300 ease-out ${isHovered ? 'scale-110' : ''}`}
        style={{
          perspective: '800px',
          boxShadow: isHovered 
            ? '0 15px 30px -5px rgba(245, 190, 61, 0.7)' 
            : '0 7px 15px -5px rgba(245, 190, 61, 0.4)'
        }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div 
          className="w-full h-full relative transition-transform duration-700 ease-out"
          style={{ 
            transformStyle: 'preserve-3d',
            transform: `rotateY(${rotation}deg)`
          }}
        >
          {/* Front face of the coin */}
          <div
            className="absolute inset-0 rounded-full bg-gradient-to-br from-yellow-300 via-amber-500 to-yellow-600 flex items-center justify-center backface-hidden"
          >
            {/* Coin front design */}
            <div className="absolute inset-2 rounded-full border-4 border-yellow-300/30"></div>
            <div className="absolute inset-4 rounded-full border border-yellow-700/30"></div>
            
            {/* Coin front text */}
            <div className="text-yellow-100 font-bold text-xl relative">
              {/* Embossed effect */}
              <div className="absolute inset-0 blur-[0.5px] text-yellow-700/30 translate-y-[1px] translate-x-[1px]">₹</div>
              <span>₹</span>
            </div>
            
            {/* Shimmer accent */}
            <motion.div 
              className="absolute top-1/4 right-1/4 w-1 h-1 rounded-full bg-yellow-100"
              animate={{ 
                opacity: [0.3, 1, 0.3], 
                scale: [1, 1.5, 1] 
              }}
              transition={{ 
                duration: 2, 
                repeat: Infinity
              }}
            />
          </div>
          
          {/* Back face of the coin */}
          <div
            className="absolute inset-0 rounded-full bg-gradient-to-br from-yellow-400 via-amber-600 to-yellow-700 flex items-center justify-center backface-hidden"
            style={{ transform: 'rotateY(180deg)' }}
          >
            {/* Coin back design */}
            <div className="absolute inset-2 rounded-full border-4 border-yellow-300/30"></div>
            <div className="absolute inset-4 rounded-full border border-yellow-700/30"></div>
            
            {/* Khansa logo */}
            <div className="text-yellow-100 font-serif font-bold text-sm relative">
              <div className="absolute inset-0 blur-[0.5px] text-yellow-700/30 translate-y-[1px] translate-x-[1px]">KHANSA</div>
              <span>KHANSA</span>
            </div>
          </div>

          {/* Coin edge */}
          <div className="absolute inset-0 rounded-full border-8 border-amber-600/70 transform-gpu"></div>
        </div>
        
        {/* Shimmering effect */}
        <motion.div 
          className="absolute inset-0 rounded-full overflow-hidden"
          style={{ zIndex: 10 }}
        >
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-200/30 to-transparent"
            animate={{ x: ['-100%', '100%'] }}
            transition={{ 
              duration: 1.5, 
              repeat: Infinity,
              ease: "easeInOut" 
            }}
          />
        </motion.div>
      </div>
    </div>
  );
}

// Add backface visibility styles to global CSS
const style = document.createElement('style');
style.textContent = `
  .backface-hidden {
    backface-visibility: hidden;
    -webkit-backface-visibility: hidden;
  }
`;
document.head.appendChild(style);

export default GoldCoin3D;