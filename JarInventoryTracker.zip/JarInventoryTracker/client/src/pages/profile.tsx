import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import Sidebar from "@/components/layout/sidebar";
import MobileHeader from "@/components/layout/mobile-header";
import MobileNavigation from "@/components/layout/mobile-navigation";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

const Profile = () => {
  const { toast } = useToast();
  const { user, logoutMutation } = useAuth();
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  const handleLogout = async () => {
    setIsLoggingOut(true);
    try {
      await logoutMutation.mutateAsync();
      toast({
        title: "Logged out successfully",
        description: "You have been logged out of your account",
      });
    } catch (error) {
      toast({
        title: "Logout failed",
        description: "An error occurred during logout. Please try again.",
        variant: "destructive",
      });
      setIsLoggingOut(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <MobileHeader />
      
      <main className="flex-1 pb-20 md:pb-0 md:flex">
        <Sidebar />
        
        <div className="w-full md:flex-1 px-4 md:px-8 py-4 md:py-8">
          <div className="md:max-w-4xl mx-auto">
            <h1 className="font-heading font-bold text-2xl mb-6 text-[#1A2E44]">Your Profile</h1>
            
            {/* Profile Card */}
            <Card className="bg-white rounded-xl shadow-md p-6 mb-6">
              <CardContent className="p-0">
                <div className="flex flex-col md:flex-row items-center mb-6">
                  <div className="relative mb-4 md:mb-0 md:mr-6">
                    <img 
                      src={user?.profileImage || "https://images.unsplash.com/photo-1618044733300-9472054094ee?auto=format&fit=crop&q=80&w=100&h=100"} 
                      alt="Profile" 
                      className="h-24 w-24 rounded-full object-cover border-4 border-[#F7B801]"
                    />
                    <button className="absolute bottom-0 right-0 bg-[#1A2E44] text-white p-2 rounded-full">
                      <i className="ri-camera-line text-sm"></i>
                    </button>
                  </div>
                  
                  <div className="text-center md:text-left flex-1">
                    <h2 className="font-heading font-semibold text-xl">{user?.name || "User"}</h2>
                    <p className="text-gray-500">@{user?.username || "username"}</p>
                    <div className="mt-2 inline-block bg-[#FFF8E6] px-3 py-1 rounded-full text-[#F7B801] text-sm font-medium">
                      {user?.userLevel || "Gold Saver"}
                    </div>
                  </div>
                  
                  <Button 
                    variant="outline" 
                    className="mt-4 md:mt-0"
                    onClick={() => {
                      toast({
                        title: "Feature coming soon",
                        description: "Profile editing will be available soon!",
                      });
                    }}
                  >
                    Edit Profile
                  </Button>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg mb-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                    <div>
                      <p className="text-gray-500 text-sm">Total Saved</p>
                      <p className="font-mono text-lg font-medium">₹18,547.22</p>
                    </div>
                    <div>
                      <p className="text-gray-500 text-sm">Gold Quantity</p>
                      <p className="font-mono text-lg font-medium">3.45 gm</p>
                    </div>
                    <div>
                      <p className="text-gray-500 text-sm">Active Goals</p>
                      <p className="font-mono text-lg font-medium">2</p>
                    </div>
                    <div>
                      <p className="text-gray-500 text-sm">Saving Streak</p>
                      <p className="font-mono text-lg font-medium">7 days</p>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-center md:justify-start">
                  <Button className="bg-[#F7B801] hover:bg-[#CC9600] text-white">
                    <i className="ri-award-line mr-2"></i> View Achievements
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            {/* Account Settings */}
            <Card className="bg-white rounded-xl shadow-md mb-6">
              <CardHeader>
                <CardTitle className="text-lg font-heading">Account Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Notifications</h3>
                      <p className="text-sm text-gray-500">Receive app notifications</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Email Updates</h3>
                      <p className="text-sm text-gray-500">Receive emails about your account</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Auto-save</h3>
                      <p className="text-sm text-gray-500">Automatically save ₹50 every day</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">Transaction Roundups</h3>
                      <p className="text-sm text-gray-500">Round up transactions to the nearest ₹10</p>
                    </div>
                    <Switch />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Security & Privacy */}
            <Card className="bg-white rounded-xl shadow-md mb-6">
              <CardHeader>
                <CardTitle className="text-lg font-heading">Security & Privacy</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Button variant="outline" className="w-full justify-start">
                    <i className="ri-lock-password-line mr-2"></i> Change Password
                  </Button>
                  
                  <Button variant="outline" className="w-full justify-start">
                    <i className="ri-bank-card-line mr-2"></i> Manage Payment Methods
                  </Button>
                  
                  <Button variant="outline" className="w-full justify-start">
                    <i className="ri-shield-check-line mr-2"></i> Privacy Settings
                  </Button>
                  
                  <Button variant="outline" className="w-full justify-start text-red-500 hover:text-red-600 hover:bg-red-50">
                    <i className="ri-delete-bin-line mr-2"></i> Delete Account
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            {/* Logout Button */}
            <div className="flex justify-center mb-8">
              <Button 
                variant="outline" 
                className="text-red-500 hover:text-red-600 hover:bg-red-50"
                onClick={handleLogout}
                disabled={isLoggingOut}
              >
                <i className="ri-logout-box-line mr-2"></i>
                {isLoggingOut ? "Logging out..." : "Logout"}
              </Button>
            </div>
          </div>
        </div>
      </main>
      
      <MobileNavigation />
    </div>
  );
};

export default Profile;
