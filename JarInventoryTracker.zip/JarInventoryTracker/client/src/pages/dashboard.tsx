import { useEffect, useState } from "react";
import Sidebar from "@/components/layout/sidebar";
import MobileHeader from "@/components/layout/mobile-header";
import MobileNavigation from "@/components/layout/mobile-navigation";
import PortfolioCard from "@/components/dashboard/portfolio-card";
import GoalsSection from "@/components/dashboard/goals-section";
import InsightsSection from "@/components/dashboard/insights-section";
import TransactionsSection from "@/components/dashboard/transactions-section";
import GoldPriceSection from "@/components/dashboard/gold-price-section";
import SmartSavingsSection from "@/components/dashboard/smart-savings-section";
import EducationalBanner from "@/components/dashboard/educational-banner";
import OnboardingFlow from "@/components/onboarding/onboarding-flow";
import LuxuryHeader from "@/components/dashboard/luxury-header";
import GoldAnimation from "@/components/ui/gold-animation";
import { StreakCard } from "@/components/dashboard/streak-card";
import { AchievementsCard } from "@/components/dashboard/achievements-card";
import { PointsCard } from "@/components/dashboard/points-card";
import { useAuth } from "@/hooks/use-auth";
import { motion } from "framer-motion";
import { Award } from "lucide-react";
import { LUXURY_PALETTE, GRADIENTS } from "@/lib/luxury-palette";

const Dashboard = () => {
  const [showOnboarding, setShowOnboarding] = useState(false);
  const { user } = useAuth();

  // Check if this is a first-time user and show onboarding
  useEffect(() => {
    // For demo purposes, we'll show onboarding if a URL parameter is present
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get("onboarding") === "true") {
      setShowOnboarding(true);
    }
  }, []);

  const handleOnboardingComplete = () => {
    setShowOnboarding(false);
  };

  // Animation variants for staggered children
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-neutral-50 to-gray-100 overflow-hidden">
      {/* Gold particle animations with reduced intensity */}
      <GoldAnimation position="top-right" size="lg" intensity="low" />
      <GoldAnimation position="bottom-left" size="md" intensity="low" />
      
      {/* Mobile header */}
      <MobileHeader />
      
      <main className="flex-1 pb-20 md:pb-0 md:flex relative z-10">
        {/* Sidebar */}
        <Sidebar />
        
        <div className="w-full md:flex-1 px-4 md:px-8 py-4 md:py-8">
          <motion.div 
            className="md:max-w-4xl mx-auto"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {/* Premium luxury header */}
            <motion.div variants={itemVariants}>
              <LuxuryHeader />
            </motion.div>
            
            {/* Portfolio card with enhanced animation */}
            <motion.div variants={itemVariants}>
              <PortfolioCard />
            </motion.div>
            
            {/* Goals section */}
            <motion.div variants={itemVariants}>
              <GoalsSection />
            </motion.div>
            
            {/* Smart Savings section - AI powered */}
            <motion.div variants={itemVariants}>
              <SmartSavingsSection />
            </motion.div>
            
            {/* Lower sections */}
            <div className="grid md:grid-cols-2 gap-6">
              <motion.div variants={itemVariants}>
                <GoldPriceSection />
              </motion.div>
              
              <div className="space-y-6">
                <motion.div variants={itemVariants}>
                  <InsightsSection />
                </motion.div>
                <motion.div variants={itemVariants}>
                  <TransactionsSection />
                </motion.div>
              </div>
            </div>
            
            {/* Gamification Section - Streaks, Achievements, Points */}
            <motion.div variants={itemVariants} className="mt-6">
              <h2 className="text-xl font-semibold mb-4 text-gray-800 flex items-center">
                <Award className="mr-2 h-5 w-5 text-amber-500" />
                Gamification & Rewards
              </h2>
              <div className="grid md:grid-cols-3 gap-6">
                <StreakCard />
                <AchievementsCard />
                <PointsCard />
              </div>
            </motion.div>
            
            {/* Educational banner */}
            <motion.div 
              variants={itemVariants}
              className="mt-6"
            >
              <EducationalBanner />
            </motion.div>
            
            {/* Footer with luxury colors */}
            <motion.div 
              variants={itemVariants}
              className="mt-8 text-center"
            >
              <div className="inline-block mx-auto">
                <div 
                  style={{ background: GRADIENTS.darkSlate }} 
                  className="px-4 py-2 rounded-full shadow-lg flex items-center space-x-2"
                >
                  <div 
                    style={{ background: GRADIENTS.goldPrimary }} 
                    className="w-6 h-6 rounded-full flex items-center justify-center"
                  >
                    <span className="text-white text-xs">₹</span>
                  </div>
                  <span className="text-xs text-white font-medium">Khansa: Premium Investment Platform</span>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </main>
      
      <MobileNavigation />
      
      {showOnboarding && (
        <OnboardingFlow 
          onComplete={handleOnboardingComplete} 
          onSkip={handleOnboardingComplete} 
        />
      )}
    </div>
  );
};

export default Dashboard;
