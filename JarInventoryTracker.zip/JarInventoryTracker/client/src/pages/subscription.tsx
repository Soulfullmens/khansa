import { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Check, CreditCard, Coins, Wallet, AlertCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import DeepSeaAnimation from '@/components/ui/deep-sea-animation';
import { useToast } from '@/hooks/use-toast';

// UPI App icons
const UPI_APPS = [
  { id: 'gpay', name: 'Google Pay', icon: 'ri-google-fill' },
  { id: 'phonepe', name: 'PhonePe', icon: 'ri-smartphone-line' },
  { id: 'paytm', name: 'Paytm', icon: 'ri-wallet-3-line' },
  { id: 'upi', name: 'Other UPI', icon: 'ri-bank-card-line' },
];

// Crypto payment options
const CRYPTO_OPTIONS = [
  { id: 'btc', name: 'Bitcoin', symbol: 'BTC', icon: 'ri-bitcoin-fill' },
  { id: 'eth', name: 'Ethereum', symbol: 'ETH', icon: 'ri-ethereum-fill' },
  { id: 'usdt', name: 'Tether', symbol: 'USDT', icon: 'ri-coin-line' },
  { id: 'xrp', name: 'XRP', symbol: 'XRP', icon: 'ri-ripple-fill' },
];

// Subscription plans
const SUBSCRIPTION_PLANS = [
  {
    id: 'starter',
    name: 'Starter',
    price: '499',
    billing: 'monthly',
    description: 'Perfect for beginners starting their investment journey',
    features: [
      'Basic gold investment',
      'Standard goal tracking',
      'Monthly insights report',
      'Email support',
    ],
    highlighted: false,
    cta: 'Get Started',
  },
  {
    id: 'premium',
    name: 'Premium',
    price: '999',
    billing: 'monthly',
    description: 'Enhanced features for serious investors',
    features: [
      'Advanced gold investment strategies',
      'Priority goal tracking',
      'Weekly insights report',
      'Priority email & chat support',
      'Multi-asset investments',
      'Lower transaction fees',
    ],
    highlighted: true,
    cta: 'Upgrade to Premium',
    badge: 'Most Popular',
  },
  {
    id: 'vip',
    name: 'VIP',
    price: '4999',
    billing: 'quarterly',
    description: 'Exclusive benefits for dedicated investors',
    features: [
      'Advanced gold investment strategies',
      'VIP goal tracking & recommendations',
      'Daily insights report',
      '24/7 priority support',
      'Multi-asset investment portfolio',
      'Zero transaction fees',
      'Personal investment advisor',
      'Exclusive investment opportunities',
    ],
    highlighted: false,
    cta: 'Go VIP',
  },
];

type PaymentMethod = 'card' | 'upi' | 'crypto';
type SubscriptionPlan = typeof SUBSCRIPTION_PLANS[number];

const Subscription = () => {
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('card');
  const [upiId, setUpiId] = useState('');
  const [selectedUpiApp, setSelectedUpiApp] = useState('');
  const [selectedCrypto, setSelectedCrypto] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPaymentForm, setShowPaymentForm] = useState(false);

  // Handle plan selection
  const handleSelectPlan = (plan: SubscriptionPlan) => {
    setSelectedPlan(plan);
    setShowPaymentForm(true);
    
    // Scroll to payment form
    setTimeout(() => {
      document.getElementById('payment-form')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  // Handle payment submission
  const handleSubmitPayment = () => {
    if (!selectedPlan) return;
    
    setIsProcessing(true);
    
    // For UPI and Crypto, we'd implement different payment flows
    // For now, direct all payments to Stripe checkout
    if (paymentMethod === 'card') {
      // Redirect to Stripe checkout
      window.location.href = `/checkout?amount=${selectedPlan.price}`;
    } else {
      // For UPI and crypto, show a toast that this would redirect to respective payment gateways
      toast({
        title: "Payment Method Coming Soon",
        description: `${paymentMethod.toUpperCase()} payments will be available soon. Please use card payment for now.`,
        variant: "default",
      });
      setIsProcessing(false);
    }
  };

  const fadeInUpVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { 
        duration: 0.5,
        ease: "easeOut" 
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Hero section with deep sea animation */}
      <div className="relative w-full h-[500px] overflow-hidden">
        <DeepSeaAnimation className="absolute inset-0 w-full h-full" />
        
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white z-10 p-6">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Elevate Your Investing Experience
            </h1>
            <p className="text-lg md:text-xl text-blue-100 mb-8">
              Choose the subscription plan that best fits your investment goals and unlock premium features
            </p>
            <Button 
              size="lg" 
              className="bg-blue-500 hover:bg-blue-600 text-white rounded-full px-8 shadow-lg hover:shadow-xl transition-all"
              onClick={() => document.getElementById('subscription-plans')?.scrollIntoView({ behavior: 'smooth' })}
            >
              View Plans
            </Button>
          </motion.div>
        </div>
      </div>

      {/* Subscription plans */}
      <div id="subscription-plans" className="container mx-auto py-16 px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Choose Your Plan
          </h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Select a subscription plan that suits your investment strategy. 
            Upgrade or downgrade anytime as your needs evolve.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {SUBSCRIPTION_PLANS.map((plan, i) => (
            <motion.div
              key={plan.id}
              variants={fadeInUpVariants}
              initial="hidden"
              animate="visible"
              transition={{ delay: i * 0.1 }}
              className="h-full"
            >
              <Card className={`h-full flex flex-col ${
                plan.highlighted 
                  ? 'border-blue-500 dark:border-blue-400 shadow-xl relative overflow-hidden' 
                  : 'shadow-md'
              }`}>
                {plan.badge && (
                  <div className="absolute top-0 right-0">
                    <Badge className="bg-blue-500 m-2">{plan.badge}</Badge>
                  </div>
                )}
                
                <CardHeader>
                  <CardTitle>{plan.name}</CardTitle>
                  <CardDescription>{plan.description}</CardDescription>
                  <div className="mt-4">
                    <span className="text-3xl font-bold">₹{plan.price}</span>
                    <span className="text-gray-500 dark:text-gray-400 ml-2">/{plan.billing}</span>
                  </div>
                </CardHeader>
                
                <CardContent className="flex-grow">
                  <ul className="space-y-2">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start">
                        <Check className="h-5 w-5 text-green-500 mr-2 shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                
                <CardFooter>
                  <Button 
                    className={`w-full ${
                      plan.highlighted 
                        ? 'bg-blue-500 hover:bg-blue-600 text-white' 
                        : ''
                    }`}
                    onClick={() => handleSelectPlan(plan)}
                  >
                    {plan.cta}
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Payment form */}
      {showPaymentForm && (
        <motion.div 
          id="payment-form"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="container mx-auto py-16 px-4 max-w-3xl"
        >
          <Card>
            <CardHeader>
              <CardTitle>Complete Your Subscription</CardTitle>
              <CardDescription>
                You've selected the {selectedPlan?.name} plan at ₹{selectedPlan?.price}/{selectedPlan?.billing}
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <Tabs defaultValue="card" onValueChange={(v) => setPaymentMethod(v as PaymentMethod)}>
                <TabsList className="grid grid-cols-3 mb-8">
                  <TabsTrigger value="card" className="flex items-center gap-2">
                    <CreditCard className="h-4 w-4" />
                    <span>Card</span>
                  </TabsTrigger>
                  <TabsTrigger value="upi" className="flex items-center gap-2">
                    <Wallet className="h-4 w-4" />
                    <span>UPI</span>
                  </TabsTrigger>
                  <TabsTrigger value="crypto" className="flex items-center gap-2">
                    <Coins className="h-4 w-4" />
                    <span>Crypto</span>
                  </TabsTrigger>
                </TabsList>
                
                {/* Credit card form */}
                <TabsContent value="card">
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="col-span-2">
                        <label className="block text-sm font-medium mb-1">Card Number</label>
                        <input 
                          type="text" 
                          placeholder="1234 5678 9012 3456" 
                          className="w-full p-2 border rounded-md" 
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">Expiry Date</label>
                        <input 
                          type="text" 
                          placeholder="MM/YY" 
                          className="w-full p-2 border rounded-md" 
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">CVV</label>
                        <input 
                          type="text" 
                          placeholder="123" 
                          className="w-full p-2 border rounded-md" 
                        />
                      </div>
                      <div className="col-span-2">
                        <label className="block text-sm font-medium mb-1">Name on Card</label>
                        <input 
                          type="text" 
                          placeholder="John Doe" 
                          className="w-full p-2 border rounded-md" 
                        />
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                {/* UPI form */}
                <TabsContent value="upi">
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Select UPI App</label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                        {UPI_APPS.map((app) => (
                          <div 
                            key={app.id}
                            onClick={() => setSelectedUpiApp(app.id)}
                            className={`cursor-pointer border rounded-lg p-4 text-center transition-all ${
                              selectedUpiApp === app.id 
                                ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' 
                                : 'hover:border-gray-400'
                            }`}
                          >
                            <div className="flex flex-col items-center gap-2">
                              <div className={`h-10 w-10 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center ${
                                selectedUpiApp === app.id ? 'text-blue-500' : ''
                              }`}>
                                <i className={`${app.icon} text-lg`}></i>
                              </div>
                              <span className="text-sm">{app.name}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-1">Enter UPI ID</label>
                      <div className="flex">
                        <input 
                          type="text" 
                          value={upiId}
                          onChange={(e) => setUpiId(e.target.value)}
                          placeholder="username@upi" 
                          className="flex-grow p-2 border rounded-l-md" 
                        />
                        <Button 
                          disabled={!upiId.includes('@')}
                          className="rounded-l-none"
                        >
                          Verify
                        </Button>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        Enter your UPI ID in the format username@bankname
                      </p>
                    </div>
                  </div>
                </TabsContent>
                
                {/* Crypto payment */}
                <TabsContent value="crypto">
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Select Cryptocurrency</label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                        {CRYPTO_OPTIONS.map((crypto) => (
                          <div 
                            key={crypto.id}
                            onClick={() => setSelectedCrypto(crypto.id)}
                            className={`cursor-pointer border rounded-lg p-4 text-center transition-all ${
                              selectedCrypto === crypto.id 
                                ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' 
                                : 'hover:border-gray-400'
                            }`}
                          >
                            <div className="flex flex-col items-center gap-2">
                              <div className={`h-10 w-10 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center ${
                                selectedCrypto === crypto.id ? 'text-blue-500' : ''
                              }`}>
                                <i className={`${crypto.icon} text-lg`}></i>
                              </div>
                              <div>
                                <span className="text-sm block">{crypto.name}</span>
                                <span className="text-xs text-gray-500">{crypto.symbol}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    {selectedCrypto && (
                      <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">Wallet Address</span>
                          <Button variant="ghost" size="sm" onClick={() => {
                            toast({
                              title: "Address Copied",
                              description: "Wallet address copied to clipboard",
                            });
                          }}>
                            Copy
                          </Button>
                        </div>
                        <div className="bg-white dark:bg-gray-900 p-3 rounded-md text-sm font-mono break-all">
                          {selectedCrypto === 'btc' && '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa'}
                          {selectedCrypto === 'eth' && '0x742d35Cc6634C0532925a3b844Bc454e4438f44e'}
                          {selectedCrypto === 'usdt' && 'TKHuVq1oKVruCGLvqVexFs6dawKv6fQgFs'}
                          {selectedCrypto === 'xrp' && 'rNGcGE3CR3Ta9JTjxUtEfjFcuRQrDE3c3Y'}
                        </div>
                        <div className="flex items-center mt-4 text-sm text-amber-600 dark:text-amber-400">
                          <AlertCircle className="h-4 w-4 mr-2" />
                          <span>
                            Please send exactly {selectedCrypto === 'btc' ? '0.00023' : 
                              selectedCrypto === 'eth' ? '0.0056' : 
                              selectedCrypto === 'usdt' ? '12.50' : '25.00'
                            } {
                              CRYPTO_OPTIONS.find(c => c.id === selectedCrypto)?.symbol
                            } to complete your subscription
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
            
            <CardFooter className="flex flex-col space-y-4">
              <Button 
                className="w-full" 
                disabled={
                  (paymentMethod === 'upi' && (!selectedUpiApp || !upiId.includes('@'))) ||
                  (paymentMethod === 'crypto' && !selectedCrypto) ||
                  isProcessing
                }
                onClick={handleSubmitPayment}
              >
                {isProcessing ? 'Processing...' : `Pay ₹${selectedPlan?.price}`}
              </Button>
              
              <div className="text-xs text-center text-gray-500">
                By subscribing, you agree to our Terms of Service and Privacy Policy.
                Subscriptions will automatically renew until canceled.
              </div>
            </CardFooter>
          </Card>
        </motion.div>
      )}
      
      {/* Features section */}
      <div className="bg-gray-100 dark:bg-gray-800 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Premium Benefits</h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Unlock a world of exclusive features and personalized investment guidance with our premium subscription plans.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {[
              {
                title: "AI-Powered Insights",
                description: "Get personalized investment recommendations and insights tailored to your unique financial goals",
                icon: "ri-brain-line"
              },
              {
                title: "Multi-Asset Portfolio",
                description: "Diversify your investments across gold, stocks, fixed deposits, mutual funds, and more",
                icon: "ri-pie-chart-line"
              },
              {
                title: "Zero Transaction Fees",
                description: "Enjoy fee-free transactions and transfers with our premium subscription plans",
                icon: "ri-currency-line"
              },
              {
                title: "Priority Support",
                description: "Get direct access to our team of financial experts whenever you need assistance",
                icon: "ri-customer-service-2-line"
              },
              {
                title: "Advanced Analytics",
                description: "Track your investment performance with detailed analytics and visual representations",
                icon: "ri-line-chart-line"
              },
              {
                title: "Exclusive Opportunities",
                description: "Access limited-time investment opportunities only available to premium subscribers",
                icon: "ri-vip-crown-line"
              }
            ].map((feature, i) => (
              <motion.div
                key={i}
                variants={fadeInUpVariants}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <div className="bg-white dark:bg-gray-900 p-6 rounded-xl shadow-md h-full">
                  <div className="h-12 w-12 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400 mb-4">
                    <i className={`${feature.icon} text-2xl`}></i>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400">{feature.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Subscription;