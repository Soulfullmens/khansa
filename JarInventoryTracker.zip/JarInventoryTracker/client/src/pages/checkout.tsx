import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, TrendingUp, CreditCard, Smartphone } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import DeepSeaAnimation from '@/components/ui/deep-sea-animation';
import GoldCoin3D from '@/components/ui/gold-coin-3d';
import { LUXURY_PALETTE } from '@/lib/luxury-palette';
import { SiGooglepay, SiPhonepe } from 'react-icons/si';

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const CheckoutForm = ({ amount, goldGrams, pricePerGram, onSuccess }: { 
  amount: number, 
  goldGrams: number, 
  pricePerGram: number, 
  onSuccess: () => void 
}) => {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/payment-success?goldGrams=${goldGrams}&pricePerGram=${pricePerGram}`,
      },
    });

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
      setIsProcessing(false);
    } else {
      toast({
        title: "Payment Successful",
        description: "Thank you for your payment!",
      });
      onSuccess();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <Button 
        type="submit" 
        className="w-full" 
        disabled={!stripe || isProcessing}
      >
        {isProcessing ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Processing...
          </>
        ) : (
          `Pay ₹${amount.toFixed(2)}`
        )}
      </Button>
    </form>
  );
};

export default function Checkout() {
  const [clientSecret, setClientSecret] = useState("");
  const [amount, setAmount] = useState(0);
  const [goldGrams, setGoldGrams] = useState(0);
  const [pricePerGram, setPricePerGram] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [purchaseType, setPurchaseType] = useState<'gold' | 'other'>('other');
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!user) {
      setLocation('/auth');
      return;
    }

    // Get parameters from URL
    const params = new URLSearchParams(window.location.search);
    const amountParam = params.get('amount');
    const goldGramsParam = params.get('goldGrams');
    const pricePerGramParam = params.get('pricePerGram');
    
    if (!amountParam) {
      toast({
        title: "Invalid Request",
        description: "No amount specified for payment",
        variant: "destructive",
      });
      setLocation('/');
      return;
    }

    const amountValue = parseFloat(amountParam);
    setAmount(amountValue);

    // Determine if this is a gold purchase
    let isGoldPurchase = false;
    let goldGramsValue = 0;
    let pricePerGramValue = 0;
    
    if (goldGramsParam && pricePerGramParam) {
      isGoldPurchase = true;
      goldGramsValue = parseFloat(goldGramsParam);
      pricePerGramValue = parseFloat(pricePerGramParam);
      
      setPurchaseType('gold');
      setGoldGrams(goldGramsValue);
      setPricePerGram(pricePerGramValue);
    }

    // Create PaymentIntent with metadata for gold purchase if applicable
    const payload: any = { amount: amountValue };
    
    if (isGoldPurchase) {
      payload.purchaseType = 'gold';
      payload.goldGrams = goldGramsValue;
      payload.pricePerGram = pricePerGramValue;
    }

    apiRequest("POST", "/api/create-payment-intent", payload)
      .then((res) => res.json())
      .then((data) => {
        setClientSecret(data.clientSecret);
        setIsLoading(false);
      })
      .catch((error) => {
        console.error("Error creating payment intent:", error);
        toast({
          title: "Payment Setup Failed",
          description: "Unable to initialize payment. Please try again.",
          variant: "destructive",
        });
        setIsLoading(false);
      });
  }, [user, setLocation, toast]);

  const handleSuccess = () => {
    // Navigate to success page
    setTimeout(() => {
      if (purchaseType === 'gold') {
        setLocation(`/payment-success?goldGrams=${goldGrams}&pricePerGram=${pricePerGram}`);
      } else {
        setLocation('/payment-success');
      }
    }, 1000);
  };

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
          <p>Setting up your payment...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Background animation */}
      <div className="fixed inset-0 -z-10">
        <DeepSeaAnimation className="w-full h-full" />
      </div>
      
      <div className="container mx-auto py-16 px-4 relative z-10">
        <div className="max-w-md mx-auto">
          <Card className="backdrop-blur-sm bg-white/90 dark:bg-gray-900/90 shadow-xl">
            <CardHeader>
              <CardTitle>{purchaseType === 'gold' ? 'Buy Digital Gold' : 'Complete Your Payment'}</CardTitle>
              <CardDescription>
                Secure payment powered by Stripe
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <div className="mb-6">
                {purchaseType === 'gold' && (
                  <div 
                    style={{ backgroundColor: LUXURY_PALETTE.gold[100], borderColor: LUXURY_PALETTE.gold[200] }}
                    className="border rounded-lg p-4 mb-6"
                  >
                    <div className="flex items-center justify-center mb-4">
                      <GoldCoin3D size={60} autoRotate />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600 dark:text-gray-400">Amount:</span>
                        <span className="font-medium">₹{amount.toFixed(2)}</span>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600 dark:text-gray-400">Current Rate:</span>
                        <span className="font-medium flex items-center">
                          ₹{pricePerGram.toLocaleString('en-IN', { maximumFractionDigits: 2 })}/g
                          <TrendingUp className="h-3 w-3 ml-1 text-green-500" />
                        </span>
                      </div>
                      
                      <div className="border-t border-gold-200 my-2"></div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">Gold You'll Get:</span>
                        <span 
                          style={{ color: LUXURY_PALETTE.gold[700] }}
                          className="font-bold"
                        >
                          {goldGrams.toFixed(6)} grams
                        </span>
                      </div>
                    </div>
                  </div>
                )}
                
                {purchaseType !== 'gold' && (
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-500 dark:text-gray-400">Amount</span>
                    <span className="font-semibold text-lg">₹{amount.toFixed(2)}</span>
                  </div>
                )}
                
                <div className="h-px bg-gray-200 dark:bg-gray-700 my-4" />
                
                <Tabs defaultValue="upi" className="w-full mb-6">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="upi" className="flex items-center gap-2">
                      <Smartphone className="h-4 w-4" />
                      UPI Apps
                    </TabsTrigger>
                    <TabsTrigger value="card" className="flex items-center gap-2">
                      <CreditCard className="h-4 w-4" />
                      Card Payment
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="upi" className="mt-4">
                    <div className="space-y-4">
                      <div className="text-sm font-medium text-center mb-2">
                        Select a UPI payment method
                      </div>
                      
                      <div className="grid grid-cols-2 gap-3">
                        <Button 
                          variant="outline"
                          className="flex flex-col items-center justify-center h-24 hover:border-primary hover:bg-primary/5"
                          onClick={() => {
                            toast({
                              title: "Google Pay Selected",
                              description: "Redirecting to Google Pay...",
                            });
                            
                            // For demo just use the standard flow
                            setTimeout(() => handleSuccess(), 1000);
                          }}
                        >
                          <SiGooglepay className="h-10 w-10 mb-2 text-blue-600" />
                          <span className="text-sm">Google Pay</span>
                        </Button>
                        
                        <Button 
                          variant="outline"
                          className="flex flex-col items-center justify-center h-24 hover:border-primary hover:bg-primary/5"
                          onClick={() => {
                            toast({
                              title: "PhonePe Selected",
                              description: "Redirecting to PhonePe...",
                            });
                            
                            // For demo just use the standard flow
                            setTimeout(() => handleSuccess(), 1000);
                          }}
                        >
                          <SiPhonepe className="h-10 w-10 mb-2 text-indigo-600" />
                          <span className="text-sm">PhonePe</span>
                        </Button>
                      </div>
                      
                      <div className="text-xs text-center text-gray-500 mt-4">
                        You'll be redirected to the selected UPI app to complete payment
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="card" className="mt-4">
                    {clientSecret ? (
                      <Elements stripe={stripePromise} options={{ clientSecret }}>
                        <CheckoutForm 
                          amount={amount} 
                          goldGrams={goldGrams} 
                          pricePerGram={pricePerGram} 
                          onSuccess={handleSuccess} 
                        />
                      </Elements>
                    ) : (
                      <div className="flex justify-center p-4">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </div>
            </CardContent>
            
            <CardFooter className="flex justify-center">
              <p className="text-xs text-gray-500 dark:text-gray-400 text-center">
                Your payment information is encrypted and secure.
                <br />We do not store your card details.
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}