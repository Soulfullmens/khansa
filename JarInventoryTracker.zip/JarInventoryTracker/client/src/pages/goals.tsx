import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import MobileHeader from "@/components/layout/mobile-header";
import MobileNavigation from "@/components/layout/mobile-navigation";
import GoalsSection from "@/components/dashboard/goals-section";
import { useAuth } from "@/hooks/use-auth";

const Goals = () => {
  const { user } = useAuth();

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <MobileHeader />
      
      <main className="flex-1 pb-20 md:pb-0 md:flex">
        <Sidebar />
        
        <div className="w-full md:flex-1 px-4 md:px-8 py-4 md:py-8">
          <div className="md:max-w-4xl mx-auto">
            <h1 className="font-heading font-bold text-2xl mb-6 text-[#1A2E44]">Your Savings Goals</h1>
            <GoalsSection />
          </div>
        </div>
      </main>
      
      <MobileNavigation />
    </div>
  );
};

export default Goals;
