import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Link, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { Icon } from "@/lib/icons";

const registerSchema = z.object({
  name: z.string().min(1, "Full name is required"),
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(1, "Please confirm your password"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type RegisterFormData = z.infer<typeof registerSchema>;

const Register = () => {
  const { toast } = useToast();
  const { user, isLoading, registerMutation } = useAuth();
  const [isRegistering, setIsRegistering] = useState(false);
  const [registrationError, setRegistrationError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [, setLocation] = useLocation();
  
  // Redirect to dashboard if already logged in
  useEffect(() => {
    if (!isLoading && user) {
      setLocation("/");
    }
  }, [user, isLoading, setLocation]);

  const { register, handleSubmit, formState: { errors } } = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
  });

  const onSubmit = async (data: RegisterFormData) => {
    setIsRegistering(true);
    setRegistrationError("");
    
    try {
      // Only take the needed fields
      const { confirmPassword, ...userData } = data;
      
      // Make sure we pass what the backend expects - these match insertUserSchema fields
      const registerData = {
        name: userData.name,
        username: userData.username,
        email: userData.email,
        password: userData.password,
        profileImage: "https://images.unsplash.com/photo-1618044733300-9472054094ee?auto=format&fit=crop&q=80&w=100&h=100"
      };
      
      await registerMutation.mutateAsync(registerData);
      
      // Redirect happens automatically through the AuthProvider after successful registration
    } catch (error: any) {
      console.error("Registration error:", error);
      
      let errorMessage = "An error occurred during registration. Please try again.";
      if (error.response && error.response.data && error.response.data.message) {
        errorMessage = error.response.data.message;
        if (errorMessage === "Username already exists") {
          setRegistrationError("Username already exists. Please choose a different username.");
        }
      }
      
      toast({
        title: "Registration failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsRegistering(false);
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { 
        duration: 0.2,
        ease: "easeOut",
        staggerChildren: 0.03
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.2 }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-[#1A2E44]/5 to-[#FFF8E6]/40 px-4 py-8">
      <div className="w-full max-w-md z-10 relative">
        {/* Gold particles for luxury effect */}
        <div className="absolute -top-20 -left-20 w-40 h-40 bg-[#FFC833]/10 rounded-full filter blur-3xl"></div>
        <div className="absolute -bottom-20 -right-20 w-40 h-40 bg-[#FFC833]/10 rounded-full filter blur-3xl"></div>
        
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.2 }}
          className="text-center mb-8 relative"
        >
          <div className="flex items-center justify-center flex-col">
            <motion.div 
              className="bg-gradient-to-r from-[#F7B801] to-[#FFC833] h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg shadow-amber-200/50"
              initial={{ y: -10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.2, delay: 0.1 }}
            >
              <Icon icon="ri-coins-line" className="text-white text-3xl" />
            </motion.div>
            <motion.h1 
              className="font-heading font-bold text-3xl text-[#1A2E44]"
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.2, delay: 0.15 }}
            >
              Khansa
            </motion.h1>
            <motion.p 
              className="text-gray-600 mt-2 font-medium"
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.2, delay: 0.2 }}
            >
              Your pathway to golden investments
            </motion.p>
          </div>
          
          {/* Gold accents */}
          <motion.div 
            className="absolute -right-10 top-0 h-20 w-20 bg-gradient-to-br from-amber-200 to-amber-400 rounded-full opacity-20 filter blur-xl"
            animate={{ 
              scale: [1, 1.2, 1],
              opacity: [0.2, 0.3, 0.2] 
            }}
            transition={{ 
              repeat: Infinity, 
              duration: 4,
              ease: "easeInOut" 
            }}
          />
        </motion.div>
        
        <motion.div
          variants={cardVariants}
          initial="hidden"
          animate="visible"
        >
          <Card className="border-0 shadow-xl bg-white/90 backdrop-blur-sm overflow-hidden">
            <div className="absolute top-0 right-0 h-40 w-40 bg-gradient-to-bl from-amber-100 to-transparent opacity-30 rounded-bl-full"></div>
            
            <CardHeader className="relative z-10">
              <motion.div variants={itemVariants}>
                <CardTitle className="text-xl text-[#1A2E44]">Create your account</CardTitle>
                <CardDescription>Begin your premium investment journey</CardDescription>
              </motion.div>
            </CardHeader>
            
            <CardContent className="relative z-10">
              {registrationError && (
                <motion.div 
                  className="bg-red-50 text-red-600 p-3 rounded-md mb-4 text-sm border border-red-200"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                >
                  {registrationError}
                </motion.div>
              )}
              
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                <motion.div variants={itemVariants} className="space-y-2">
                  <Label htmlFor="name" className="text-[#1A2E44]">Full Name</Label>
                  <Input 
                    id="name" 
                    placeholder="Enter your full name" 
                    {...register("name")} 
                    className="border-amber-200 focus-visible:ring-amber-400 bg-white/80"
                  />
                  {errors.name && (
                    <p className="text-red-500 text-xs">{errors.name.message}</p>
                  )}
                </motion.div>
                
                <motion.div variants={itemVariants} className="space-y-2">
                  <Label htmlFor="username" className="text-[#1A2E44]">Username</Label>
                  <Input 
                    id="username" 
                    placeholder="Choose a username" 
                    {...register("username")} 
                    className="border-amber-200 focus-visible:ring-amber-400 bg-white/80"
                  />
                  {errors.username && (
                    <p className="text-red-500 text-xs">{errors.username.message}</p>
                  )}
                </motion.div>
                
                <motion.div variants={itemVariants} className="space-y-2">
                  <Label htmlFor="email" className="text-[#1A2E44]">Email</Label>
                  <Input 
                    id="email" 
                    type="email"
                    placeholder="Enter your email address" 
                    {...register("email")} 
                    className="border-amber-200 focus-visible:ring-amber-400 bg-white/80"
                  />
                  {errors.email && (
                    <p className="text-red-500 text-xs">{errors.email.message}</p>
                  )}
                </motion.div>
                
                <motion.div variants={itemVariants} className="space-y-2">
                  <Label htmlFor="password" className="text-[#1A2E44]">Password</Label>
                  <div className="relative">
                    <Input 
                      id="password" 
                      type={showPassword ? "text" : "password"} 
                      placeholder="Create a password" 
                      {...register("password")} 
                      className="border-amber-200 focus-visible:ring-amber-400 bg-white/80 pr-10"
                    />
                    <button 
                      type="button"
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-amber-600 hover:text-amber-800 transition-colors"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <Icon icon="ri-eye-off-line" className="h-5 w-5" />
                      ) : (
                        <Icon icon="ri-eye-line" className="h-5 w-5" />
                      )}
                    </button>
                  </div>
                  {errors.password && (
                    <p className="text-red-500 text-xs">{errors.password.message}</p>
                  )}
                </motion.div>
                
                <motion.div variants={itemVariants} className="space-y-2">
                  <Label htmlFor="confirmPassword" className="text-[#1A2E44]">Confirm Password</Label>
                  <div className="relative">
                    <Input 
                      id="confirmPassword" 
                      type={showConfirmPassword ? "text" : "password"} 
                      placeholder="Confirm your password" 
                      {...register("confirmPassword")} 
                      className="border-amber-200 focus-visible:ring-amber-400 bg-white/80 pr-10"
                    />
                    <button 
                      type="button"
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-amber-600 hover:text-amber-800 transition-colors"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    >
                      {showConfirmPassword ? (
                        <Icon icon="ri-eye-off-line" className="h-5 w-5" />
                      ) : (
                        <Icon icon="ri-eye-line" className="h-5 w-5" />
                      )}
                    </button>
                  </div>
                  {errors.confirmPassword && (
                    <p className="text-red-500 text-xs">{errors.confirmPassword.message}</p>
                  )}
                </motion.div>
                
                <motion.div variants={itemVariants}>
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-[#F7B801] to-[#FFC833] text-white hover:shadow-lg hover:shadow-amber-200/50 transition-all"
                    disabled={isRegistering}
                  >
                    {isRegistering ? (
                      <div className="flex items-center">
                        <span className="animate-spin mr-2">
                          <Icon icon="ri-repeat-line" className="h-4 w-4" />
                        </span>
                        Creating account...
                      </div>
                    ) : (
                      "Create Account"
                    )}
                  </Button>
                </motion.div>
              </form>
            </CardContent>
            
            <CardFooter className="flex flex-col space-y-4 relative z-10">
              <motion.div variants={itemVariants} className="text-center text-sm text-gray-600">
                Already have an account?{" "}
                <Link href="/login" className="text-[#F7B801] font-medium hover:underline">
                  Sign in
                </Link>
              </motion.div>
            </CardFooter>
          </Card>
        </motion.div>
        
        {/* Gold coin design elements - faster animations */}
        <motion.div 
          className="absolute -bottom-6 -left-6"
          initial={{ opacity: 0, rotate: -10 }}
          animate={{ opacity: 1, rotate: 0 }}
          transition={{ delay: 0.3, duration: 0.3 }}
        >
          <div className="w-12 h-12 rounded-full bg-gradient-to-r from-[#F7B801] to-[#FFC833] shadow-lg flex items-center justify-center">
            <div className="w-10 h-10 rounded-full border-2 border-amber-400/30 flex items-center justify-center">
              <Icon icon="ri-coin-line" className="text-white text-lg" />
            </div>
          </div>
        </motion.div>
        
        <motion.div 
          className="absolute -top-2 right-2"
          initial={{ opacity: 0, rotate: 10 }}
          animate={{ opacity: 1, rotate: 0 }}
          transition={{ delay: 0.4, duration: 0.3 }}
        >
          <div className="w-10 h-10 rounded-full bg-gradient-to-r from-[#F7B801] to-[#FFC833] shadow-lg flex items-center justify-center transform rotate-12">
            <div className="w-8 h-8 rounded-full border-2 border-amber-400/30 flex items-center justify-center">
              <Icon icon="ri-coin-line" className="text-white text-sm" />
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Register;
