import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Link, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { Icon } from "@/lib/icons";
import Khansa3DLogo from "@/components/ui/khansa-3d-logo";
import GoldCoin3D from "@/components/ui/gold-coin-3d";
import PremiumHeroScene from "@/components/ui/premium-hero-scene";
import GoldAnimation from "@/components/ui/gold-animation";

const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

type LoginFormData = z.infer<typeof loginSchema>;

const Login = () => {
  const { toast } = useToast();
  const { user, isLoading, loginMutation } = useAuth();
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [loginError, setLoginError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [, setLocation] = useLocation();
  
  // Redirect to dashboard if already logged in
  useEffect(() => {
    if (!isLoading && user) {
      setLocation("/");
    }
  }, [user, isLoading, setLocation]);

  const { register, handleSubmit, formState: { errors } } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = async (data: LoginFormData) => {
    setIsLoggingIn(true);
    setLoginError("");
    try {
      await loginMutation.mutateAsync({ 
        username: data.username, 
        password: data.password 
      });
    } catch (error) {
      setLoginError("Invalid username or password. Please try again.");
      toast({
        title: "Login failed",
        description: "Invalid username or password. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoggingIn(false);
    }
  };
  
  // Animation variants with faster transitions
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.05,
        duration: 0.2
      }
    }
  };
  
  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.2 }
    }
  };

  return (
    <div className="min-h-screen overflow-hidden">
      {/* Background with subtle pattern and gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-amber-50 to-amber-100/80 z-0">
        <div className="absolute inset-0 opacity-5" style={{ 
          backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath d=\'M54.627 0l.83.828-1.415 1.415L51.8 0h2.827zM5.373 0l-.83.828L5.96 2.243 8.2 0H5.374zM48.97 0l3.657 3.657-1.414 1.414L46.143 0h2.828zM11.03 0L7.372 3.657 8.787 5.07 13.857 0H11.03zm32.284 0L49.8 6.485 48.384 7.9l-7.9-7.9h2.83zM16.686 0L10.2 6.485 11.616 7.9l7.9-7.9h-2.83zm20.97 0l9.315 9.314-1.414 1.414L34.828 0h2.83zM22.344 0L13.03 9.314l1.414 1.414L25.172 0h-2.83zM32 0l12.142 12.142-1.414 1.414L30 .828 17.272 13.556l-1.414-1.414L28 0h4zM.284 0l28 28-1.414 1.414L0 2.544v2.83L25.456 30l-1.414 1.414-28-28L0 0h.284zM0 5.373l25.456 25.455-1.414 1.415L0 8.2v2.83l21.627 21.628-1.414 1.414L0 13.657v2.828l17.8 17.8-1.414 1.414L0 19.1v2.83l14.142 14.14-1.414 1.415L0 24.544v2.83l10.314 10.313-1.414 1.414L0 30v2.828l6.485 6.485-1.414 1.415L0 35.373v2.83l2.657 2.656-1.414 1.415L0 40.717v2.83l-1.414 1.414L0 47.803v2.83l-1.414 1.415L0 54.627v2.83L0 60h2.828L60 2.828V0h-2.83L0 57.172V60h5.657L60 5.657V0h-2.83L0 52.343V60h8.485L60 8.485V0h-2.83L0 47.515V60h11.314L60 11.314V0h-2.83L0 42.687V60h14.142L60 14.142V0h-2.83L0 37.858V60h17.8L60 16.97V0h-2.83L0 33.03V60h20.627L60 20.627V0h-2.83L0 28.373V60H24.28L60 24.28V0h-2.83L0 23.03V60h28L60 28V0h-2.83L0 17.272V60h32.657L60 32.657V0h-2.83L0 11.515V60h37.515L60 37.515V0h-2.83L0 5.757V60h42.343L60 42.343V0h-2.83L0 0v60h47.172L60 47.172V0h-2.83L0 0v60h52.9L60 56.9V0h-2.83L0 0v60h57.627L60 57.627V0h-2.83L0 0v60h60L60 0H0v60z\' fill=\'%23B45309\' fill-opacity=\'1\' fill-rule=\'evenodd\'/%3E%3C/svg%3E")',
          backgroundSize: '20px 20px',
        }} />
      </div>
      
      {/* Gold animation accents */}
      <GoldAnimation position="top-right" size="lg" intensity="low" />
      <GoldAnimation position="bottom-left" size="md" intensity="medium" />
      
      {/* Main content with 2-column layout */}
      <div className="flex flex-col md:flex-row w-full min-h-screen relative z-10">
        {/* Left column: Auth form */}
        <div className="w-full md:w-1/2 flex items-center justify-center p-6">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="w-full max-w-md"
          >
            {/* Logo */}
            <div className="mb-8 flex justify-center">
              <Khansa3DLogo size="md" />
            </div>
            
            <Card className="border-0 shadow-xl bg-white/90 backdrop-blur-sm overflow-hidden">
              {/* Luxury card design accents */}
              <div className="absolute top-0 right-0 h-40 w-40 bg-gradient-to-bl from-amber-100 to-transparent opacity-30 rounded-bl-full"></div>
              <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-[#F7B801] to-[#FFC833] opacity-50"></div>
              
              <CardHeader className="relative z-10">
                <motion.div variants={itemVariants}>
                  <CardTitle className="text-xl text-amber-900">Welcome back</CardTitle>
                  <CardDescription>Sign in to access your premium gold investments</CardDescription>
                </motion.div>
              </CardHeader>
              
              <CardContent className="relative z-10">
                {loginError && (
                  <motion.div 
                    className="bg-red-50 text-red-600 p-3 rounded-md mb-4 text-sm border border-red-200"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                  >
                    {loginError}
                  </motion.div>
                )}
                
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                  <motion.div variants={itemVariants} className="space-y-2">
                    <Label htmlFor="username" className="text-amber-900">Username</Label>
                    <Input 
                      id="username" 
                      placeholder="Enter your username" 
                      {...register("username")} 
                      className="border-amber-200 focus-visible:ring-amber-400 bg-white/80"
                    />
                    {errors.username && (
                      <p className="text-red-500 text-xs">{errors.username.message}</p>
                    )}
                  </motion.div>
                  
                  <motion.div variants={itemVariants} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <Label htmlFor="password" className="text-amber-900">Password</Label>
                      <Link href="/forgot-password" className="text-xs text-amber-600 hover:text-amber-800 hover:underline">
                        Forgot password?
                      </Link>
                    </div>
                    <div className="relative">
                      <Input 
                        id="password" 
                        type={showPassword ? "text" : "password"} 
                        placeholder="Enter your password" 
                        {...register("password")} 
                        className="border-amber-200 focus-visible:ring-amber-400 bg-white/80 pr-10"
                      />
                      <button 
                        type="button"
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-amber-600 hover:text-amber-800 transition-colors"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? (
                          <Icon icon="ri-eye-off-line" className="h-5 w-5" />
                        ) : (
                          <Icon icon="ri-eye-line" className="h-5 w-5" />
                        )}
                      </button>
                    </div>
                    {errors.password && (
                      <p className="text-red-500 text-xs">{errors.password.message}</p>
                    )}
                  </motion.div>
                  
                  <motion.div variants={itemVariants}>
                    <Button 
                      type="submit" 
                      className="w-full bg-gradient-to-r from-[#F7B801] to-[#FFC833] text-white hover:shadow-lg hover:shadow-amber-200/50 transition-all"
                      disabled={isLoggingIn}
                    >
                      {isLoggingIn ? (
                        <div className="flex items-center">
                          <span className="animate-spin mr-2">
                            <Icon icon="ri-repeat-line" className="h-4 w-4" />
                          </span>
                          Signing in...
                        </div>
                      ) : (
                        "Sign In"
                      )}
                    </Button>
                  </motion.div>
                </form>
              </CardContent>
              
              <CardFooter className="flex flex-col space-y-4 relative z-10">
                <motion.div variants={itemVariants} className="text-center text-sm text-amber-800">
                  Don't have an account?{" "}
                  <Link href="/register" className="text-[#F7B801] font-medium hover:underline">
                    Sign up
                  </Link>
                </motion.div>
              </CardFooter>
            </Card>
            
            {/* 3D Coin Decorations */}
            <div className="relative">
              <div className="absolute -bottom-10 -left-10">
                <GoldCoin3D size={70} autoRotate={true} />
              </div>
              <div className="absolute -top-16 -right-10">
                <GoldCoin3D size={50} autoRotate={true} />
              </div>
            </div>
          </motion.div>
        </div>
        
        {/* Right column: Premium hero scene */}
        <div className="hidden md:block md:w-1/2 relative">
          <PremiumHeroScene className="h-full" />
        </div>
      </div>
    </div>
  );
};

export default Login;
