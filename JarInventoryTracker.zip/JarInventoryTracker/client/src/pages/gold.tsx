import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import Sidebar from "@/components/layout/sidebar";
import MobileHeader from "@/components/layout/mobile-header";
import MobileNavigation from "@/components/layout/mobile-navigation";
import GoldPriceChart from "@/components/ui/gold-price-chart";
import EducationalBanner from "@/components/dashboard/educational-banner";
import { useAuth } from "@/hooks/use-auth";
import type { GoldPrice, Investment } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

const Gold = () => {
  const { toast } = useToast();
  const [timeframe, setTimeframe] = useState("Past Month");
  const [, navigate] = useLocation();
  const { user } = useAuth();

  const { data: goldPrice, isLoading: isLoadingGoldPrice } = useQuery<GoldPrice>({
    queryKey: ["/api/gold/price"],
  });

  const { data: investment, isLoading: isLoadingInvestment } = useQuery<Investment>({
    queryKey: ["/api/investments"],
  });

  const handleBuyGold = () => {
    navigate("/buy-gold");
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <MobileHeader />
      
      <main className="flex-1 pb-20 md:pb-0 md:flex">
        <Sidebar />
        
        <div className="w-full md:flex-1 px-4 md:px-8 py-4 md:py-8">
          <div className="md:max-w-4xl mx-auto">
            <h1 className="font-heading font-bold text-2xl mb-6 text-[#1A2E44]">Digital Gold Investment</h1>
            
            {/* Gold Investment Summary */}
            <Card className="bg-white rounded-xl shadow-md p-6 mb-6">
              <CardContent className="p-0">
                <div className="flex flex-col md:flex-row md:items-center mb-6">
                  <div className="flex-1">
                    <div className="flex items-center mb-4">
                      <div className="bg-[#F7B801] h-12 w-12 rounded-full flex items-center justify-center mr-4">
                        <i className="ri-coin-line text-white text-xl"></i>
                      </div>
                      <div>
                        <h2 className="font-heading font-semibold text-lg">Your Gold Portfolio</h2>
                        <p className="text-sm text-gray-500">24K Digital Gold</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-6 mb-6">
                      <div>
                        <p className="text-sm text-gray-500 mb-1">Gold Quantity</p>
                        <p className="font-mono text-2xl font-medium">
                          {isLoadingInvestment ? "..." : `${investment?.goldAmount || "0.00"} gm`}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500 mb-1">Current Value</p>
                        <p className="font-mono text-2xl font-medium">
                          ₹{isLoadingInvestment ? "..." : investment?.goldValue || "0.00"}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Buy/Sell Gold buttons */}
                <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 mb-6">
                  <Button 
                    onClick={handleBuyGold}
                    className="bg-gradient-to-r from-[#F7B801] to-[#FFC833] text-white flex-1 space-x-2"
                  >
                    <i className="ri-add-line"></i>
                    <span>Buy Gold</span>
                  </Button>
                  <Button variant="outline" className="flex-1 space-x-2">
                    <i className="ri-exchange-line"></i>
                    <span>Sell Gold</span>
                  </Button>
                </div>
                
                {/* Returns */}
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="font-medium mb-3">Your Returns</h3>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div>
                      <p className="text-xs text-gray-500 mb-1">Today</p>
                      <p className="font-medium text-green-500">+0.8%</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 mb-1">This Month</p>
                      <p className="font-medium text-green-500">+2.5%</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 mb-1">This Year</p>
                      <p className="font-medium text-green-500">+12.4%</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Gold Price Chart */}
            <Card className="bg-white rounded-xl shadow-md p-4 mb-6">
              <CardHeader className="p-0 mb-4">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-heading">Gold Price Trends</CardTitle>
                  <Select value={timeframe} onValueChange={setTimeframe}>
                    <SelectTrigger className="w-[180px] text-sm bg-gray-100 border-none rounded-lg">
                      <SelectValue placeholder="Past Month" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Past Month">Past Month</SelectItem>
                      <SelectItem value="Past 3 Months">Past 3 Months</SelectItem>
                      <SelectItem value="Past Year">Past Year</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="flex justify-between items-baseline mb-2">
                  <p className="font-mono text-lg font-medium">
                    ₹{isLoadingGoldPrice ? "..." : goldPrice?.pricePerGram}
                    <span className="text-xs text-gray-500 ml-1">per gram</span>
                  </p>
                  {!isLoadingGoldPrice && goldPrice && (
                    <span className="text-green-500 text-sm flex items-center">
                      <i className="ri-arrow-up-line mr-1"></i>{goldPrice.change24h}%
                    </span>
                  )}
                </div>
                
                {isLoadingGoldPrice ? (
                  <div className="h-48 bg-gray-100 rounded-lg mb-4 animate-pulse"></div>
                ) : (
                  <GoldPriceChart 
                    data={goldPrice?.priceHistory as any || []}
                    timeframe={timeframe}
                  />
                )}
                
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="bg-gray-50 rounded-lg p-2">
                    <p className="text-xs text-gray-500">24h Change</p>
                    {isLoadingGoldPrice ? (
                      <div className="h-4 bg-gray-200 rounded w-12 mx-auto animate-pulse"></div>
                    ) : (
                      <p className={`font-medium ${parseFloat(goldPrice?.change24h.toString() || "0") >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {parseFloat(goldPrice?.change24h.toString() || "0") >= 0 ? '+' : ''}{goldPrice?.change24h}%
                      </p>
                    )}
                  </div>
                  <div className="bg-gray-50 rounded-lg p-2">
                    <p className="text-xs text-gray-500">7d Change</p>
                    {isLoadingGoldPrice ? (
                      <div className="h-4 bg-gray-200 rounded w-12 mx-auto animate-pulse"></div>
                    ) : (
                      <p className={`font-medium ${parseFloat(goldPrice?.change7d.toString() || "0") >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {parseFloat(goldPrice?.change7d.toString() || "0") >= 0 ? '+' : ''}{goldPrice?.change7d}%
                      </p>
                    )}
                  </div>
                  <div className="bg-gray-50 rounded-lg p-2">
                    <p className="text-xs text-gray-500">30d Change</p>
                    {isLoadingGoldPrice ? (
                      <div className="h-4 bg-gray-200 rounded w-12 mx-auto animate-pulse"></div>
                    ) : (
                      <p className={`font-medium ${parseFloat(goldPrice?.change30d.toString() || "0") >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {parseFloat(goldPrice?.change30d.toString() || "0") >= 0 ? '+' : ''}{goldPrice?.change30d}%
                      </p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Benefits of Gold Investment */}
            <Card className="bg-white rounded-xl shadow-md p-6 mb-6">
              <CardHeader className="p-0 mb-4">
                <CardTitle className="text-lg font-heading">Why Invest in Digital Gold?</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="bg-[#FFF8E6] p-4 rounded-lg">
                    <div className="bg-[#F7B801] h-10 w-10 rounded-full flex items-center justify-center mb-3">
                      <i className="ri-shield-check-line text-white"></i>
                    </div>
                    <h3 className="font-medium mb-2">Safe & Secure</h3>
                    <p className="text-sm text-gray-600">
                      Your gold is 100% insured and stored in secure vaults with complete documentation.
                    </p>
                  </div>
                  
                  <div className="bg-[#E6EBF0] p-4 rounded-lg">
                    <div className="bg-[#1A2E44] h-10 w-10 rounded-full flex items-center justify-center mb-3">
                      <i className="ri-cash-line text-white"></i>
                    </div>
                    <h3 className="font-medium mb-2">High Liquidity</h3>
                    <p className="text-sm text-gray-600">
                      Easily sell your gold at any time and get money directly into your bank account.
                    </p>
                  </div>
                  
                  <div className="bg-[#E6FFF5] p-4 rounded-lg">
                    <div className="bg-[#00C9A7] h-10 w-10 rounded-full flex items-center justify-center mb-3">
                      <i className="ri-funds-line text-white"></i>
                    </div>
                    <h3 className="font-medium mb-2">Wealth Growth</h3>
                    <p className="text-sm text-gray-600">
                      Historically, gold has provided protection against inflation and economic uncertainty.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Educational Banner */}
            <EducationalBanner />
          </div>
        </div>
      </main>
      
      <MobileNavigation />
    </div>
  );
};

export default Gold;
