import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { Icon } from "@/lib/icons";
import { apiRequest } from "@/lib/queryClient";

const forgotPasswordSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

type ForgotPasswordFormData = z.infer<typeof forgotPasswordSchema>;

const ForgotPassword = () => {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<ForgotPasswordFormData>({
    resolver: zodResolver(forgotPasswordSchema),
  });

  const onSubmit = async (data: ForgotPasswordFormData) => {
    setIsSubmitting(true);
    
    try {
      await apiRequest("POST", "/api/forgot-password", data);
      
      // Show success toast
      toast({
        title: "Reset email sent",
        description: "If an account exists with that email, you'll receive a password reset link shortly.",
        variant: "default",
      });
      
      setEmailSent(true);
    } catch (error: any) {
      console.error("Password reset error:", error);
      
      // Show error toast
      toast({
        title: "Error",
        description: "There was an error processing your request. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { 
        duration: 0.6,
        ease: "easeOut",
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.4 }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-[#1A2E44]/5 to-[#FFF8E6]/40 px-4 py-8">
      <div className="w-full max-w-md z-10 relative">
        {/* Gold particles for luxury effect */}
        <div className="absolute -top-20 -left-20 w-40 h-40 bg-[#FFC833]/10 rounded-full filter blur-3xl"></div>
        <div className="absolute -bottom-20 -right-20 w-40 h-40 bg-[#FFC833]/10 rounded-full filter blur-3xl"></div>
        
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8 relative"
        >
          <div className="flex items-center justify-center flex-col">
            <motion.div 
              className="bg-gradient-to-r from-[#F7B801] to-[#FFC833] h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg shadow-amber-200/50"
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Icon icon="ri-lock-line" className="text-white text-3xl" />
            </motion.div>
            <motion.h1 
              className="font-heading font-bold text-3xl text-[#1A2E44]"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              Khansa
            </motion.h1>
          </div>
        </motion.div>
        
        <motion.div
          variants={cardVariants}
          initial="hidden"
          animate="visible"
        >
          <Card className="border-0 shadow-xl bg-white/90 backdrop-blur-sm overflow-hidden">
            <div className="absolute top-0 right-0 h-40 w-40 bg-gradient-to-bl from-amber-100 to-transparent opacity-30 rounded-bl-full"></div>
            
            <CardHeader className="relative z-10">
              <motion.div variants={itemVariants}>
                <CardTitle className="text-xl text-[#1A2E44]">Forgot Password</CardTitle>
                <CardDescription>Enter your email to reset your password</CardDescription>
              </motion.div>
            </CardHeader>
            
            <CardContent className="relative z-10">
              {emailSent ? (
                <motion.div 
                  className="bg-green-50 text-green-700 p-4 rounded-md space-y-4"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  <div className="flex items-center justify-center mb-2">
                    <div className="bg-green-100 rounded-full p-2 mr-2">
                      <Icon icon="ri-mail-check-line" className="h-6 w-6 text-green-600" />
                    </div>
                  </div>
                  <h3 className="font-medium text-center">Check your email</h3>
                  <p className="text-sm text-center">
                    If an account exists with that email, you'll receive a password reset link shortly.
                  </p>
                  <p className="text-xs text-center text-green-600 mt-2">
                    Don't forget to check your spam folder.
                  </p>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                  <motion.div variants={itemVariants} className="space-y-2">
                    <Label htmlFor="email" className="text-[#1A2E44]">Email</Label>
                    <Input 
                      id="email" 
                      type="email"
                      placeholder="Enter your email address" 
                      {...register("email")} 
                      className="border-amber-200 focus-visible:ring-amber-400 bg-white/80"
                    />
                    {errors.email && (
                      <p className="text-red-500 text-xs">{errors.email.message}</p>
                    )}
                  </motion.div>
                  
                  <motion.div variants={itemVariants}>
                    <Button 
                      type="submit" 
                      className="w-full bg-gradient-to-r from-[#F7B801] to-[#FFC833] text-white hover:shadow-lg hover:shadow-amber-200/50 transition-all"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <div className="flex items-center">
                          <span className="animate-spin mr-2">
                            <Icon icon="ri-repeat-line" className="h-4 w-4" />
                          </span>
                          Sending...
                        </div>
                      ) : (
                        "Send Reset Link"
                      )}
                    </Button>
                  </motion.div>
                </form>
              )}
            </CardContent>
            
            <CardFooter className="flex flex-col space-y-4 relative z-10">
              <motion.div variants={itemVariants} className="text-center text-sm text-gray-600">
                Remember your password?{" "}
                <Link href="/login">
                  <a className="text-[#F7B801] font-medium hover:underline">Sign in</a>
                </Link>
              </motion.div>
            </CardFooter>
          </Card>
        </motion.div>
        
        {/* Gold coin design element */}
        <motion.div 
          className="absolute -bottom-6 -left-6"
          initial={{ opacity: 0, rotate: -20 }}
          animate={{ opacity: 1, rotate: 0 }}
          transition={{ delay: 0.7, duration: 0.8 }}
        >
          <div className="w-12 h-12 rounded-full bg-gradient-to-r from-[#F7B801] to-[#FFC833] shadow-lg flex items-center justify-center">
            <div className="w-10 h-10 rounded-full border-2 border-amber-400/30 flex items-center justify-center">
              <Icon icon="ri-lock-password-line" className="text-white text-lg" />
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default ForgotPassword;