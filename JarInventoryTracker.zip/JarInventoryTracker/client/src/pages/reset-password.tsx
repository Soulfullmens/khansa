import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Link, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { Icon } from "@/lib/icons";
import { apiRequest } from "@/lib/queryClient";

const resetPasswordSchema = z.object({
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(1, "Please confirm your password"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type ResetPasswordFormData = z.infer<typeof resetPasswordSchema>;

const ResetPassword = () => {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isResetting, setIsResetting] = useState(false);
  const [resetComplete, setResetComplete] = useState(false);
  const [token, setToken] = useState<string | null>(null);
  const [tokenInvalid, setTokenInvalid] = useState(false);
  
  useEffect(() => {
    // Extract token from URL query parameters
    const queryParams = new URLSearchParams(window.location.search);
    const resetToken = queryParams.get('token');
    
    if (!resetToken) {
      setTokenInvalid(true);
      toast({
        title: "Invalid request",
        description: "The password reset link is invalid or expired.",
        variant: "destructive",
      });
    } else {
      setToken(resetToken);
    }
  }, [toast]);

  const { register, handleSubmit, formState: { errors } } = useForm<ResetPasswordFormData>({
    resolver: zodResolver(resetPasswordSchema),
  });

  const onSubmit = async (data: ResetPasswordFormData) => {
    if (!token) return;
    
    setIsResetting(true);
    
    try {
      await apiRequest("POST", "/api/reset-password", {
        token,
        password: data.password
      });
      
      // Show success toast
      toast({
        title: "Password reset successful",
        description: "Your password has been reset. You can now log in with your new password.",
        variant: "default",
      });
      
      setResetComplete(true);
      
      // Redirect to login after 3 seconds
      setTimeout(() => {
        setLocation("/login");
      }, 3000);
    } catch (error: any) {
      console.error("Password reset error:", error);
      
      let errorMessage = "There was an error resetting your password. Please try again.";
      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      }
      
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
      
      if (errorMessage.includes("Invalid or expired token")) {
        setTokenInvalid(true);
      }
    } finally {
      setIsResetting(false);
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { 
        duration: 0.6,
        ease: "easeOut",
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.4 }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-[#1A2E44]/5 to-[#FFF8E6]/40 px-4 py-8">
      <div className="w-full max-w-md z-10 relative">
        {/* Gold particles for luxury effect */}
        <div className="absolute -top-20 -left-20 w-40 h-40 bg-[#FFC833]/10 rounded-full filter blur-3xl"></div>
        <div className="absolute -bottom-20 -right-20 w-40 h-40 bg-[#FFC833]/10 rounded-full filter blur-3xl"></div>
        
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8 relative"
        >
          <div className="flex items-center justify-center flex-col">
            <motion.div 
              className="bg-gradient-to-r from-[#F7B801] to-[#FFC833] h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg shadow-amber-200/50"
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Icon icon="ri-lock-unlock-line" className="text-white text-3xl" />
            </motion.div>
            <motion.h1 
              className="font-heading font-bold text-3xl text-[#1A2E44]"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              Khansa
            </motion.h1>
          </div>
        </motion.div>
        
        <motion.div
          variants={cardVariants}
          initial="hidden"
          animate="visible"
        >
          <Card className="border-0 shadow-xl bg-white/90 backdrop-blur-sm overflow-hidden">
            <div className="absolute top-0 right-0 h-40 w-40 bg-gradient-to-bl from-amber-100 to-transparent opacity-30 rounded-bl-full"></div>
            
            <CardHeader className="relative z-10">
              <motion.div variants={itemVariants}>
                <CardTitle className="text-xl text-[#1A2E44]">Reset Password</CardTitle>
                <CardDescription>Create a new password for your account</CardDescription>
              </motion.div>
            </CardHeader>
            
            <CardContent className="relative z-10">
              {tokenInvalid ? (
                <motion.div 
                  className="bg-red-50 text-red-700 p-4 rounded-md space-y-4"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  <div className="flex items-center justify-center mb-2">
                    <div className="bg-red-100 rounded-full p-2 mr-2">
                      <Icon icon="ri-error-warning-line" className="h-6 w-6 text-red-600" />
                    </div>
                  </div>
                  <h3 className="font-medium text-center">Invalid or Expired Link</h3>
                  <p className="text-sm text-center">
                    The password reset link is invalid or has expired. Please request a new password reset link.
                  </p>
                  <div className="pt-2">
                    <Button
                      onClick={() => setLocation("/forgot-password")}
                      variant="outline"
                      className="w-full border-amber-200 text-amber-800 hover:bg-amber-50"
                    >
                      Request New Link
                    </Button>
                  </div>
                </motion.div>
              ) : resetComplete ? (
                <motion.div 
                  className="bg-green-50 text-green-700 p-4 rounded-md space-y-4"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  <div className="flex items-center justify-center mb-2">
                    <div className="bg-green-100 rounded-full p-2 mr-2">
                      <Icon icon="ri-check-line" className="h-6 w-6 text-green-600" />
                    </div>
                  </div>
                  <h3 className="font-medium text-center">Password Reset Successful</h3>
                  <p className="text-sm text-center">
                    Your password has been reset successfully. You can now log in with your new password.
                  </p>
                  <p className="text-xs text-center text-green-600 mt-2">
                    Redirecting to login page...
                  </p>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                  <motion.div variants={itemVariants} className="space-y-2">
                    <Label htmlFor="password" className="text-[#1A2E44]">New Password</Label>
                    <Input 
                      id="password" 
                      type="password"
                      placeholder="Enter your new password" 
                      {...register("password")} 
                      className="border-amber-200 focus-visible:ring-amber-400 bg-white/80"
                    />
                    {errors.password && (
                      <p className="text-red-500 text-xs">{errors.password.message}</p>
                    )}
                  </motion.div>
                  
                  <motion.div variants={itemVariants} className="space-y-2">
                    <Label htmlFor="confirmPassword" className="text-[#1A2E44]">Confirm Password</Label>
                    <Input 
                      id="confirmPassword" 
                      type="password"
                      placeholder="Confirm your new password" 
                      {...register("confirmPassword")} 
                      className="border-amber-200 focus-visible:ring-amber-400 bg-white/80"
                    />
                    {errors.confirmPassword && (
                      <p className="text-red-500 text-xs">{errors.confirmPassword.message}</p>
                    )}
                  </motion.div>
                  
                  <motion.div variants={itemVariants}>
                    <Button 
                      type="submit" 
                      className="w-full bg-gradient-to-r from-[#F7B801] to-[#FFC833] text-white hover:shadow-lg hover:shadow-amber-200/50 transition-all"
                      disabled={isResetting}
                    >
                      {isResetting ? (
                        <div className="flex items-center">
                          <span className="animate-spin mr-2">
                            <Icon icon="ri-repeat-line" className="h-4 w-4" />
                          </span>
                          Resetting...
                        </div>
                      ) : (
                        "Reset Password"
                      )}
                    </Button>
                  </motion.div>
                </form>
              )}
            </CardContent>
            
            <CardFooter className="flex flex-col space-y-4 relative z-10">
              <motion.div variants={itemVariants} className="text-center text-sm text-gray-600">
                Remember your password?{" "}
                <Link href="/login">
                  <a className="text-[#F7B801] font-medium hover:underline">Sign in</a>
                </Link>
              </motion.div>
            </CardFooter>
          </Card>
        </motion.div>
        
        {/* Gold coin design element */}
        <motion.div 
          className="absolute -bottom-6 -left-6"
          initial={{ opacity: 0, rotate: -20 }}
          animate={{ opacity: 1, rotate: 0 }}
          transition={{ delay: 0.7, duration: 0.8 }}
        >
          <div className="w-12 h-12 rounded-full bg-gradient-to-r from-[#F7B801] to-[#FFC833] shadow-lg flex items-center justify-center">
            <div className="w-10 h-10 rounded-full border-2 border-amber-400/30 flex items-center justify-center">
              <Icon icon="ri-key-2-line" className="text-white text-lg" />
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default ResetPassword;