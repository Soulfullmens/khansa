import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { CheckCircle, Coins, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import DeepSeaAnimation from '@/components/ui/deep-sea-animation';
import { useAuth } from '@/hooks/use-auth';
import GoldCoin3D from '@/components/ui/gold-coin-3d';
import { LUXURY_PALETTE } from '@/lib/luxury-palette';

export default function PaymentSuccess() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [countdown, setCountdown] = useState(5);
  const [isGoldPurchase, setIsGoldPurchase] = useState(false);
  const [goldGrams, setGoldGrams] = useState(0);
  const [pricePerGram, setPricePerGram] = useState(0);

  // Check if there's a payment_intent in the URL
  const hasPaymentIntent = window.location.search.includes('payment_intent');
  
  useEffect(() => {
    // Get parameters from URL
    const params = new URLSearchParams(window.location.search);
    const goldGramsParam = params.get('goldGrams');
    const pricePerGramParam = params.get('pricePerGram');
    
    if (goldGramsParam && pricePerGramParam) {
      setIsGoldPurchase(true);
      setGoldGrams(parseFloat(goldGramsParam));
      setPricePerGram(parseFloat(pricePerGramParam));
    }
  }, []);

  useEffect(() => {
    // Redirect if no user or no payment intent in URL (direct access)
    if (!user && !hasPaymentIntent) {
      setLocation('/');
      return;
    }

    // Countdown to redirect
    const timer = setTimeout(() => {
      if (countdown <= 1) {
        setLocation('/dashboard');
      } else {
        setCountdown(countdown - 1);
      }
    }, 1000);

    return () => clearTimeout(timer);
  }, [countdown, setLocation, user, hasPaymentIntent]);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background animation */}
      <div className="absolute inset-0 z-0">
        <DeepSeaAnimation className="w-full h-full" />
      </div>
      
      <div className="container max-w-md mx-auto z-10 px-4">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, type: 'spring' }}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-xl overflow-hidden backdrop-blur-sm bg-opacity-90 dark:bg-opacity-90"
        >
          <div className="p-8 text-center">
            <div className="mb-6 flex justify-center">
              <GoldCoin3D size={100} autoRotate />
            </div>
            
            <div className="mb-6 inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 dark:bg-green-900">
              <CheckCircle className="h-10 w-10 text-green-500 dark:text-green-400" />
            </div>
            
            <h2 className="text-2xl font-bold mb-2 text-gray-900 dark:text-white">
              Payment Successful!
            </h2>
            
            {isGoldPurchase ? (
              <div className="space-y-4 mb-6">
                <p className="text-gray-600 dark:text-gray-300">
                  Your gold purchase has been processed. Our system is now allocating your digital gold at the current market rate.
                </p>
                
                <div 
                  style={{ backgroundColor: LUXURY_PALETTE.gold[100], borderColor: LUXURY_PALETTE.gold[200] }}
                  className="border rounded-lg p-4 mx-auto"
                >
                  <div className="space-y-2 text-left">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600 dark:text-gray-400 flex items-center">
                        <Coins className="h-4 w-4 mr-1" />
                        Gold Amount:
                      </span>
                      <span 
                        style={{ color: LUXURY_PALETTE.gold[700] }}
                        className="font-bold"
                      >
                        {goldGrams.toFixed(6)} grams
                      </span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Purchase Rate:</span>
                      <span className="font-medium flex items-center">
                        ₹{pricePerGram.toLocaleString('en-IN', { maximumFractionDigits: 2 })}/g
                        <TrendingUp className="h-3 w-3 ml-1 text-green-500" />
                      </span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600 dark:text-gray-400">Value:</span>
                      <span className="font-medium">
                        ₹{(goldGrams * pricePerGram).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
                
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Note: Gold purchase details will show in your dashboard within a few moments. 
                </p>
              </div>
            ) : (
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                Thank you for your payment. Your investment journey with Khansa is now enhanced with premium features.
              </p>
            )}
            
            <div className="mb-6 p-4 bg-blue-50 dark:bg-blue-900/30 rounded-md">
              <p className="text-sm text-blue-800 dark:text-blue-200">
                You will be redirected to your dashboard in {countdown} seconds.
              </p>
            </div>
            
            <Button
              onClick={() => setLocation('/dashboard')}
              className="w-full"
            >
              Go to Dashboard Now
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}