import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAuth } from '@/hooks/use-auth';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Loader2, TrendingUp, Info, Scale, Percent } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import GoldCoin3D from '@/components/ui/gold-coin-3d';
import DeepSeaAnimation from '@/components/ui/deep-sea-animation';
import { LUXURY_PALETTE } from '@/lib/luxury-palette';

// Form schema
const buyGoldSchema = z.object({
  amount: z.preprocess(
    (val) => (val === '' ? undefined : Number(val)),
    z.number({ invalid_type_error: "Amount must be a number" })
      .positive("Amount must be positive")
      .min(100, "Minimum investment is ₹100")
  )
});

type BuyGoldFormData = z.infer<typeof buyGoldSchema>;

const predefinedAmounts = [500, 1000, 5000, 10000];

export default function BuyGold() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [goldPrice, setGoldPrice] = useState<number | null>(null);
  const [priceChange, setPriceChange] = useState<string | null>(null);
  const [isPositiveChange, setIsPositiveChange] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [estimatedGold, setEstimatedGold] = useState<number>(0);

  // Form setup
  const form = useForm<BuyGoldFormData>({
    resolver: zodResolver(buyGoldSchema),
    defaultValues: {
      amount: 1000
    }
  });
  
  const watchAmount = form.watch('amount');
  
  useEffect(() => {
    // Redirect to auth if no user
    if (!user) {
      setLocation('/auth');
      return;
    }

    // Fetch current gold price
    const fetchGoldPrice = async () => {
      try {
        setIsLoading(true);
        const response = await apiRequest('GET', '/api/gold/price');
        const data = await response.json();
        
        const price = parseFloat(data.pricePerGram);
        setGoldPrice(price);
        
        const change = data.change24h;
        setPriceChange(change);
        setIsPositiveChange(parseFloat(change) >= 0);
        
        setIsLoading(false);
      } catch (error) {
        console.error('Failed to fetch gold price:', error);
        toast({
          title: 'Failed to get gold price',
          description: 'Please try again later',
          variant: 'destructive'
        });
        setIsLoading(false);
      }
    };

    fetchGoldPrice();
  }, [user, setLocation, toast]);

  // Update estimated gold when amount or price changes
  useEffect(() => {
    if (goldPrice && watchAmount) {
      const gramsOfGold = watchAmount / goldPrice;
      setEstimatedGold(gramsOfGold);
    } else {
      setEstimatedGold(0);
    }
  }, [watchAmount, goldPrice]);

  const onSelectPredefinedAmount = (amount: number) => {
    form.setValue('amount', amount);
    form.trigger('amount');
  };

  const onSubmit = (data: BuyGoldFormData) => {
    if (!goldPrice) {
      toast({
        title: 'Gold price unavailable',
        description: 'Please try again when gold pricing is available',
        variant: 'destructive'
      });
      return;
    }
    
    // Navigate to checkout with amount
    setLocation(`/checkout?amount=${data.amount}&goldGrams=${estimatedGold.toFixed(6)}&pricePerGram=${goldPrice}`);
  };

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
          <p>Loading gold prices...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12 px-4 sm:px-6 lg:px-8 relative">
      {/* Background animation */}
      <div className="fixed inset-0 -z-10">
        <DeepSeaAnimation className="w-full h-full" />
      </div>
      
      <div className="max-w-4xl mx-auto relative z-10">
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="mb-8 text-center"
        >
          <h1 className="text-3xl font-bold mb-2 text-gray-900 dark:text-white">Buy Digital Gold</h1>
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Invest in pure 999.9 gold seamlessly with Khansa, and build your wealth over time.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          {/* Gold info section */}
          <div className="md:col-span-5 space-y-6">
            <Card className="backdrop-blur-sm bg-white/90 dark:bg-gray-900/90 shadow-xl overflow-hidden border-0">
              <CardHeader className="pb-2">
                <CardTitle>Current Gold Rate</CardTitle>
                <CardDescription>Today's 99.9% pure gold price</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center py-4">
                  <GoldCoin3D size={120} autoRotate />
                  
                  <div className="mt-6 text-center">
                    <div className="text-3xl font-bold mb-1">
                      ₹{goldPrice?.toLocaleString('en-IN', { maximumFractionDigits: 2 })}
                      <span className="text-sm font-normal text-gray-500 dark:text-gray-400 ml-1">
                        per gram
                      </span>
                    </div>
                    
                    {priceChange && (
                      <div 
                        className={`text-sm font-medium flex items-center justify-center ${
                          isPositiveChange ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                        }`}
                      >
                        <TrendingUp className="h-4 w-4 mr-1" />
                        {isPositiveChange ? '+' : ''}{priceChange}% in 24h
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg">
                    <div className="flex items-center mb-1">
                      <Scale className="h-4 w-4 mr-1 text-primary" />
                      <span className="text-xs text-gray-500 dark:text-gray-400">Purity</span>
                    </div>
                    <p className="font-medium">999.9 (24 Karat)</p>
                  </div>
                  
                  <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg">
                    <div className="flex items-center mb-1">
                      <Percent className="h-4 w-4 mr-1 text-primary" />
                      <span className="text-xs text-gray-500 dark:text-gray-400">Buy Charges</span>
                    </div>
                    <p className="font-medium">3% (Included)</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="backdrop-blur-sm bg-white/90 dark:bg-gray-900/90 shadow-md border-0">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center text-base">
                  <Info className="h-4 w-4 mr-2 text-primary" />
                  Why Buy Digital Gold?
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start">
                    <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center mr-2 flex-shrink-0 mt-0.5">
                      <span className="text-xs text-primary">✓</span>
                    </div>
                    <span>Start with as little as ₹100</span>
                  </li>
                  <li className="flex items-start">
                    <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center mr-2 flex-shrink-0 mt-0.5">
                      <span className="text-xs text-primary">✓</span>
                    </div>
                    <span>99.9% pure gold backed by physical reserves</span>
                  </li>
                  <li className="flex items-start">
                    <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center mr-2 flex-shrink-0 mt-0.5">
                      <span className="text-xs text-primary">✓</span>
                    </div>
                    <span>Safe, secure, and insured digital storage</span>
                  </li>
                  <li className="flex items-start">
                    <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center mr-2 flex-shrink-0 mt-0.5">
                      <span className="text-xs text-primary">✓</span>
                    </div>
                    <span>Sell easily anytime with 24-hour liquidity</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
          
          {/* Buy form section */}
          <div className="md:col-span-7">
            <Card className="backdrop-blur-sm bg-white/90 dark:bg-gray-900/90 shadow-xl border-0">
              <CardHeader>
                <CardTitle>Buy Gold</CardTitle>
                <CardDescription>Enter the amount you wish to invest</CardDescription>
              </CardHeader>
              
              <CardContent>
                <Tabs defaultValue="amount" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 mb-6">
                    <TabsTrigger value="amount">By Amount (₹)</TabsTrigger>
                    <TabsTrigger value="gold" disabled>By Gold Weight (g)</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="amount">
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <FormField
                          control={form.control}
                          name="amount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Investment Amount (₹)</FormLabel>
                              <FormControl>
                                <Input
                                  {...field}
                                  type="number"
                                  placeholder="Enter amount"
                                  className="text-xl py-6"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div>
                          <div className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                            Quick Select Amount
                          </div>
                          <div className="grid grid-cols-4 gap-2">
                            {predefinedAmounts.map((amount) => (
                              <Button
                                key={amount}
                                type="button"
                                variant="outline"
                                onClick={() => onSelectPredefinedAmount(amount)}
                                className={`border-primary/30 ${
                                  watchAmount === amount ? 'bg-primary/10 border-primary' : ''
                                }`}
                              >
                                ₹{amount.toLocaleString('en-IN')}
                              </Button>
                            ))}
                          </div>
                        </div>
                        
                        {goldPrice && (
                          <div 
                            style={{ 
                              backgroundColor: LUXURY_PALETTE.gold[100],
                              borderColor: LUXURY_PALETTE.gold[200]
                            }}
                            className="border rounded-lg p-4"
                          >
                            <div className="flex justify-between mb-2">
                              <span className="text-sm text-gray-600 dark:text-gray-400">Amount:</span>
                              <span className="font-medium">₹{watchAmount?.toLocaleString('en-IN') || 0}</span>
                            </div>
                            <div className="flex justify-between mb-2">
                              <span className="text-sm text-gray-600 dark:text-gray-400">Current Rate:</span>
                              <span className="font-medium">₹{goldPrice.toLocaleString('en-IN', { maximumFractionDigits: 2 })}/g</span>
                            </div>
                            <div className="border-t border-gold-200 my-2"></div>
                            <div className="flex justify-between">
                              <span className="text-sm font-medium">Gold You'll Get:</span>
                              <span 
                                style={{ color: LUXURY_PALETTE.gold[700] }}
                                className="font-bold"
                              >
                                {estimatedGold.toFixed(6)} grams
                              </span>
                            </div>
                          </div>
                        )}
                        
                        <Button 
                          type="submit" 
                          className="w-full py-6 text-lg"
                          disabled={!goldPrice || form.formState.isSubmitting}
                        >
                          {form.formState.isSubmitting ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Processing...
                            </>
                          ) : (
                            'Proceed to Payment'
                          )}
                        </Button>
                      </form>
                    </Form>
                  </TabsContent>
                </Tabs>
              </CardContent>
              
              <CardFooter className="flex flex-col">
                <p className="text-xs text-gray-500 dark:text-gray-400 text-center">
                  Gold rates are updated every few minutes. The final price will be locked at the time of payment.
                </p>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}