import React, { useState } from "react";
import Sidebar from "@/components/layout/sidebar";
import MobileHeader from "@/components/layout/mobile-header";
import MobileNavigation from "@/components/layout/mobile-navigation";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useRewards } from "@/hooks/use-rewards";
import { usePoints } from "@/hooks/use-points";
import { motion } from "framer-motion";
import { 
  Gift, 
  Package, 
  Trophy, 
  Zap, 
  Award, 
  Star, 
  CreditCard, 
  Coins, 
  History,
  ChevronRight,
  CheckCircle2,
  Clock,
  AlertCircle
} from "lucide-react";
import { GRADIENTS } from "@/lib/luxury-palette";

const RewardsPage = () => {
  const { rewards, userPoints, myRewards, isLoading, isLoadingMyRewards, redeem, isRedeeming } = useRewards();
  const { points, transactions } = usePoints();
  const [selectedReward, setSelectedReward] = useState<any>(null);
  
  // Animation variants for staggered children
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.4 }
    }
  };
  
  const getRewardIcon = (type: string, name: string) => {
    switch (type) {
      case 'subscription':
        return <Star className="h-5 w-5 text-purple-500" />;
      case 'feature':
        return <Zap className="h-5 w-5 text-blue-500" />;
      case 'digital':
        return <Package className="h-5 w-5 text-green-500" />;
      case 'discount':
        return <CreditCard className="h-5 w-5 text-red-500" />;
      case 'service':
        return <Trophy className="h-5 w-5 text-amber-500" />;
      default:
        return <Gift className="h-5 w-5 text-gray-500" />;
    }
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="bg-amber-100 text-amber-800 border-amber-200">Processing</Badge>;
      case 'claimed':
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">Claimed</Badge>;
      case 'expired':
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">Expired</Badge>;
      default:
        return null;
    }
  };
  
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="h-5 w-5 text-amber-500" />;
      case 'claimed':
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'expired':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return null;
    }
  };
  
  const renderAvailableRewards = () => {
    if (isLoading) {
      return (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="pb-2">
                <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              </CardHeader>
              <CardContent className="pb-3">
                <div className="h-20 bg-gray-200 rounded mb-4"></div>
                <div className="h-6 bg-gray-200 rounded w-1/3"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      );
    }
    
    if (!rewards || rewards.length === 0) {
      return (
        <div className="text-center py-10">
          <Gift className="h-12 w-12 mx-auto text-gray-400 mb-3" />
          <h3 className="text-lg font-medium">No Rewards Available</h3>
          <p className="text-gray-500">Check back soon for new rewards!</p>
        </div>
      );
    }
    
    return (
      <motion.div 
        className="grid grid-cols-1 md:grid-cols-3 gap-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {rewards.map((reward: any) => (
          <motion.div key={reward.id} variants={itemVariants}>
            <Card className={`h-full transition-all duration-200 hover:shadow-md ${
              reward.canAfford ? 'border-muted hover:border-primary/30' : 'bg-muted/30'
            }`}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg flex items-center">
                    {getRewardIcon(reward.type, reward.name)}
                    <span className="ml-2">{reward.name}</span>
                  </CardTitle>
                  <Badge variant={reward.canAfford ? "outline" : "secondary"} className="font-normal">
                    {reward.cost} points
                  </Badge>
                </div>
                <CardDescription>{reward.type.charAt(0).toUpperCase() + reward.type.slice(1)}</CardDescription>
              </CardHeader>
              
              <CardContent className="pb-3">
                <p className="text-sm text-gray-600 mb-4">{reward.description}</p>
              </CardContent>
              
              <CardFooter>
                <Button 
                  className="w-full"
                  variant={reward.canAfford ? "default" : "secondary"}
                  disabled={!reward.canAfford || isRedeeming}
                  onClick={() => setSelectedReward(reward)}
                >
                  {reward.canAfford ? "Redeem Reward" : "Not Enough Points"}
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    );
  };
  
  const renderMyRewards = () => {
    if (isLoadingMyRewards) {
      return (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="pb-2">
                <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              </CardHeader>
              <CardContent className="pb-3">
                <div className="h-12 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      );
    }
    
    if (!myRewards || myRewards.length === 0) {
      return (
        <div className="text-center py-10">
          <Package className="h-12 w-12 mx-auto text-gray-400 mb-3" />
          <h3 className="text-lg font-medium">No Rewards Redeemed Yet</h3>
          <p className="text-gray-500">Redeem rewards to see them here!</p>
        </div>
      );
    }
    
    return (
      <motion.div 
        className="space-y-4"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {myRewards.map((userReward: any) => (
          <motion.div key={userReward.id} variants={itemVariants}>
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    {getRewardIcon(userReward.reward.type, userReward.reward.name)}
                    <div className="ml-3">
                      <CardTitle className="text-base">{userReward.reward.name}</CardTitle>
                      <CardDescription>Redeemed on {new Date(userReward.redeemedAt).toLocaleDateString()}</CardDescription>
                    </div>
                  </div>
                  {getStatusBadge(userReward.status)}
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="flex items-center">
                  {getStatusIcon(userReward.status)}
                  <p className="text-sm ml-2 text-gray-600">
                    {userReward.status === 'pending' 
                      ? "Your reward is being processed. It will be available soon." 
                      : userReward.status === 'claimed' 
                      ? "You have successfully claimed this reward." 
                      : "This reward has expired."}
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-neutral-50 to-gray-100">
      {/* Mobile header */}
      <MobileHeader />
      
      <main className="flex-1 pb-20 md:pb-0 md:flex">
        {/* Sidebar */}
        <Sidebar />
        
        <div className="w-full md:flex-1 px-4 md:px-8 py-4 md:py-8">
          <div className="md:max-w-5xl mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-3xl font-bold">Rewards Shop</h1>
                <p className="text-gray-500">Earn points and redeem exclusive rewards</p>
              </div>
              
              <Card className="bg-background border p-4 shadow-sm hidden md:block">
                <div className="flex items-center space-x-4">
                  <div className="rounded-full bg-amber-100 p-2">
                    <Coins className="h-5 w-5 text-amber-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Available Points</p>
                    <p className="text-2xl font-bold">
                      {isLoading ? "..." : userPoints?.availablePoints || 0}
                    </p>
                  </div>
                </div>
              </Card>
            </div>
            
            {/* Points summary (mobile) */}
            <Card className="bg-gradient-to-r from-amber-50 to-yellow-50 mb-6 border-amber-100 md:hidden">
              <CardContent className="p-4">
                <div className="flex items-center">
                  <div className="bg-amber-500/10 rounded-full p-3 mr-4">
                    <Coins className="h-6 w-6 text-amber-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Available Points</p>
                    <p className="text-2xl font-bold">
                      {isLoading ? "..." : userPoints?.availablePoints || 0}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Tabs */}
            <Tabs defaultValue="available" className="mb-6">
              <TabsList className="mb-6">
                <TabsTrigger value="available" className="flex-1">Available Rewards</TabsTrigger>
                <TabsTrigger value="myrewards" className="flex-1">My Rewards</TabsTrigger>
              </TabsList>
              
              <TabsContent value="available">
                {renderAvailableRewards()}
              </TabsContent>
              
              <TabsContent value="myrewards">
                {renderMyRewards()}
                
                {/* Point History */}
                <div className="mt-8">
                  <h3 className="text-lg font-medium flex items-center mb-4">
                    <History className="h-5 w-5 mr-2 text-gray-500" />
                    Point History
                  </h3>
                  
                  <Card>
                    <CardContent className="p-0">
                      {!transactions || transactions.length === 0 ? (
                        <div className="text-center py-6">
                          <p className="text-gray-500">No point transactions yet</p>
                        </div>
                      ) : (
                        <div className="divide-y">
                          {transactions.slice(0, 5).map((transaction: any) => (
                            <div key={transaction.id} className="flex items-center justify-between p-4">
                              <div>
                                <p className="font-medium">{transaction.description}</p>
                                <p className="text-xs text-gray-500">{new Date(transaction.createdAt).toLocaleDateString()}</p>
                              </div>
                              <span className={`font-semibold ${transaction.amount > 0 ? 'text-green-600' : 'text-red-600'}`}>
                                {transaction.amount > 0 ? '+' : ''}{transaction.amount}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
            
            {/* How to Earn Points Card */}
            <Card className="mt-8 overflow-hidden bg-gradient-to-br from-amber-50 to-orange-50 border-amber-100">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center">
                  <Award className="mr-2 h-5 w-5 text-amber-600" />
                  How to Earn Points
                </CardTitle>
                <CardDescription>Complete these actions to earn more reward points</CardDescription>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-4">
                  <div className="flex">
                    <div className="mr-4 p-2 rounded-full bg-blue-100 flex-shrink-0">
                      <Zap className="h-4 w-4 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium">Daily Check-ins</p>
                      <p className="text-sm text-gray-600">Log in every day to maintain your streak and earn bonus points.</p>
                    </div>
                    <div className="ml-auto flex items-center text-amber-600 font-medium">
                      +5 <ChevronRight className="h-4 w-4 ml-1" />
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="mr-4 p-2 rounded-full bg-green-100 flex-shrink-0">
                      <Trophy className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium">Complete Goals</p>
                      <p className="text-sm text-gray-600">Earn points by setting and completing savings goals.</p>
                    </div>
                    <div className="ml-auto flex items-center text-amber-600 font-medium">
                      +25 <ChevronRight className="h-4 w-4 ml-1" />
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="mr-4 p-2 rounded-full bg-purple-100 flex-shrink-0">
                      <Star className="h-4 w-4 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium">Unlock Achievements</p>
                      <p className="text-sm text-gray-600">Complete special actions to unlock achievements with point rewards.</p>
                    </div>
                    <div className="ml-auto flex items-center text-amber-600 font-medium">
                      +50 <ChevronRight className="h-4 w-4 ml-1" />
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="mr-4 p-2 rounded-full bg-amber-100 flex-shrink-0">
                      <CreditCard className="h-4 w-4 text-amber-600" />
                    </div>
                    <div>
                      <p className="font-medium">Make Investments</p>
                      <p className="text-sm text-gray-600">Earn points with every new investment.</p>
                    </div>
                    <div className="ml-auto flex items-center text-amber-600 font-medium">
                      +20 <ChevronRight className="h-4 w-4 ml-1" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Footer */}
            <div className="text-center mt-8 mb-4">
              <div 
                style={{ background: GRADIENTS.darkSlate }} 
                className="px-4 py-2 rounded-full shadow-lg inline-flex items-center space-x-2"
              >
                <div 
                  style={{ background: GRADIENTS.goldPrimary }} 
                  className="w-6 h-6 rounded-full flex items-center justify-center"
                >
                  <span className="text-white text-xs">₹</span>
                </div>
                <span className="text-xs text-white font-medium">Khansa: Premium Investment Platform</span>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <MobileNavigation />
      
      {/* Redeem Confirmation Dialog */}
      {selectedReward && (
        <Dialog open={!!selectedReward} onOpenChange={(open) => !open && setSelectedReward(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center">
                {getRewardIcon(selectedReward.type, selectedReward.name)}
                <span className="ml-2">Redeem {selectedReward.name}</span>
              </DialogTitle>
              <DialogDescription>
                This will deduct {selectedReward.cost} points from your account
              </DialogDescription>
            </DialogHeader>
            
            <div className="py-4">
              <p className="mb-4">{selectedReward.description}</p>
              
              <div className="bg-muted p-4 rounded-md mb-4">
                <p className="text-sm font-medium">Your points after redeeming:</p>
                <div className="flex items-center mt-1">
                  <Coins className="h-4 w-4 mr-2 text-amber-500" />
                  <span className="font-bold">{userPoints?.availablePoints - selectedReward.cost}</span>
                  <span className="text-muted-foreground text-sm ml-2">
                    (Current: {userPoints?.availablePoints})
                  </span>
                </div>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setSelectedReward(null)}>Cancel</Button>
              <Button 
                onClick={() => {
                  redeem(selectedReward.id);
                  setSelectedReward(null);
                }}
                disabled={isRedeeming}
              >
                Confirm Redemption
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default RewardsPage;