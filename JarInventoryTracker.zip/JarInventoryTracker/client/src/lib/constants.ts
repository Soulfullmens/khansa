export const COLORS = {
  gold: {
    50: '#FFF8E6',
    100: '#FFF1CC',
    200: '#FFE499',
    300: '#FFD666',
    400: '#FFC833',
    500: '#F7B801', // Primary gold
    600: '#CC9600',
    700: '#A67800',
    800: '#805A00',
    900: '#593F00'
  },
  navy: {
    50: '#E6EBF0',
    100: '#C0D0DE',
    200: '#97B2CA',
    300: '#6E93B6',
    400: '#507CA7',
    500: '#3A648F',
    600: '#2D4D6E',
    700: '#1A2E44', // Primary navy
    800: '#13233A',
    900: '#0C1522'
  },
  turquoise: {
    500: '#00C9A7' // Accent
  }
};

export const GOAL_ICONS = [
  { icon: "ri-plane-line", bg: "bg-turquoise-500", name: "Travel" },
  { icon: "ri-computer-line", bg: "bg-blue-500", name: "Gadget" },
  { icon: "ri-home-line", bg: "bg-purple-500", name: "Home" },
  { icon: "ri-car-line", bg: "bg-red-500", name: "Vehicle" },
  { icon: "ri-book-open-line", bg: "bg-green-500", name: "Education" },
  { icon: "ri-heart-line", bg: "bg-pink-500", name: "Health" },
  { icon: "ri-gift-line", bg: "bg-yellow-500", name: "Gift" },
  { icon: "ri-shopping-bag-line", bg: "bg-indigo-500", name: "Shopping" },
];

export const TRANSACTION_TYPES = {
  "auto-save": {
    icon: "ri-add-line",
    bg: "bg-green-100",
    color: "text-green-600",
    label: "Auto-save"
  },
  "round-up": {
    icon: "ri-exchange-funds-line",
    bg: "bg-blue-100",
    color: "text-blue-600",
    label: "Round-up savings"
  },
  "manual-deposit": {
    icon: "ri-hand-coin-line",
    bg: "bg-purple-100",
    color: "text-purple-600",
    label: "Manual deposit"
  },
  "withdraw": {
    icon: "ri-subtract-line",
    bg: "bg-red-100",
    color: "text-red-600",
    label: "Withdrawal"
  }
};

export const INSIGHT_TYPES = {
  "positive": {
    icon: "ri-lightbulb-flash-line",
    bg: "bg-gold-100",
    color: "text-gold-600",
    border: "border-gold-500"
  },
  "warning": {
    icon: "ri-alert-line",
    bg: "bg-red-100",
    color: "text-red-600",
    border: "border-red-500"
  },
  "info": {
    icon: "ri-information-line",
    bg: "bg-blue-100",
    color: "text-blue-600",
    border: "border-blue-500"
  }
};
