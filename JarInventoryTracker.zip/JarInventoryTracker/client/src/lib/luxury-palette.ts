// Luxury color palette for Khansa application
// This palette provides a rich, professional set of colors beyond the gold/amber theme

export const LUXURY_PALETTE = {
  // Neutral tones
  neutral: {
    950: '#0F172A', // Deep navy blue - almost black
    900: '#1E293B', // Rich slate blue
    800: '#334155', // Dark slate
    700: '#475569', // Medium slate
    600: '#64748B', // Slate gray
    500: '#94A3B8', // Medium gray
    400: '#CBD5E1', // Light gray
    300: '#E2E8F0', // Very light gray
    200: '#F1F5F9', // Almost white
    100: '#F8FAFC', // Pure white
    50: '#FBFCFE',  // Extra Light
  },
  
  // Primary gold palette (used as accent)
  gold: {
    900: '#854D0E', // Deep gold
    800: '#A16207', // Rich gold
    700: '#B45309', // Dark gold
    600: '#D97706', // Medium gold
    500: '#F59E0B', // Standard gold
    400: '#F7B801', // Light gold
    300: '#FCD34D', // Very light gold
    200: '#FDE68A', // Ultra light gold
    100: '#FEF3C7', // Gold tint
  },

  // Rich complimentary royal blue
  royalBlue: {
    900: '#1E3A8A', // Deep royal blue
    800: '#1E40AF', // Rich royal blue
    700: '#1D4ED8', // Medium royal blue
    600: '#2563EB', // Standard royal blue
    500: '#3B82F6', // Light royal blue
    400: '#60A5FA', // Very light royal blue
    300: '#93C5FD', // Ultra light royal blue
    200: '#BFDBFE', // Blue tint
    100: '#DBEAFE', // Pale blue
    50: '#EFF6FF',  // Extra Light
  },

  // Elegant emerald green
  emerald: {
    900: '#064E3B', // Deep emerald
    800: '#065F46', // Rich emerald
    700: '#047857', // Dark emerald
    600: '#059669', // Medium emerald
    500: '#10B981', // Standard emerald
    400: '#34D399', // Light emerald
    300: '#6EE7B7', // Very light emerald
    200: '#A7F3D0', // Ultra light emerald
    100: '#D1FAE5', // Emerald tint
    50: '#ECFDF5',  // Extra Light
  },

  // Luxury purple
  purple: {
    900: '#4C1D95', // Deep purple
    800: '#5B21B6', // Rich purple
    700: '#6D28D9', // Dark purple
    600: '#7C3AED', // Medium purple
    500: '#8B5CF6', // Standard purple
    400: '#A78BFA', // Light purple
    300: '#C4B5FD', // Very light purple
    200: '#DDD6FE', // Ultra light purple
    100: '#EDE9FE', // Purple tint
  },

  // Rich burgundy/wine
  burgundy: {
    900: '#7F1D1D', // Deep burgundy
    800: '#991B1B', // Rich burgundy
    700: '#B91C1C', // Dark burgundy
    600: '#DC2626', // Medium burgundy
    500: '#EF4444', // Standard burgundy
    400: '#F87171', // Light burgundy
    300: '#FCA5A5', // Very light burgundy
    200: '#FECACA', // Ultra light burgundy
    100: '#FEE2E2', // Burgundy tint
  }
};

// Using the palette in various contexts
export const UI_COLORS = {
  // Primary UI elements
  primary: LUXURY_PALETTE.neutral[900],
  primaryDark: LUXURY_PALETTE.neutral[950],
  primaryLight: LUXURY_PALETTE.neutral[800],
  
  // Accent colors
  accent: LUXURY_PALETTE.gold[500],
  accentDark: LUXURY_PALETTE.gold[700],
  accentLight: LUXURY_PALETTE.gold[300],
  
  // Secondary accent colors
  secondary: LUXURY_PALETTE.royalBlue[600],
  secondaryDark: LUXURY_PALETTE.royalBlue[800],
  secondaryLight: LUXURY_PALETTE.royalBlue[400],
  
  // Success indicators
  success: LUXURY_PALETTE.emerald[600],
  successDark: LUXURY_PALETTE.emerald[800],
  successLight: LUXURY_PALETTE.emerald[400],
  
  // Error indicators
  error: LUXURY_PALETTE.burgundy[600],
  errorDark: LUXURY_PALETTE.burgundy[800],
  errorLight: LUXURY_PALETTE.burgundy[400],
  
  // Highlight colors
  highlight: LUXURY_PALETTE.purple[500],
  highlightDark: LUXURY_PALETTE.purple[700],
  highlightLight: LUXURY_PALETTE.purple[300],
  
  // Background variations
  background: LUXURY_PALETTE.neutral[100],
  backgroundAlt: LUXURY_PALETTE.neutral[200],
  
  // Text colors
  textPrimary: LUXURY_PALETTE.neutral[900],
  textSecondary: LUXURY_PALETTE.neutral[600],
  textLight: LUXURY_PALETTE.neutral[400],
};

// Color gradients
export const GRADIENTS = {
  goldPrimary: `linear-gradient(to right, ${LUXURY_PALETTE.gold[400]}, ${LUXURY_PALETTE.gold[600]})`,
  goldLight: `linear-gradient(to right, ${LUXURY_PALETTE.gold[300]}, ${LUXURY_PALETTE.gold[500]})`,
  bluePrimary: `linear-gradient(to right, ${LUXURY_PALETTE.royalBlue[500]}, ${LUXURY_PALETTE.royalBlue[700]})`,
  purpleGold: `linear-gradient(to right, ${LUXURY_PALETTE.purple[500]}, ${LUXURY_PALETTE.gold[500]})`,
  emeraldBlue: `linear-gradient(to right, ${LUXURY_PALETTE.emerald[500]}, ${LUXURY_PALETTE.royalBlue[500]})`,
  darkSlate: `linear-gradient(to right, ${LUXURY_PALETTE.neutral[800]}, ${LUXURY_PALETTE.neutral[900]})`,
};

// Dashboard section color assignments
export const DASHBOARD_COLORS = {
  portfolioCard: {
    background: LUXURY_PALETTE.neutral[100],
    border: LUXURY_PALETTE.neutral[300],
    title: LUXURY_PALETTE.neutral[900],
    subtitle: LUXURY_PALETTE.neutral[600],
    value: LUXURY_PALETTE.gold[700],
    accent: LUXURY_PALETTE.gold[500],
  },
  
  goldPriceSection: {
    background: LUXURY_PALETTE.neutral[100],
    border: LUXURY_PALETTE.gold[300],
    title: LUXURY_PALETTE.neutral[900],
    value: LUXURY_PALETTE.gold[700],
    change: {
      positive: LUXURY_PALETTE.emerald[600],
      negative: LUXURY_PALETTE.burgundy[600],
    },
    chart: {
      line: LUXURY_PALETTE.gold[500],
      fillStart: LUXURY_PALETTE.gold[300],
      fillEnd: LUXURY_PALETTE.gold[100],
    }
  },
  
  smartSavings: {
    background: LUXURY_PALETTE.neutral[100],
    border: LUXURY_PALETTE.royalBlue[300],
    title: LUXURY_PALETTE.neutral[900],
    accent: LUXURY_PALETTE.royalBlue[500],
    card: {
      background: LUXURY_PALETTE.neutral[100],
      border: LUXURY_PALETTE.neutral[200],
      title: LUXURY_PALETTE.neutral[900],
      text: LUXURY_PALETTE.neutral[700],
      savingsValue: LUXURY_PALETTE.emerald[600],
    },
    categories: [
      LUXURY_PALETTE.royalBlue[500],
      LUXURY_PALETTE.purple[500],
      LUXURY_PALETTE.emerald[500],
      LUXURY_PALETTE.gold[500],
      LUXURY_PALETTE.burgundy[500],
    ]
  },
  
  goals: {
    background: LUXURY_PALETTE.neutral[100],
    border: LUXURY_PALETTE.emerald[300],
    title: LUXURY_PALETTE.neutral[900],
    accent: LUXURY_PALETTE.emerald[500],
    progress: LUXURY_PALETTE.emerald[600],
    progressBackground: LUXURY_PALETTE.emerald[100],
  },
  
  navigation: {
    background: LUXURY_PALETTE.neutral[900],
    active: LUXURY_PALETTE.gold[500],
    inactive: LUXURY_PALETTE.neutral[400],
    hover: LUXURY_PALETTE.neutral[800],
    border: LUXURY_PALETTE.neutral[700],
  }
};

export default LUXURY_PALETTE;