import { apiRequest } from "./queryClient";

export interface GoldPriceData {
  pricePerGram: number;
  timestamp: string;
  change24h: string;
  currency: string;
}

export interface HistoricalGoldPrice {
  date: string;
  price: number;
}

/**
 * Fetches the current gold price from the server
 */
export async function fetchCurrentGoldPrice(): Promise<GoldPriceData> {
  try {
    const response = await apiRequest("GET", "/api/gold/price");
    const data = await response.json();
    
    return {
      pricePerGram: parseFloat(data.pricePerGram),
      timestamp: data.timestamp || new Date().toISOString(),
      change24h: data.change24h || '0.00',
      currency: data.currency || 'INR'
    };
  } catch (error) {
    console.error("Error fetching gold price:", error);
    // Return fallback data
    return {
      pricePerGram: 5500, // Approximate gold price in INR per gram
      timestamp: new Date().toISOString(),
      change24h: '0.00',
      currency: 'INR'
    };
  }
}

/**
 * Fetches historical gold prices for a specified number of days
 */
export async function fetchHistoricalGoldPrices(days: number = 30): Promise<HistoricalGoldPrice[]> {
  try {
    const response = await apiRequest("GET", `/api/gold/price/history?days=${days}`);
    return await response.json();
  } catch (error) {
    console.error("Error fetching historical gold prices:", error);
    // Return empty array on error
    return [];
  }
}

/**
 * Gets AI-powered gold price forecast
 */
export async function getGoldPriceForecast(): Promise<{prediction: string, confidence: number}> {
  try {
    const response = await apiRequest("GET", "/api/gold/forecast");
    return await response.json();
  } catch (error) {
    console.error("Error fetching gold price forecast:", error);
    return {
      prediction: "Unable to generate forecast at this time",
      confidence: 0
    };
  }
}

/**
 * Converts INR amount to gold grams based on current price
 */
export function inrToGoldGrams(inrAmount: number, currentPricePerGram: number): number {
  return inrAmount / currentPricePerGram;
}

/**
 * Converts gold grams to INR based on current price
 */
export function goldGramsToInr(grams: number, currentPricePerGram: number): number {
  return grams * currentPricePerGram;
}