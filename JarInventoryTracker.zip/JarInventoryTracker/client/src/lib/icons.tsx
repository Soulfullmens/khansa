// Icon components using react-icons to replace remixicon class usage
import { 
  FiPlus, FiTrendingUp, FiArrowUp, FiArrowDown, 
  FiRepeat, FiAward, FiGift, FiHeadphones, FiShield, 
  FiDollarSign, FiCamera, FiLock, FiCreditCard, FiTrash2,
  FiLogOut, FiDelete, FiStar, FiSettings,
  FiBarChart2
} from 'react-icons/fi';

import {
  BsLightbulb, BsArrowLeftRight
} from 'react-icons/bs';

import {
  GiTrophyCup, GiCoinsPile, GiCoins
} from 'react-icons/gi';

// Map of remixicon classes to react-icons components
export const Icons = {
  'ri-add-line': FiPlus,
  'ri-coin-line': GiCoins,
  'ri-line-chart-line': FiTrendingUp,
  'ri-arrow-up-line': FiArrowUp,
  'ri-arrow-down-line': FiArrowDown,
  'ri-repeat-line': FiRepeat,
  'ri-trophy-line': GiTrophyCup,
  'ri-award-line': FiAward,
  'ri-gift-line': FiGift,
  'ri-customer-service-2-line': FiHeadphones,
  'ri-shield-check-line': FiShield,
  'ri-exchange-dollar-line': FiDollarSign,
  'ri-camera-line': FiCamera,
  'ri-lock-password-line': FiLock,
  'ri-bank-card-line': FiCreditCard,
  'ri-delete-bin-line': FiTrash2,
  'ri-logout-box-line': FiLogOut,
  'ri-lightbulb-line': BsLightbulb,
  'ri-funds-line': FiBarChart2,
  'ri-exchange-line': BsArrowLeftRight,
  'ri-coins-line': GiCoinsPile
};

// Helper component to use instead of <i className="ri-xxx"></i>
interface IconProps {
  icon: string;
  className?: string;
  style?: React.CSSProperties;
}

export const Icon = ({ icon, className = '', style }: IconProps) => {
  const IconComponent = Icons[icon as keyof typeof Icons] || FiStar;
  
  return (
    <span className={className} style={style}>
      <IconComponent />
    </span>
  );
};

export default Icon;