import Anthropic from '@anthropic-ai/sdk';

// Check for the required API key
if (!process.env.ANTHROPIC_API_KEY) {
  console.warn('ANTHROPIC_API_KEY is not set. AI features will not work correctly.');
}

// Initialize Anthropic SDK (this will be imported in the server side)
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY || '',
});

// Type definitions for transaction data
export interface Transaction {
  id: number;
  userId: number;
  amount: number;
  type: string;
  category: string;
  description: string | null;
  date: Date;
  goalId?: number | null;
  createdAt?: Date;
}

// Types for spending analysis
export interface SpendingCategory {
  category: string;
  totalAmount: number;
  percentageOfTotal: number;
  transactions: Transaction[];
}

export interface SpendingAnalysis {
  totalSpending: number;
  categories: SpendingCategory[];
  timeRange: {
    start: Date;
    end: Date;
  };
}

// Types for savings recommendations
export interface SavingsRecommendation {
  id: string;
  title: string;
  description: string;
  potentialSavings: number;
  difficulty: 'easy' | 'medium' | 'hard';
  implementationSteps?: string[];
  category: string;
}

/**
 * Analyzes transactions to identify spending patterns
 */
export function analyzeSpending(transactions: Transaction[]): SpendingAnalysis {
  // If no transactions, return empty analysis
  if (!transactions || transactions.length === 0) {
    return {
      totalSpending: 0,
      categories: [],
      timeRange: {
        start: new Date(),
        end: new Date()
      }
    };
  }
  
  // Filter to only withdrawals/payments
  const expenses = transactions.filter(t => 
    t.type === 'withdrawal' || (t.amount < 0 && t.type !== 'deposit')
  );
  
  // Get date range
  const dates = expenses.map(t => new Date(t.date).getTime());
  const startDate = new Date(Math.min(...dates));
  const endDate = new Date(Math.max(...dates));
  
  // Group by category
  const categoryMap = new Map<string, Transaction[]>();
  
  expenses.forEach(transaction => {
    if (!categoryMap.has(transaction.category)) {
      categoryMap.set(transaction.category, []);
    }
    categoryMap.get(transaction.category)?.push(transaction);
  });
  
  // Calculate totals
  const totalSpending = Math.abs(expenses.reduce((sum, t) => sum + t.amount, 0));
  
  // Create category analysis
  const categories: SpendingCategory[] = [];
  
  categoryMap.forEach((transactions, category) => {
    const categoryTotal = Math.abs(transactions.reduce((sum, t) => sum + t.amount, 0));
    categories.push({
      category,
      totalAmount: categoryTotal,
      percentageOfTotal: totalSpending > 0 ? (categoryTotal / totalSpending) * 100 : 0,
      transactions
    });
  });
  
  // Sort categories by amount (highest first)
  categories.sort((a, b) => b.totalAmount - a.totalAmount);
  
  return {
    totalSpending,
    categories,
    timeRange: {
      start: startDate,
      end: endDate
    }
  };
}

/**
 * Generates AI-powered savings recommendations based on spending analysis
 * This will be called from the server-side
 */
export async function generateSavingsRecommendations(
  analysis: SpendingAnalysis
): Promise<SavingsRecommendation[]> {
  // For local development or when API key is missing, return sample recommendations
  if (!process.env.ANTHROPIC_API_KEY) {
    console.warn('Using sample recommendations because ANTHROPIC_API_KEY is not set');
    return getSampleRecommendations(analysis);
  }

  try {
    // Prepare the analysis data for the AI
    const topCategories = analysis.categories
      .slice(0, 5)
      .map(cat => `${cat.category}: ₹${cat.totalAmount.toFixed(2)} (${cat.percentageOfTotal.toFixed(1)}%)`);
    
    // Create a prompt for the AI
    const prompt = `Analyze this user's spending data and provide 3-5 personalized savings recommendations.
    
    Spending Overview:
    Total spending: ₹${analysis.totalSpending.toFixed(2)}
    Time period: ${analysis.timeRange.start.toLocaleDateString()} to ${analysis.timeRange.end.toLocaleDateString()}
    
    Top spending categories:
    ${topCategories.join('\n')}
    
    For each recommendation:
    1. Provide a specific, actionable title (e.g., "Switch to a cheaper mobile plan" not "Reduce phone expenses")
    2. Write a detailed description explaining the recommendation
    3. Estimate potential monthly savings in Indian Rupees (₹)
    4. Rate difficulty as "easy", "medium", or "hard"
    5. List 2-3 implementation steps
    6. Categorize the recommendation
    
    Format each recommendation as a JSON object with keys: title, description, potentialSavings, difficulty, implementationSteps, category.
    Return an array of these JSON objects.`;

    // the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
    const response = await anthropic.messages.create({
      model: "claude-3-7-sonnet-20250219",
      max_tokens: 1000,
      messages: [
        { role: 'user', content: prompt }
      ],
      temperature: 0.3,
    });

    // Extract and parse the JSON response
    const content = typeof response.content[0] === 'object' && 'text' in response.content[0] 
      ? response.content[0].text
      : '';
    
    // Find JSON array in response (handling potential non-JSON text around it)
    const jsonMatch = content.match(/\[\s*\{[\s\S]*\}\s*\]/);
    if (!jsonMatch) {
      throw new Error('Failed to parse AI response as JSON');
    }
    
    const recommendations = JSON.parse(jsonMatch[0]) as SavingsRecommendation[];
    
    // Add IDs to recommendations
    return recommendations.map((rec, index) => ({
      ...rec,
      id: `rec-${Date.now()}-${index}`
    }));

  } catch (error) {
    console.error('Error generating AI recommendations:', error);
    return getSampleRecommendations(analysis);
  }
}

/**
 * Returns sample recommendations for development/fallback purposes
 */
function getSampleRecommendations(analysis: SpendingAnalysis): SavingsRecommendation[] {
  // Find the highest spending category
  const topCategory = analysis.categories[0]?.category || 'dining';
  
  return [
    {
      id: `rec-${Date.now()}-1`,
      title: `Reduce ${topCategory} expenses`,
      description: `You're spending a significant amount on ${topCategory}. Consider setting a budget for this category and tracking your spending more closely.`,
      potentialSavings: Math.round(analysis.categories[0]?.totalAmount * 0.2) || 1000,
      difficulty: 'medium',
      implementationSteps: [
        `Set a monthly ${topCategory} budget`,
        `Use the Khansa app to track your ${topCategory} spending`,
        `Find more affordable alternatives`
      ],
      category: topCategory
    },
    {
      id: `rec-${Date.now()}-2`,
      title: 'Automate small savings',
      description: 'Enable round-up savings to automatically save small amounts with every transaction.',
      potentialSavings: 500,
      difficulty: 'easy',
      implementationSteps: [
        'Enable round-up feature in the app settings',
        'Choose your round-up amount (₹5, ₹10, etc.)',
        'Select your savings goal'
      ],
      category: 'automation'
    },
    {
      id: `rec-${Date.now()}-3`,
      title: 'Review subscription services',
      description: 'Cancel unused subscriptions or switch to annual plans to save money.',
      potentialSavings: 800,
      difficulty: 'medium',
      implementationSteps: [
        'List all active subscriptions',
        'Identify services you rarely use',
        'Cancel or downgrade unnecessary subscriptions'
      ],
      category: 'subscriptions'
    }
  ];
}