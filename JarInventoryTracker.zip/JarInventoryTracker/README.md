<<<<<<< HEAD
# khansa
=======
# Khansa Finance App

A comprehensive financial platform designed to simplify and gamify personal finance, enabling users to save, invest, and grow their wealth through intuitive digital tools.

## Features

- **Multi-asset Investment Options**: Gold, mutual funds, fixed deposits, bonds, and cryptocurrency (where regulated)
- **Smart Savings**: AI-powered recommendations based on spending patterns
- **Goal-based Saving**: Set financial goals and track progress
- **Gamification System**: Earn points, unlock achievements, and maintain streaks for consistent financial habits
- **Rewards Marketplace**: Redeem earned points for various rewards and benefits
- **UPI Payment Integration**: Support for popular payment options including Google Pay and PhonePe
- **Real-time Gold Price Tracking**: Visual charts showing price trends
- **Credit & Financial Growth Tools**: Credit score building, micro-insurance options

## Tech Stack

- **Frontend**: React.js with Tailwind CSS and ShadCN UI components
- **Backend**: Node.js with Express
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Custom authentication system with secure password reset functionality
- **Payment Processing**: Stripe integration
- **Email Functionality**: SendGrid

## Getting Started

### Prerequisites

- Node.js (v16+)
- PostgreSQL database
- Stripe account for payments
- SendGrid account for emails (optional)
- Anthropic API key for AI features (optional)

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/khansa-finance-app.git
   cd khansa-finance-app
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Set up environment variables:
   Create a `.env` file in the root directory with the following variables:
   ```
   DATABASE_URL=your_postgresql_connection_string
   STRIPE_SECRET_KEY=your_stripe_secret_key
   VITE_STRIPE_PUBLIC_KEY=your_stripe_public_key
   ANTHROPIC_API_KEY=your_anthropic_api_key (optional)
   SENDGRID_API_KEY=your_sendgrid_api_key (optional)
   ```

4. Start the development server:
   ```bash
   npm run dev
   ```

## Screenshots

[Coming soon]

## License

[Your chosen license]

## Contributors

[Your name/organization]
>>>>>>> 70baf43 (Initial commit - Khansa Finance App with gamification features)
