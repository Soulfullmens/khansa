import { pgTable, text, serial, timestamp, numeric, integer, boolean, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  profileImage: text("profile_image"),
  userLevel: text("user_level").default("Gold Saver").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  // Password reset fields
  resetToken: text("reset_token"),
  resetTokenExpires: timestamp("reset_token_expires"),
  // Stripe fields for subscription
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  subscriptionStatus: text("subscription_status").default("none").notNull(),
  subscriptionTier: text("subscription_tier").default("free").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
  name: true,
  profileImage: true,
});

// Investments schema
export const investments = pgTable("investments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  goldAmount: numeric("gold_amount", { precision: 10, scale: 4 }).notNull(),
  goldValue: numeric("gold_value", { precision: 10, scale: 2 }).notNull(),
  otherInvestments: numeric("other_investments", { precision: 10, scale: 2 }).default("0"),
  totalValue: numeric("total_value", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertInvestmentSchema = createInsertSchema(investments).pick({
  userId: true,
  goldAmount: true,
  goldValue: true,
  otherInvestments: true,
  totalValue: true,
});

// Goals schema
export const goals = pgTable("goals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  targetAmount: numeric("target_amount", { precision: 10, scale: 2 }).notNull(),
  currentAmount: numeric("current_amount", { precision: 10, scale: 2 }).notNull(),
  targetDate: timestamp("target_date").notNull(),
  icon: text("icon").notNull(),
  iconBg: text("icon_bg").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertGoalSchema = createInsertSchema(goals).pick({
  userId: true,
  name: true,
  targetAmount: true,
  currentAmount: true,
  targetDate: true,
  icon: true,
  iconBg: true,
});

// Transactions schema
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // auto-save, round-up, manual-deposit, etc.
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  goalId: integer("goal_id"), // null if not associated with a goal
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  userId: true,
  type: true,
  amount: true,
  goalId: true,
  description: true,
});

// Gold Price schema
export const goldPrices = pgTable("gold_prices", {
  id: serial("id").primaryKey(),
  pricePerGram: numeric("price_per_gram", { precision: 10, scale: 2 }).notNull(),
  change24h: numeric("change_24h", { precision: 5, scale: 2 }).notNull(),
  change7d: numeric("change_7d", { precision: 5, scale: 2 }).notNull(),
  change30d: numeric("change_30d", { precision: 5, scale: 2 }).notNull(),
  priceHistory: json("price_history").notNull(), // Array of price points for charting
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertGoldPriceSchema = createInsertSchema(goldPrices).pick({
  pricePerGram: true,
  change24h: true,
  change7d: true,
  change30d: true,
  priceHistory: true,
});

// Insights schema
export const insights = pgTable("insights", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // positive, warning, etc.
  title: text("title").notNull(),
  description: text("description").notNull(),
  actionText: text("action_text").notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertInsightSchema = createInsertSchema(insights).pick({
  userId: true,
  type: true,
  title: true,
  description: true,
  actionText: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Investment = typeof investments.$inferSelect;
export type InsertInvestment = z.infer<typeof insertInvestmentSchema>;

export type Goal = typeof goals.$inferSelect;
export type InsertGoal = z.infer<typeof insertGoalSchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type GoldPrice = typeof goldPrices.$inferSelect;
export type InsertGoldPrice = z.infer<typeof insertGoldPriceSchema>;

export type Insight = typeof insights.$inferSelect;
export type InsertInsight = z.infer<typeof insertInsightSchema>;

// Streaks schema
export const streaks = pgTable("streaks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  currentStreak: integer("current_streak").default(0).notNull(),
  longestStreak: integer("longest_streak").default(0).notNull(),
  lastCheckIn: timestamp("last_check_in").defaultNow().notNull(),
  streakFreezeUsed: boolean("streak_freeze_used").default(false).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertStreakSchema = createInsertSchema(streaks).pick({
  userId: true,
  currentStreak: true,
  longestStreak: true,
  lastCheckIn: true,
  streakFreezeUsed: true,
});

// Achievements schema
export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  category: text("category").notNull(), // savings, investment, streak, etc.
  level: integer("level").default(1).notNull(), // 1, 2, 3, etc. for tiered achievements
  pointsAwarded: integer("points_awarded").notNull(),
  isHidden: boolean("is_hidden").default(false).notNull(), // For secret achievements
});

export const insertAchievementSchema = createInsertSchema(achievements).pick({
  name: true,
  description: true,
  icon: true,
  category: true,
  level: true,
  pointsAwarded: true,
  isHidden: true,
});

// User Achievements junction table
export const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  achievementId: integer("achievement_id").notNull(),
  unlockedAt: timestamp("unlocked_at").defaultNow().notNull(),
  isNew: boolean("is_new").default(true).notNull(), // To show "new achievement" badge
});

export const insertUserAchievementSchema = createInsertSchema(userAchievements).pick({
  userId: true,
  achievementId: true,
  isNew: true,
});

// Rewards schema
export const rewards = pgTable("rewards", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  cost: integer("cost").notNull(), // Points cost
  type: text("type").notNull(), // digital, physical, feature, etc.
  isActive: boolean("is_active").default(true).notNull(),
  expiresAt: timestamp("expires_at"), // Optional expiration date
});

export const insertRewardSchema = createInsertSchema(rewards).pick({
  name: true,
  description: true,
  icon: true,
  cost: true,
  type: true,
  isActive: true,
  expiresAt: true,
});

// User Rewards junction table
export const userRewards = pgTable("user_rewards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  rewardId: integer("reward_id").notNull(),
  redeemedAt: timestamp("redeemed_at").defaultNow().notNull(),
  status: text("status").default("pending").notNull(), // pending, claimed, expired
});

export const insertUserRewardSchema = createInsertSchema(userRewards).pick({
  userId: true,
  rewardId: true,
  status: true,
});

// User Points tracking
export const userPoints = pgTable("user_points", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  totalPoints: integer("total_points").default(0).notNull(),
  availablePoints: integer("available_points").default(0).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserPointsSchema = createInsertSchema(userPoints).pick({
  userId: true,
  totalPoints: true,
  availablePoints: true,
});

// Point Transactions
export const pointTransactions = pgTable("point_transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amount: integer("amount").notNull(), // Can be positive or negative
  description: text("description").notNull(),
  source: text("source").notNull(), // achievement, streak, redeem, etc.
  sourceId: integer("source_id"), // Optional reference to the source (achievement id, reward id, etc.)
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPointTransactionSchema = createInsertSchema(pointTransactions).pick({
  userId: true,
  amount: true,
  description: true,
  source: true,
  sourceId: true,
});

// Type exports for new schemas
export type Streak = typeof streaks.$inferSelect;
export type InsertStreak = z.infer<typeof insertStreakSchema>;

export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;

export type UserAchievement = typeof userAchievements.$inferSelect;
export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;

export type Reward = typeof rewards.$inferSelect;
export type InsertReward = z.infer<typeof insertRewardSchema>;

export type UserReward = typeof userRewards.$inferSelect;
export type InsertUserReward = z.infer<typeof insertUserRewardSchema>;

export type UserPoints = typeof userPoints.$inferSelect;
export type InsertUserPoints = z.infer<typeof insertUserPointsSchema>;

export type PointTransaction = typeof pointTransactions.$inferSelect;
export type InsertPointTransaction = z.infer<typeof insertPointTransactionSchema>;
